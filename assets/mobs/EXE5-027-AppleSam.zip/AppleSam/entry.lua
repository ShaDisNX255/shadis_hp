local shared_package_init = include("../AppleSam/character.lua")

function package_init(character)
    local character_info = {
        name = "AppleSam",
        name_on_spawn = true,
        health = 150,
        damage = 30,
        element = Element.Wood,
        damage_kidsseed = 30,
        kidsseed_diff = 5, -- 8
        move_frame1 = 42,
        move_frame2 = 9,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "ApplSamEX"
        character_info.health = 180
        character_info.damage = 60
        character_info.damage_kidsseed = 60
        character_info.kidsseed_diff = 4.4 -- 9
        character_info.move_frame1 = 34
        character_info.move_frame2 = 8
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "AppleTom"
        character_info.health = 210
        character_info.damage = 90
        character_info.damage_kidsseed = 90
        character_info.kidsseed_diff = 3.6 -- 11
        character_info.move_frame1 = 27
        character_info.move_frame2 = 7
    elseif character:get_rank() == Rank.SP then
        character_info.name = "ApplTomEX"
        character_info.health = 250
        character_info.damage = 120
        character_info.damage_kidsseed = 120
        character_info.kidsseed_diff = 3.3 -- 12
        character_info.move_frame1 = 21
        character_info.move_frame2 = 7
    elseif character:get_rank() == Rank.Rare1 then
        character_info.name = "AppleJim"
        character_info.health = 290
        character_info.damage = 160
        character_info.damage_kidsseed = 160
        character_info.kidsseed_diff = 2.3 -- 17
        character_info.move_frame1 = 16
        character_info.move_frame2 = 6
    elseif character:get_rank() == Rank.Rare2 then
        character_info.name = "ApplJimEX"
        character_info.health = 330
        character_info.damage = 200
        character_info.damage_kidsseed = 200
        character_info.kidsseed_diff = 2.2 -- 18
        character_info.move_frame1 = 12
        character_info.move_frame2 = 6
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end