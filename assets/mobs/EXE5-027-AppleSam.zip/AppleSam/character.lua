--[[
    TODO:
    There should be not explosion effect when the gimmick activates.
]]
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
local CHARACTER_SHADOW = Engine.load_texture(_folderpath.."gfx/battle_shadow.png")

local KIDSSEED_TEXTURE = Engine.load_texture(_folderpath.."gfx/kidsseed.grayscaled.png")
local KIDSSEED_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/kidsseed.png")
local KIDSSEED_ANIMPATH = _folderpath.."gfx/kidsseed.animation"
local KIDSSEED_SHADOW = Engine.load_texture(_folderpath.."gfx/kidsseed_shadow.png")
local KIDSSEED_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_194.ogg", true)

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png") -- flip for player 2
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"

local SPARKLES_TEXTURE = Engine.load_texture(_folderpath.."gfx/sparkles.grayscaled.png") -- flip for player 2
local SPARKLES_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/sparkles.png")
local SPARKLES_ANIMPATH = _folderpath.."gfx/sparkles.animation"

local RECOVERY_TEXTURE = Engine.load_texture(_folderpath.."gfx/recovery.grayscaled.png") -- flip for player 2
local RECOVERY_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/recovery.png")
local RECOVERY_ANIMPATH = _folderpath.."gfx/recovery.animation"
local RECOVERY_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_8.ogg", true)

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png") -- flip for player 2
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local JUMP_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_97.ogg", true)
local GUARD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_125.ogg", true)
local GRASS_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_197.ogg", true)

function debug_print(str)
    if print_debug then
        print("[AppleSam] "..str)
    end
end

--possible states for character
local states = { IDLE = 1, MOVE = 2, ATTACK = 3 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

function directions_eight(user)
    local facing_away = user:get_facing_away()
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
    local dirs = {
        Direction.join(facing_away, Direction.Up),
        facing_away,
        Direction.join(facing_away, Direction.Down),
        Direction.Up,
        Direction.Down,
        Direction.join(facing, Direction.Up),
        facing,
        Direction.join(facing, Direction.Down),
    }
    local allies = {}
    for i=1,#dirs do
        local tile = user:get_tile(dirs[i],1)
        local query = function(c)
            return c:get_id() ~= user:get_id() and c:get_health()>0 and c:is_team(team)
        end
        if tile and #tile:find_characters(query)>0 then
            local ally = tile:find_characters(query)
            for j=1,#ally do
                table.insert(allies, ally[j])
            end
        end
    end
    return allies
end

function action_healing(user, facing, field, team, ally, apple)
    print("in action_healing()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self)
        print("in custom card action execute_func()!")
		local a_frames = 1
		local step1 = Battle.Step.new()
		local targets = field:find_characters(function(t)
			return t and t:get_health() > 0 and not t:is_team(team)
		end)
        local anim = apple:get_animation()
        local heights = {
            20,
            40,
            60,
            70,
            30,
        }
        user:hide()
		step1.update_func = function(self)
            for i=2, 2+4*19, 4 do
                if a_frames == i or a_frames == i+1 then
                    apple:sprite():set_color_mode(ColorMode.Additive)
                    apple:sprite():set_color(Color.new(255,255,0,255))
                end
            end
            --[[
            for i=3, 3+4*19, 4 do
                if a_frames == i or a_frames == i+1 then
                    apple:sprite():set_color_mode(ColorMode.Additive)
                    apple:sprite():set_color(Color.new(0,0,0,255))
                end
            end]]
            if a_frames == 44 then
                anim:set_state("HEALING_JUMP")
                apple:jump(ally:get_tile(), 100, frames(30), frames(0), ActionOrder.Immediate)
                Engine.play_audio(JUMP_AUDIO, AudioPriority.Immediate)
            end
            for i=1, 5 do
                if a_frames == 47+5*(i-1) then
                    local fx = graphic_init("artifact", apple:get_tile_offset().x, apple:get_tile_offset().y, SPARKLES_TEXTURE, SPARKLES_PALETTE, SPARKLES_ANIMPATH, -999, "0", Playback.Once, user, facing, true, false, true)
                    fx:set_elevation(heights[i])
                    field:spawn(fx, apple:get_tile())
                end
            end
            if a_frames == 74 then
                anim:set_state("HEALING_LAND")
                ally:set_health(ally:get_max_health())
                local heal_fx = graphic_init("artifact", 0, 0, RECOVERY_TEXTURE, RECOVERY_PALETTE, RECOVERY_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
                field:spawn(heal_fx, ally:get_tile())
                Engine.play_audio(RECOVERY_AUDIO, AudioPriority.Immediate)
            end
            if a_frames == 81 then
                apple:delete()
            end
            if a_frames == 84 then
				self:complete_step()
                user:erase()
            end
			a_frames = a_frames + 1
		end
		self:add_step(step1)
	end
	local meta = action:copy_metadata()
	meta.shortname = "Healing"
	meta.damage = 0
	meta.time_freeze = true
    meta.counterable = false
    meta.skip_time_freeze_intro = true
	action:set_metadata(meta)
	user:card_action_event(action, ActionOrder.Immediate)
end

function create_kids_seed(user, facing, field, diff, damage, tile)
    local seed = graphic_init("spell", -24*2, 0, KIDSSEED_TEXTURE, KIDSSEED_PALETTE, KIDSSEED_ANIMPATH, -3, "0", Playback.Once, user, facing, false, true)
    seed:set_elevation(26*2)
    seed:set_shadow(KIDSSEED_SHADOW)
    seed:show_shadow(true)
    seed:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :elem(Element.Wood)
        :from(user:get_context())
    )
    local tile2 = tile:get_tile(facing,2)
    local tileWidth = tile:width()/2
    local tileHeight = tile:height()/2 - tile:height()/10
    seed.x_speed = tileWidth/diff*2
    if facing == Direction.Left then
        seed.x_speed = -seed.x_speed
    end
    seed.x_coord = seed:get_offset().x
    seed.y_coord = seed:get_offset().y
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    -- Kids Seed deletes itself a frame later then it should.
    local delete_frames = 1
    seed.update_func = function(self)
        self:get_tile():attack_entities(self)
        self.x_coord = self.x_coord + self.x_speed
        if ((facing == Direction.Right and round(self.x_coord) >= 0 and round(self.x_coord) < tileWidth) or (facing == Direction.Left and round(self.x_coord) <= 0 and round(self.x_coord) > -tileWidth)) and self:get_tile() == tile2 then
            if delete_frames == 1 then
                if tile2 and not tile2:is_hole() then
                    local heal_fx = graphic_init("spell", 0, 0, RECOVERY_TEXTURE, RECOVERY_PALETTE, RECOVERY_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
                    field:spawn(heal_fx,tile2)
                    tile2:set_state(TileState.Grass)
                    Engine.play_audio(GRASS_AUDIO, AudioPriority.Immediate)
                    self:delete()
                end
                local offset_x = self.x_coord-8*2
                if facing == Direction.Left then offset_x = self.x_coord+8*2 end
                local move_fx = graphic_init("spell", offset_x, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
                move_fx:set_elevation(26*2)
                field:spawn(move_fx,tile2)
                delete_frames = 2
            elseif delete_frames == 2 then
                self:delete()
            end
        end
        if facing == Direction.Right then
            if round(self.x_coord) > tileWidth then
                if self:get_tile(Direction.Right, 1) then
                    self:teleport(self:get_tile(Direction.Right, 1), ActionOrder.Immediate)
                    self.x_coord = -(tileWidth-(self.x_coord-tileWidth))
                else
                    self:delete()
                end
            end
        else
            if round(self.x_coord) < -tileWidth then
                if self:get_tile(Direction.Left, 1) then
                    self:teleport(self:get_tile(Direction.Left, 1), ActionOrder.Immediate)
                    self.x_coord = (tileWidth+(self.x_coord+tileWidth))
                else
                    self:delete()
                end
            end
        end
        self:set_offset(self.x_coord,self.y_coord)
    end
    seed.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-5,6)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        hit_fx:set_elevation(8*2)
        self:get_field():spawn(hit_fx, other:get_tile())
    end
    seed.collision_func = function(self)
        self:delete()
    end
    seed.battle_end_func = function(self)
        self:delete()
    end
    seed.delete_func = function(self)
        self:erase()
    end
    seed.can_move_to_func = function(tile)
        return true
    end
    field:spawn(seed, tile)
    return seed
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(48)
    self:set_float_shoe(false)
    self:set_air_shoe(false)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self:set_shadow(CHARACTER_SHADOW)
    self:show_shadow(true)
    self.damage = character_info.damage
    -- Apple Sam Specific
    self.damage_kidsseed = character_info.damage_kidsseed
    self.kidsseed_diff = character_info.kidsseed_diff
    self.move_frame1 = character_info.move_frame1
    self.move_frame2 = character_info.move_frame2
    -- Other Setup
    self.collision_available = true
    self.attacked = false
    -- entity will spawn with this animation.
    self.animation:set_state("PLAYER_IDLE")
    --self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    -- Can't be Dragged.
    self.guarding = true
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flash
        if ref.guarding and not statuses:has_element(Element.Fire) then
            statuses.damage = 0
        end
		return statuses
	end
    self.defense_rule.can_block_func = function(judge, attacker, defender)
        -- While inside the apple:
        -- If Spell is non-Fire Elemental, blocks only damage, but not the attack_func.
		local attacker_hit_props = attacker:copy_hit_props()
        if ref.guarding and not attacker_hit_props:has_element(Element.Fire) then
            judge:set_hit_sfx(GUARD_AUDIO)
        end
	end
    self:add_defense_rule(self.defense_rule)

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        --[[
        if ref:get_health() <= 0 then
            ref.animation:set_state("PLAYER_IDLE")
            local facing_away = ref:get_facing_away()
            local facing = ref:get_facing()
            local field = ref:get_field()
            local team = ref:get_team()
            local tiles = {
                Direction.join(facing_away, Direction.Up),
                facing_away,
                Direction.join(facing_away, Direction.Down),
                Direction.Up,
                Direction.Down,
                Direction.join(facing, Direction.Up),
                facing,
                Direction.join(facing, Direction.Down),
            }
            local allies = {}
            for i=1,#tiles do
                local tile = ref:get_tile(tiles[i],1)
                local query = function(c)
                    return c:get_id() ~= ref:get_id() and c:get_health()>0 and c:is_team(ref:get_team())
                end
                if tile and #tile:find_characters(query)>0 then
                    local ally = tile:find_characters(query)
                    for j=1,#ally do
                        table.insert(allies, ally[j])
                    end
                end
            end
            if #allies>0 then
                local ally = allies[1]
                if #allies>1 then
                    ally = allies[math.random(1,#allies)]
                end
                ref:hide()
                local apple = graphic_init("artifact", 0, 0, CHARACTER_TEXTURE, nil, CHARACTER_ANIMPATH, -3, "PLAYER_IDLE", Playback.Once, ref, ref:get_facing())
                apple:set_palette(ref:get_base_palette())
                apple:set_shadow(KIDSSEED_SHADOW)
                apple:show_shadow(true)
                apple.can_move_to_func = function(tile)
                    return true
                end
                field:spawn(apple, ref:get_tile())
                action_healing(ref, facing, field, ref:get_team(), ally, apple)
            end
			self:eject()
        end
        ]]
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print("Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print("Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil
    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_hole() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end

    self.move_times = math.random(3,5)
    self.move_frames = {
        self.move_frame1,
        self.move_frame2,
    }
    self.move_frame = self.move_frames[math.random(1,#self.move_frames)]
    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        if frame == 1 then
            debug_print("IDLE")
            self.animation:set_state("PLAYER_IDLE")
            self.move_frame = self.move_frames[math.random(1,#self.move_frames)]
        end
        if frame >= self.move_frame then
            self.set_state(states.MOVE)
        end
    end
    
    ---@param frame number
    self.action_move = function(frame)
        local facing_away = self:get_facing_away()
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 1 then
            self.animation:set_state("WARP_IN")
            self.prev_tile = self:get_tile()
            self.next_tile = nil
            -- Sticks closer to its allies.
            local allies = field:find_nearest_characters(self, function(c)
                return c:get_id() ~= self:get_id() and c:get_health()>0 and c:is_team(team)
            end)
            if #allies>0 then
                local ally = allies[1]
                if #allies>1 then
                    ally = allies[math.random(1,#allies)]
                end
                -- Ally data
                local ally_tile = ally:get_tile()
                local ally_x = ally_tile:x()
                local ally_y = ally_tile:y()
                --print(self:get_id()..": ("..ally_x..";"..ally_y..")")
                -- Self data
                local self_tile = self:get_tile()
                local self_x = self_tile:x()
                local self_y = self_tile:y()
                --print(self:get_id()..": ("..ally_x..";"..ally_y..")")
                --
                local dirs = {}
                if (ally_x == self_x+1 and ally_y == self_y) or (ally_x == self_x-1 and ally_y == self_y) then
                    dirs = {
                        Direction.Up,
                        Direction.Down,
                    }
                elseif (ally_x == self_x and ally_y == self_y+1) or (ally_x == self_x and ally_y == self_y-1) then
                    dirs = {
                        facing,
                        facing_away,
                    }
                elseif (ally_x > self_x and ally_y == self_y) then
                    dirs = {
                        Direction.Right
                    }
                elseif (ally_x < self_x and ally_y == self_y) then
                    dirs = {
                        Direction.Left
                    }
                elseif (ally_x == self_x and ally_y > self_y) then
                    dirs = {
                        Direction.Down
                    }
                elseif (ally_x == self_x and ally_y < self_y) then
                    dirs = {
                        Direction.Up
                    }
                elseif ally_x > self_x and ally_y > self_y then
                    dirs = {
                        Direction.Right,
                        Direction.Down,
                    }
                elseif ally_x < self_x and ally_y > self_y then
                    dirs = {
                        Direction.Left,
                        Direction.Down,
                    }
                elseif ally_x > self_x and ally_y < self_y then
                    dirs = {
                        Direction.Right,
                        Direction.Up,
                    }
                elseif ally_x < self_x and ally_y < self_y then
                    dirs = {
                        Direction.Left,
                        Direction.Up,
                    }
                end
                local tiles = {}
                for i=1,#dirs do
                    local tile = self:get_tile(dirs[i],1)
                    if tile and self.can_move_to_func(tile) then
                        table.insert(tiles, tile)
                    end
                end
                if #tiles>0 then
                    self.next_tile = tiles[math.random(1,#tiles)]
                end
            else
                local tiles = {}
                for i=0,3 do
                    -- first four directions
                    local tile = self:get_tile(math.floor(2^i),1)
                    if tile and self.can_move_to_func(tile) then
                        table.insert(tiles, tile)
                    end
                end
                if #tiles>0 then
                    self.next_tile = tiles[math.random(1,#tiles)]
                end
            end
            if self.next_tile then
                self.next_tile:reserve_entity_by_id(self:get_id())
            end
        end
        if frame == 7 then
            if self.next_tile then
                local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "3", Playback.Once, self, self:get_facing(), true, true, true)
                move_fx:set_elevation(16*2)
                field:spawn(move_fx, self.next_tile)
            end
        end
        if frame == 9 then
            if self.next_tile then
                self:teleport(self.next_tile, ActionOrder.Immediate)
            end
            self.animation:set_state("PLAYER_IDLE")
            local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -999, "2", Playback.Once, self, self:get_facing(), true, true, true)
            move_fx:set_elevation(16*2)
            field:spawn(move_fx, self:get_tile())
        end
        if frame >= 16 then
            self.move_times = self.move_times - 1
            if self.move_times <= 0 then
                self.move_times = math.random(3,5)
                self.set_state(states.ATTACK)
            else
                self.set_state(states.IDLE)
            end
        end
    end
    
    ---@param frame number
    self.action_attack = function(frame)
        local field = self:get_field()
        if frame == 1 then
            debug_print("ATTACK")
            self.animation:set_state("REVEAL")
        end
        if frame == 6 then
            self.guarding = false
        end
        if frame == 13 then
            self.animation:set_state("IDLE_OPENED")
        end
        if frame == 45-6 then
            self.counterable_component.timer = 20 -- Becomes counterable for 20 frames.
        end
        if frame == 45 then
            self.animation:set_state("ATTACK")
        end
        if frame == 54 then
            Engine.play_audio(KIDSSEED_AUDIO, AudioPriority.Immediate)
            create_kids_seed(self, self:get_facing(), self:get_field(), self.kidsseed_diff, self.damage_kidsseed, self:get_tile(self:get_facing(),1))
        end
        if frame == 98 then
            self.animation:set_state("HIDE")
        end
        if frame == 100 then
            self.guarding = true
        end
        if frame >= 110 then
            self.set_state(states.IDLE)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_move, [3] = self.action_attack }
    self.current_name = self:get_name()
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
    end
    self.battle_start_func = function()
    end
    self.delete_func = function()
        print("in delete_func")
        self.is_deleting = true
        self.animation:set_state("PLAYER_IDLE")
        local facing_away = self:get_facing_away()
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        local allies = directions_eight(self)
        if #allies>0 then
            local ally = allies[1]
            self:hide()
            local apple = graphic_init("artifact", 0, 0, CHARACTER_TEXTURE, nil, CHARACTER_ANIMPATH, -3, "PLAYER_IDLE", Playback.Once, self, self:get_facing())
            apple:set_palette(self:get_base_palette())
            apple:set_shadow(KIDSSEED_SHADOW)
            apple:show_shadow(true)
            apple.can_move_to_func = function(tile)
                return true
            end
            field:spawn(apple, self:get_tile())
            action_healing(self, facing, field, self:get_team(), ally, apple)
        end
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        --:breaking()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init