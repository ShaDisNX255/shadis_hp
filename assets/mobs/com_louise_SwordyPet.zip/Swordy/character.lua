-- Imports
---@type EnemyUtils
local enemy_utils = include("lib/enemy_utils.lua")

---@type BattleHelpers
local battle_helpers = include("lib/battle_helpers.lua")

local sword_spell = include("sword.lua")

local Chip1 = include("chips/EXE6-001-Recovery30/recovery/recovery.lua")
Chip1.recover_hp = 30

local Chip2 = include("chips/EXE6-002-Recovery50/recovery/recovery.lua")
Chip2.recover_hp = 50

local Chip3 = include("chips/EXE6-003-PanlSteal/steal/steal.lua")
Chip3.type = 1

local Chip4 = include("chips/EXE6-004-AreaSteal/steal/steal.lua")
Chip4.type = 2

local Chip5 = include("chips/EXE6-005-HolyPanel/stage/stage.lua")
Chip5.type = 1

local Chip6 = include("chips/EXE6-006-Sanctuary/stage/stage.lua")
Chip6.type = 2

local Chip7 = include("chips/EXE6-007-Invisible/invisible/invisible.lua")
local Chip8 = include("chips/EXE6-008-Shadow/entry.lua")
local Chip9 = include("chips/EXE6-009-Barrier/entry.lua")
local Chip10 = include("chips/EXE6-010-Barrier100/entry.lua")

local PET_BRIDGE_CHIPS = {
    ["__PETC1"]  = { id = 1,  card = Chip1,  label = "Recovery30", kind = "recovery", shortname = "Recov30", time_freeze = false },
    ["__PETC2"]  = { id = 2,  card = Chip2,  label = "Recovery50", kind = "recovery", shortname = "Recov50", time_freeze = false },
    ["__PETC3"]  = { id = 3,  card = Chip3,  label = "PanelSteal", kind = "support",  shortname = "PanlStel", time_freeze = true  },
    ["__PETC4"]  = { id = 4,  card = Chip4,  label = "AreaSteal",  kind = "support",  shortname = "AreaStel", time_freeze = true  },
    ["__PETC5"]  = { id = 5,  card = Chip5,  label = "HolyPanel",  kind = "support",  shortname = "HolyPanl", time_freeze = true  },
    ["__PETC6"]  = { id = 6,  card = Chip6,  label = "Sanctuary",  kind = "support",  shortname = "Snctuary", time_freeze = true  },
    ["__PETC7"]  = { id = 7,  card = Chip7,  label = "Invisible",  kind = "support",  shortname = "Invis",    time_freeze = true  },
    ["__PETC8"]  = { id = 8,  card = Chip8,  label = "Shadow",     kind = "support",  shortname = "Shadow",   time_freeze = true  },
    ["__PETC9"]  = { id = 9,  card = Chip9,  label = "Barrier",    kind = "support",  shortname = "Barrier",  time_freeze = true  },
    ["__PETC10"] = { id = 10, card = Chip10, label = "Barrier100", kind = "support",  shortname = "Barr100",  time_freeze = true  },
}

local function equip_bridge_chip(self, chip_def)
    if not chip_def then return false end

    self.battle_chip_amount = 1
    self.battle_chip = chip_def.card
    self.battle_chip_id = chip_def.id
    self.battle_chip_kind = chip_def.kind
    self.battle_chip_shortname = chip_def.shortname
    self.battle_chip_time_freeze = chip_def.time_freeze
    self.battle_chip_timer = 0

    print("SwordyPet bridge chip: "..tostring(chip_def.label))
    return true
end

local function get_pet_hp_cap(self)
    if self.pet_hp_cap ~= nil and self.pet_hp_cap > 0 then
        return self.pet_hp_cap
    end

    return self:get_max_health()
end

local PET_BRIDGE_LOOKUP = {}

for rank = 1, 20 do
    PET_BRIDGE_LOOKUP["__PETR"..tostring(rank)] = {
        chip = nil,
        rank = rank,
    }

    for _, chip_def in pairs(PET_BRIDGE_CHIPS) do
        PET_BRIDGE_LOOKUP["__PETC"..tostring(chip_def.id).."R"..tostring(rank)] = {
            chip = chip_def,
            rank = rank,
        }
    end
end

local function parse_pet_bridge_name(raw_name)
    raw_name = tostring(raw_name or "")

    local entry = PET_BRIDGE_LOOKUP[raw_name]
    if entry then
        return entry.chip, entry.rank
    end

    return PET_BRIDGE_CHIPS[raw_name], nil
end

local function clamp_pet_attack_rank(rank)
    rank = math.floor(tonumber(rank) or 1)
    if rank < 1 then rank = 1 end
    if rank > 20 then rank = 20 end
    return rank
end

local function apply_custom_pet_rank(character, pet_attack_rank)
    pet_attack_rank = clamp_pet_attack_rank(pet_attack_rank)

    character.pet_attack_rank = pet_attack_rank
    character.damage = pet_attack_rank * 5

    if pet_attack_rank >= 20 then
        character.move_speed = 32 -- old3 speed
        character:set_palette(Engine.load_texture(_folderpath .. "V3.png"))
    elseif pet_attack_rank >= 11 then
        character.move_speed = 42 -- old2 speed
        character:set_palette(Engine.load_texture(_folderpath .. "V2.png"))
    end

    character.action_move = enemy_utils.move_toward_enemy_row(character, character.move_speed, attack_logic, attack_logic)
end

local function try_use_pet_chip(character)
    if not character.battle_chip or (character.battle_chip_amount or 0) <= 0 then
        return false
    end

    local hp_cap = get_pet_hp_cap(character)
    local should_use = false

    if character.battle_chip_kind == "recovery" then
        should_use = character:get_health() <= (hp_cap - (hp_cap * 75) / 100)
    else
        should_use = character.battle_chip_start == true
    end

    if not should_use then
        return false
    end

    character.battle_chip_amount = character.battle_chip_amount - 1

    local chip_action = character.battle_chip.card_create_action(character)
    local props = chip_action:copy_metadata()
    local chip_runtime = nil

    props.shortname = character.battle_chip_shortname or "PetChip"
    props.damage = 0
    props.time_freeze = character.battle_chip_time_freeze == true
    props.element = Element.None
    props.can_boost = false

    if character.battle_chip_kind == "recovery" then
        chip_runtime = {
            pet_hp_cap = get_pet_hp_cap(character)
        }
    end

    chip_action = character.battle_chip.card_create_action(character, props, chip_runtime)
    chip_action:set_metadata(props)

    character:card_action_event(chip_action, ActionOrder.Voluntary)

    character.battle_chip_start = false

    if character.battle_chip_amount <= 0 then
        character.battle_chip = nil
        character.battle_chip_id = 0
        character.battle_chip_kind = nil
        character.battle_chip_shortname = nil
        character.battle_chip_time_freeze = false
    end

    character.set_current_action(character.action_wait_chip)
    return true
end

-- Animations, Textures and Sounds
local CHARACTER_ANIMATION = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.png")

local longswords = 0

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Set up character meta
    self:set_palette(Engine.load_texture(character_info.palette))
    self:set_name(character_info.name)
    self.name = character_info.name
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage = (character_info.damage)
    self:set_element(character_info.element)
    self:set_explosion_behavior(4, 1, false)
    self.animation:set_state("SPAWN")
    self.move_speed = character_info.move_speed
    self.dash_speed = 10
    self.battle_chip_start = false
    self.battle_chip_timer = 0
    self.battle_chip_amount = 0
    self.battle_chip = nil
    self.battle_chip_id = 0
    self.pet_hp_cap = nil
    self.battle_chip_kind = nil
    self.battle_chip_shortname = nil
    self.battle_chip_time_freeze = false


    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)

    --Swordy Sword node
    self.swordNode = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.swordNode:set_texture(Engine.load_texture(_folderpath .. "sword.png")) --Just set their texture...
    self.swordNode_anim = Engine.Animation.new(_folderpath .. "sword.animation") --And they have no get_animation, so we create one...
    self.swordNode:set_layer(1) --Set their layer, they're already a sprite...
    self.swordNode_anim:set_state("SPAWN")
    self.swordNode_anim:refresh(self.swordNode)
    self.swordNode:enable_parent_shader(true)

    self.battle_start_func = function()
        longswords = 0
        if self.battle_chip_kind ~= "recovery" then
            self.battle_chip_start = true
        end
    end

    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.swordNode_anim:update(dt, ref.swordNode)
    end
    self:register_component(self.animate_component)
    -- actions for states


    self.action_move = enemy_utils.move_toward_enemy_row(self, self.move_speed, attack_logic, attack_logic)
    self.action_wait = enemy_utils.wait
    self.action_wait_chip = enemy_utils.wait_for_frames(self, 20, function()
        self.set_current_action(self.action_move)
    end)
    self.action_wait_dash = enemy_utils.wait_for_frames(self, self.dash_speed, function()
        self.set_current_action(self.action_move)
    end)


    self.play_idle_anim = function()
        self.animation:set_state("IDLE")
        self.swordNode_anim:set_state("IDLE")
        self.swordNode_anim:set_playback(Playback.Loop)
        self.animation:set_playback(Playback.Loop)
    end

    self.on_spawn_func = function(self, spawn_tile)
        local current_name = nil
        local forced_chip = nil
        local pet_attack_rank = nil

        pcall(function()
            current_name = self:get_name()
        end)

        forced_chip, pet_attack_rank = parse_pet_bridge_name(current_name)

        self.pet_hp_cap = self:get_health()

        if pet_attack_rank ~= nil then
            apply_custom_pet_rank(self, pet_attack_rank)
        end

        self:set_name(self.name or character_info.name)

        print("SwordyPet current_name = "..tostring(current_name))
        print("SwordyPet forced_chip = "..tostring(forced_chip and forced_chip.id or nil))
        print("SwordyPet pet_hp_cap = "..tostring(self.pet_hp_cap))
        print("SwordyPet pet_attack_rank = "..tostring(pet_attack_rank))

        if forced_chip then
            equip_bridge_chip(self, forced_chip)
        end
    end

    local old_battle_end_func = self.battle_end_func
    self.battle_end_func = function(self)
        local hp = "?"
        local deleted = "?"

        pcall(function() hp = tostring(self:get_health()) end)
        pcall(function() deleted = tostring(self:is_deleted()) end)

        print("[PET DBG] SwordyPet battle_end hp=" .. hp .. " deleted=" .. deleted)

        if old_battle_end_func then
            old_battle_end_func(self)
        end
    end

    local old_delete_func = self.delete_func
    self.delete_func = function(self)
        local hp = "?"
        local deleted = "?"

        pcall(function() hp = tostring(self:get_health()) end)
        pcall(function() deleted = tostring(self:is_deleted()) end)

        print("[PET DBG] SwordyPet delete hp=" .. hp .. " deleted=" .. deleted)

        if old_delete_func then
            old_delete_func(self)
        end
    end

    enemy_utils.use_enemy_framework(self)
    self.init_func = function()
        self.set_current_action(self.action_move)
        self.play_idle_anim()
    end
end

function attack_logic(character)
    if try_use_pet_chip(character) then
        return
    end
    local target_enemy = battle_helpers.find_target(character)
    local target_enemy_x = target_enemy:get_tile():x()
    local character_x = character:get_tile():x()
    local dir = character:get_facing_away()
    local end_lag = 0
    if (target_enemy_x < character_x) then
        dir = Direction.Left
    elseif (target_enemy_x > character_x) then
        dir = Direction.Right
    else
        end_lag = 30
    end
    local target_tile = character:get_tile(dir, 1)
    local sword_damage = character.damage

    if (
        battle_helpers.is_tile_free_for_movement(target_tile, character) and not should_widesword(character, target_tile)
        ) then
        character:slide(target_tile, frames(character.dash_speed), frames(end_lag), ActionOrder.Involuntary, function()
            target_tile:reserve_entity_by_id(character:get_id())
        end)
        character.set_current_action(character.action_wait_dash)
    else
        if (should_widesword(character, target_tile)) then
            character.animation:set_state("WIDESWORD")
            character.swordNode_anim:set_state("WIDESWORD")
            character.animation:on_frame(2, function()
                character:toggle_counter(true)
            end)
            character.animation:on_frame(4, function()
                character:toggle_counter(false)
                sword_spell.create_slash(character, sword_damage, "WIDE")
            end)
            character.animation:on_complete(function()
                character.play_idle_anim()
                character.set_current_action(character.action_move)
            end)
            character.set_current_action(character.action_wait)
        elseif (
            tile_has_enemies(target_tile:get_tile(character:get_facing(), 1), character) or
                tile_has_enemies(target_tile:get_tile(character:get_facing(), 2), character)) then
            character.animation:set_state("LONGSWORD")
            character.swordNode_anim:set_state("LONGSWORD")
            character.animation:on_frame(6, function()
                character:toggle_counter(true)
            end)
            character.animation:on_frame(8, function()
                character:toggle_counter(false)
                sword_spell.create_slash(character, sword_damage, "LONG")
                longswords = longswords + 1
            end)
            character.animation:on_complete(function()
                character.play_idle_anim()

                if (longswords >= 3) then
                    longswords = 0
                end

                character.set_current_action(character.action_move)
            end)
            character.set_current_action(character.action_wait)
        else
            character.set_current_action(character.action_move)
        end
    end
end

function should_widesword(character, center_tile)
    local tile_up = center_tile:get_tile(Direction.Up, 1)
    local tile_down = center_tile:get_tile(Direction.Down, 1)
    return tile_has_enemies(center_tile, character) or tile_has_enemies(tile_up, character) or
        tile_has_enemies(tile_down, character)
end

function can_grab_more_area(user)
    local x_max = 5
    if (user:get_facing() == Direction.Left) then
        x_max = 2
    end
    if (user:get_field():tile_at(x_max, 2):get_team() == user:get_team()) then
        return false
    end
    return true
end

---@param tile Tile
---@param user Entity
function tile_has_enemies(tile, user)
    if not tile then return false end
    local enemies = tile:find_characters(function(char)
        if char:get_team() ~= user:get_team() then
            return true
        end
        return false
    end)
    return #enemies >= 1
end

return package_init
