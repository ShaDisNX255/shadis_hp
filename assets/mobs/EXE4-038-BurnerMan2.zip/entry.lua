local package_id = "com.OFC.mob.EXE4-038-BurnerMan2"
local character_id = "com.OFC.char.EXE4-038-BurnerMan0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("BurnerMan V2 (EXE4)")
    package:set_description("Test fight with\nBurnerMan V2\nfrom Rockman EXE4")
    package:set_speed(2)
    package:set_attack(80)
    package:set_health(1100)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    print("")
    ----
    local battlemode = "RANDOM" --[[
        RANDOM - random mode
        NORMAL - Park Area 2
        TOURNAMENT - The Eagle/Hawk Tournament
    ]]
    if battlemode == "RANDOM" then
        print("Battle Mode Randomizer ON")
    else
        print("Battle Mode Randomizer OFF")
    end
    local r = math.random(1,2)
    -- Set background --
    if     battlemode == "NORMAL"     or (battlemode == "RANDOM" and r==1) then
        print("Current area:","Park Area 2")
        local texPath = _modpath.."exe4-parkarea.png"
        local animPath = _modpath.."exe4-parkarea.animation"
        mob:set_background(texPath, animPath, 0.2, 0.19)
    elseif battlemode == "TOURNAMENT" or (battlemode == "RANDOM" and r==2) then
        print("Current area:","Aerial Stadium")
        --print("Current area:","Cielo NB Machine's Cyber")
        local texPath = _modpath.."exe4-tournamentb.png"
        local animPath = _modpath.."exe4-tournamentb.animation"
        mob:set_background(texPath, animPath, 0.12, 0)
    end
    -- Set music --
    if     battlemode == "NORMAL"     or (battlemode == "RANDOM" and r==1) then
        print("Now playing:","Fighting Oneself")
        print('(from "Rockman EXE4: Tournament Red Sun/Blue Moon")')
        local musicPath = _modpath.."exe4-boss.ogg"
        mob:stream_music(musicPath, 9644, 47934)
    elseif battlemode == "TOURNAMENT" or (battlemode == "RANDOM" and r==2) then
        print("Now playing:","Battle Pressure")
        print('(from "Rockman EXE4: Tournament Red Sun/Blue Moon")')
        local musicPath = _modpath.."exe4-tournament.ogg"
        mob:stream_music(musicPath, 6898, 58550)
    end
    -- Spawn mob --
    mob:create_spawner(character_id, Rank.V2):spawn_at(6,2)
    mob:enable_boss_battle()
    ----
    print("")
end