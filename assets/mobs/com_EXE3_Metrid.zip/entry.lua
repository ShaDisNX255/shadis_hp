local package_id = "com.EXE3.Metrid"
local character_id = "com.EXE3.Metrid.Enemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Metrid")
    package:set_description("I don't care about the NPCs, I CAST METEOR.")
    package:set_speed(1)
    package:set_attack(40)
    package:set_health(150)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    mob:create_spawner(character_id, Rank.V1):spawn_at(4, 1)
    mob:create_spawner(character_id, Rank.V2):spawn_at(4, 3)
    mob:create_spawner(character_id, Rank.V3):spawn_at(6, 1)
    mob:create_spawner(character_id, Rank.SP):spawn_at(6, 3)
    -- mob:create_spawner(character_id, Rank.NM):spawn_at(5, 2)
end