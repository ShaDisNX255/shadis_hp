--[[

    CUSTOM BEHAVIOR:
    If Rooted, can't move.
    If Confused or Blind while looking for the player, becomes slower and can't find the player.
    If Confused or Blind while attacking, appears from wrong edge tiles.

]]
local is_counterable = true
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"

local FLAMES_TEXTURE = Engine.load_texture(_folderpath.."gfx/flames.grayscaled.png")
local FLAMES_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/flames.png")
local FLAMES_ANIMPATH = _folderpath.."gfx/flames.animation"

local DASHATTACK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE3_96.ogg", true)

local WindPush = include("libs/WindPush.lua")

-- possible states for character
local states = { IDLE = 1, CHARGE = 2, ATTACK = 3, RETURN = 4 }

local Chip1 = include("chips/EXE6-001-Recovery30/recovery/recovery.lua")
Chip1.recover_hp = 30

local Chip2 = include("chips/EXE6-002-Recovery50/recovery/recovery.lua")
Chip2.recover_hp = 50

local Chip3 = include("chips/EXE6-003-PanlSteal/steal/steal.lua")
Chip3.type = 1

local Chip4 = include("chips/EXE6-004-AreaSteal/steal/steal.lua")
Chip4.type = 2

local Chip5 = include("chips/EXE6-005-HolyPanel/stage/stage.lua")
Chip5.type = 1

local Chip6 = include("chips/EXE6-006-Sanctuary/stage/stage.lua")
Chip6.type = 2

local Chip7 = include("chips/EXE6-007-Invisible/invisible/invisible.lua")
local Chip8 = include("chips/EXE6-008-Shadow/entry.lua")
local Chip9 = include("chips/EXE6-009-Barrier/entry.lua")
local Chip10 = include("chips/EXE6-010-Barrier100/entry.lua")

local PET_BRIDGE_CHIPS = {
    ["__PETC1"]  = { id = 1,  card = Chip1,  label = "Recovery30", kind = "recovery", shortname = "Recov30", time_freeze = false },
    ["__PETC2"]  = { id = 2,  card = Chip2,  label = "Recovery50", kind = "recovery", shortname = "Recov50", time_freeze = false },
    ["__PETC3"]  = { id = 3,  card = Chip3,  label = "PanelSteal", kind = "support", shortname = "PanlStel", time_freeze = true },
    ["__PETC4"]  = { id = 4,  card = Chip4,  label = "AreaSteal",  kind = "support", shortname = "AreaStel", time_freeze = true },
    ["__PETC5"]  = { id = 5,  card = Chip5,  label = "HolyPanel",  kind = "support", shortname = "HolyPanl", time_freeze = true },
    ["__PETC6"]  = { id = 6,  card = Chip6,  label = "Sanctuary",  kind = "support", shortname = "Snctuary", time_freeze = true },
    ["__PETC7"]  = { id = 7,  card = Chip7,  label = "Invisible",  kind = "support", shortname = "Invis", time_freeze = true },
    ["__PETC8"]  = { id = 8,  card = Chip8,  label = "Shadow",     kind = "support", shortname = "Shadow", time_freeze = true },
    ["__PETC9"]  = { id = 9,  card = Chip9,  label = "Barrier",    kind = "support", shortname = "Barrier", time_freeze = true },
    ["__PETC10"] = { id = 10, card = Chip10, label = "Barrier100", kind = "support", shortname = "Barr100", time_freeze = true },
}

local PET_BRIDGE_LOOKUP = {}

for rank = 1, 20 do
    PET_BRIDGE_LOOKUP["__PETR"..tostring(rank)] = {
        chip = nil,
        rank = rank,
    }

    for _, chip_def in pairs(PET_BRIDGE_CHIPS) do
        PET_BRIDGE_LOOKUP["__PETC"..tostring(chip_def.id).."R"..tostring(rank)] = {
            chip = chip_def,
            rank = rank,
        }
    end
end

local function equip_bridge_chip(self, chip_def)
    if not chip_def then return false end

    self.battle_chip_amount = 1
    self.battle_chip = chip_def.card
    self.battle_chip_id = chip_def.id
    self.battle_chip_kind = chip_def.kind
    self.battle_chip_shortname = chip_def.shortname
    self.battle_chip_time_freeze = chip_def.time_freeze
    self._pet_chip_wait = 0

    print("FishyPet bridge chip: "..tostring(chip_def.label))
    return true
end

local function get_pet_hp_cap(self)
    if self.pet_hp_cap ~= nil and self.pet_hp_cap > 0 then
        return self.pet_hp_cap
    end

    return self:get_max_health()
end

local function parse_pet_bridge_name(raw_name)
    raw_name = tostring(raw_name or "")

    local entry = PET_BRIDGE_LOOKUP[raw_name]
    if entry then
        return entry.chip, entry.rank
    end

    return PET_BRIDGE_CHIPS[raw_name], nil
end

local function clamp_pet_attack_rank(rank)
    rank = math.floor(tonumber(rank) or 1)
    if rank < 1 then rank = 1 end
    if rank > 20 then rank = 20 end
    return rank
end

local function apply_custom_pet_rank(self, pet_attack_rank)
    pet_attack_rank = clamp_pet_attack_rank(pet_attack_rank)

    local damage = pet_attack_rank * 5
    self.pet_attack_rank = pet_attack_rank
    self:set_element(Element.None)
    self.damage = damage
    self.damage_tosshin = damage
    self.damage_honoo = damage

    -- Every Fishy pet evolution performs exactly one attack pass.
    self.max_dashes = 1
    self.dashes = 1

    local palette_rank = 0
    self.frames_atk = 10
    self.frames_move = 64

    if pet_attack_rank >= 20 then
        palette_rank = 2
        self.frames_atk = 6
        self.frames_move = 54
    elseif pet_attack_rank >= 11 then
        palette_rank = 1
        self.frames_atk = 7
        self.frames_move = 58
    end

    local palette = Engine.load_texture(_folderpath.."gfx/palette/battle-"..tostring(palette_rank)..".png")
    self:store_base_palette(palette)
    self:set_palette(self:get_base_palette())
    self:set_shadow(Engine.load_texture(_folderpath.."gfx/shadow-"..tostring(palette_rank)..".png"))
end

local function try_use_pet_chip(self)
    if not self.battle_chip or (self.battle_chip_amount or 0) <= 0 then
        return false
    end

    if self._pet_chip_wait > 0 then
        return false
    end

    -- Do not interrupt Fishy's charge, dash, return, or vertical movement.
    if self.started and (self.state ~= states.IDLE or self.slide_component ~= nil) then
        return false
    end

    local hp_cap = get_pet_hp_cap(self)
    local should_use = false

    if self.battle_chip_kind == "recovery" then
        should_use = self:get_health() <= (hp_cap - (hp_cap * 75) / 100)
    else
        should_use = self.battle_chip_start == true
    end

    if not should_use then
        return false
    end

    self.battle_chip_amount = self.battle_chip_amount - 1

    local chip_action = self.battle_chip.card_create_action(self)
    local props = chip_action:copy_metadata()
    local chip_runtime = nil

    props.shortname = self.battle_chip_shortname or "PetChip"
    props.damage = 0
    props.time_freeze = self.battle_chip_time_freeze == true
    props.element = Element.None
    props.can_boost = false

    if self.battle_chip_kind == "recovery" then
        chip_runtime = {
            pet_hp_cap = get_pet_hp_cap(self)
        }
    end

    chip_action = self.battle_chip.card_create_action(self, props, chip_runtime)
    chip_action:set_metadata(props)
    self:card_action_event(chip_action, ActionOrder.Voluntary)

    self.battle_chip_start = false
    self._pet_chip_wait = 20
    self._pet_ai_pause = 20

    if self.battle_chip_amount <= 0 then
        self.battle_chip = nil
        self.battle_chip_id = 0
        self.battle_chip_kind = nil
        self.battle_chip_shortname = nil
        self.battle_chip_time_freeze = false
    end

    return true
end

function debug_print(id,str)
    if print_debug then
        print("[Kiorushin] (ID: "..id:get_id()..") "..str)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_flames(user, damage)
    local tile = user:get_tile()
    if not tile or tile:is_hole() then return end
    local facing = user:get_facing()
    local field = user:get_field()
    local spell = graphic_init("spell", 0, 0, FLAMES_TEXTURE, FLAMES_PALETTE, FLAMES_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :no_counter()
        :elem(Element.Fire)
        :from(user:get_context())
    )
    spell.frames = 1
    spell.update_func = function(self)
        tile:attack_entities(self)
        if self.frames >= 180 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    spell.collision_func = function(self)
        self:delete()
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell,tile)
    return spell
end

local function move_slide(self, facing, direction, frames1, reserving)
    local res_tile = self:get_tile(direction,1)
    if reserving then res_tile:reserve_entity_by_id(self.reserving_obstacle:get_id()) end
    WindPush.make_entity_immune_to_status(self)
    self.slide_component = Battle.Component.new(self, Lifetimes.Local)
    local cur_tile = 1
    local self_tile = self:get_tile()
    local tileWidthO = self_tile:width()
    local tileHeightO = self_tile:height()
    local tileWidth = tileWidthO/2
    local tileHeight = tileHeightO/2 - tileHeightO/10
    local offset_x = self:get_offset().x
    local offset_y = self:get_offset().y
    local wait_delay = 0
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    local create_mob_move = function()
        local move_fx = graphic_init("artifact", self:get_offset().x, self:get_offset().y, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "2", Playback.Once, self, self:get_facing(), true, false, true)
        move_fx:set_elevation(32*2)
        self:get_field():spawn(move_fx,self:get_tile())
        self.set_state(states.RETURN)
    end
    local cancel_move = function()
        WindPush.remove_immunity(self)
        self.slide_component:eject()
        self.slide_component = nil
        self:set_offset(0,0)
        if reserving then res_tile:remove_entity_by_id(self.reserving_obstacle:get_id()) end
    end
    self.slide_component.update_func = function()
        --debug_print(self,"slide_component update_func()")
        if self:is_bubbled() then
            cancel_move()
            return
        end
        if self:is_stunned() or self:is_frozen() or self:is_rooted() or self.is_deleting then return end
        ----
        local frames = frames1
        if self:is_confused() or self:is_blind() then
            frames = math.floor(frames1*2)
        end
        local round_x = 0
        local round_y = 0
        if direction == Direction.Up then
            offset_y = offset_y - tileHeightO/frames
            round_y = round(offset_y)
            if round_y <= 0 and cur_tile == 2 then
                if self:get_element() == Element.Fire and not reserving then create_flames(self, self.damage_honoo) end
                cancel_move()
                return
            end
            if round_y < -tileHeight and cur_tile == 1 then
                local t = self:get_tile(Direction.Up,1)
                if not self.can_move_to_func(t) and not reserving then
                    create_mob_move()
                    cancel_move()
                    return
                else
                    self:teleport(t, ActionOrder.Immediate)
                    round_y = round_y+tileHeight*2
                    offset_y = round_y
                    cur_tile = 2
                end
            end
        elseif direction == Direction.Down then
            offset_y = offset_y + tileHeightO/frames
            round_y = round(offset_y)
            if round_y >= 0 and cur_tile == 2 then
                if self:get_element() == Element.Fire and not reserving then create_flames(self, self.damage_honoo) end
                cancel_move()
                return
            end
            if round_y > tileHeight and cur_tile == 1 then
                local t = self:get_tile(Direction.Down,1)
                if not self.can_move_to_func(t) and not reserving then
                    create_mob_move()
                    cancel_move()
                    return
                else
                    self:teleport(t, ActionOrder.Immediate)
                    round_y = round_y-tileHeight*2
                    offset_y = round_y
                    cur_tile = 2
                end
            end
        elseif direction == Direction.Left then
            offset_x = offset_x - tileWidthO/frames
            round_x = round(offset_x)
            if round_x <= 0 and cur_tile == 2 then
                if self:get_element() == Element.Fire and not reserving then create_flames(self, self.damage_honoo) end
                cancel_move()
                return
            end
            if round_x < -tileWidth and cur_tile == 1 then
                local t = self:get_tile(Direction.Left,1)
                if not self.can_move_to_func(t) and not reserving then
                    create_mob_move()
                    cancel_move()
                    return
                else
                    self:teleport(t, ActionOrder.Immediate)
                    round_x = round_x+tileWidth*2
                    offset_x = round_x
                    cur_tile = 2
                end
            end
        elseif direction == Direction.Right then
            offset_x = offset_x + tileWidthO/frames
            round_x = round(offset_x)
            if round_x >= 0 and cur_tile == 2 then
                if self:get_element() == Element.Fire and not reserving then create_flames(self, self.damage_honoo) end
                cancel_move()
                return
            end
            if round_x > tileWidth and cur_tile == 1 then
                local t = self:get_tile(Direction.Right,1)
                if not self.can_move_to_func(t) and not reserving then
                    create_mob_move()
                    cancel_move()
                    return
                else
                    self:teleport(t, ActionOrder.Immediate)
                    round_x = round_x-tileWidth*2
                    offset_x = round_x
                    cur_tile = 2
                end
            end
        elseif direction == nil then
            wait_delay = wait_delay + 1
            if wait_delay >= frames1 then
                self.slide_component:eject()
                self.slide_component = nil
            end
            return
        end
        self:set_offset(round_x,round_y)
        --print("OFFSET:",self:get_offset().x,self:get_offset().y)
    end
    self:register_component(self.slide_component)
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.anim = self:get_animation()
    self.anim:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(44)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())
    self:set_shadow(Engine.load_texture(_folderpath.."gfx/shadow-"..self:get_rank()..".png"))
    self:show_shadow(true)
    self.damage = character_info.damage
    -- Cannodumb Specific
    self.damage_tosshin = character_info.damage_tosshin
    self.damage_honoo = character_info.damage_honoo
    self.frames_move = character_info.frames_move
    self.frames_atk = character_info.frames_atk
    self.max_dashes = character_info.dashes
    self.dashes = character_info.dashes
    -- Other Setup
    self.collision_available = true
    -- Track tiles already struck during the current dash. The original Fishy
    -- spawned a new hitbox every update frame while occupying an enemy tile.
    self.hit_tiles_this_dash = {}
    -- entity will spawn with this animation.
    self.anim:set_state("PLAYER_IDLE")
    --self.anim:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false

    self.battle_chip_start = false
    self.battle_chip_amount = 0
    self.battle_chip = nil
    self.battle_chip_id = 0
    self.pet_hp_cap = nil
    self.battle_chip_kind = nil
    self.battle_chip_shortname = nil
    self.battle_chip_time_freeze = false
    self._pet_chip_wait = 0
    self._pet_ai_pause = 0

    self.move_direction = Direction.Down
    self.move_counter = 0
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    local ref = self
    self.defense_rule.filter_statuses_func = function(statuses)
        if self.state == states.ATTACK then
            -- Fishy receives one third damage only during its attack dash.
            -- This changes the defender-local HitProps copy, not the attacker.
            local incoming_damage = tonumber(statuses.damage) or 0
            if incoming_damage > 0 then
                statuses.damage = math.max(1, math.ceil(incoming_damage * 2 / 3))
            end
            statuses.flags = statuses.flags & ~Hit.Drag
        elseif self.slide_component ~= nil then
            statuses.flags = statuses.flags & ~Hit.Drag
        end
        statuses.flags = statuses.flags & ~Hit.Flinch
        statuses.flags = statuses.flags & ~Hit.Flash
        return statuses
    end
    self:add_defense_rule(self.defense_rule)
    self.reserving_obstacle = Battle.Obstacle.new(self:get_team())

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 and is_counterable then
            debug_print(ref,"COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print(ref,"Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print(ref,"Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil
    self.prev_tile = nil
    self.next_tile = nil

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_edge() and self.state ~= states.ATTACK then
            return false
        end
        if tile:get_team() ~= self:get_team() and self.state ~= states.ATTACK then
            return false
        end
        -- Can't move to reserved tiles.
        if(tile:is_reserved({self:get_id(),self.reserving_obstacle:get_id()})) and self.state ~= states.ATTACK then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if self:is_teleporting() then
            return true
        else
            return not check_obstacles(tile) and not check_characters_true_team(tile,self)
        end
    end

    self.do_once = true
    self.begin_loop_position = 0
    self.original_tile = nil
    self.current_name = nil
    ---@param frame number
    self.action_idle = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        --[[
        if frame == 1 then
            if self.move_direction == Direction.Down then
                self.anim:set_state("MOVE_DOWN")
            else
                self.anim:set_state("MOVE_UP")
            end
        end]]
        if self.anim:get_state() == "STOP_DOWN" or self.anim:get_state() == "STOP_UP" then
            self.anim:on_complete(function()
                if self.anim:get_state() == "STOP_DOWN" then
                    self.anim:set_state("MOVE_UP")
                elseif self.anim:get_state() == "STOP_UP" then
                    self.anim:set_state("MOVE_DOWN")
                end
            end)
            return
        end
        if not self.slide_component then
            if not self:is_confused() and not self:is_blind() and not self:is_rooted() then
                for i=1,field:width() do
                    local t = self:get_tile(facing,i)
                    if t and not t:is_edge() and check_characters(t,self) then
                        self.original_tile = self:get_tile()
                        self.set_state(states.CHARGE)
                        return
                    end
                end
            end
            local tile = self:get_tile(self.move_direction,1)
            if not self.can_move_to_func(tile) then
                --print("CAN MOVE")
                self.move_direction = Direction.reverse(self.move_direction)
                tile = self:get_tile(self.move_direction,1)
                if not self.can_move_to_func(tile) then
                    self.anim:set_state("PLAYER_IDLE")
                else
                    if self.move_direction == Direction.Down then
                        self.anim:set_state("STOP_UP")
                    else
                        self.anim:set_state("STOP_DOWN")
                    end
                end
            else
                if self.move_direction == Direction.Down and self.anim:get_state() ~= "MOVE_DOWN" then
                    self.anim:set_state("MOVE_DOWN")
                elseif self.move_direction == Direction.Up and self.anim:get_state() ~= "MOVE_UP" then
                    self.anim:set_state("MOVE_UP")
                end
                move_slide(self, facing, self.move_direction, self.frames_move, true)
            end
        end
    end
    ---@param frame number
    self.action_charge = function(frame)
        if frame == 1 then
            debug_print(self,"action_charge()")
            self.anim:set_state("CHARGE")
            self.original_tile:reserve_entity_by_id(self.reserving_obstacle:get_id())
            self.counterable_component.timer = 20 -- Becomes counterable for 20 frames.
        end
        if frame >= 15 then
            self.dashes = self.max_dashes
            --WindPush.make_entity_immune_to_status(self)
            self.set_state(states.ATTACK)
        end
    end
    ---@param frame number
    self.action_attack = function(frame)
        local facing = self:get_facing()
        local field = self:get_field()
        local team = self:get_team()
        if frame == 1 then
            debug_print(self,"action_attack()")
            --print("attack tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
            self.anim:set_state("ATTACK")
            self.anim:set_playback(Playback.Loop)
            -- A new dash may strike every occupied enemy tile once.
            self.collision_available = true
            self.hit_tiles_this_dash = {}
            Engine.play_audio(DASHATTACK_AUDIO, AudioPriority.Immediate)
            self.dashes = self.dashes - 1
            self.begin_loop_position = 0
            if facing == Direction.Left then self.begin_loop_position = field:width()+1 end
        end
        if not self.slide_component then
            if self:get_tile():is_edge() and self:get_tile():x() ~= self.begin_loop_position then
                if self.dashes > 0 then
                    local tile = field:tile_at(self.begin_loop_position, self:get_tile():y())
                    local enemies = field:find_characters(function(c)
                        return c:get_health()>0 and not c:is_team(team)
                    end)
                    if #enemies>0 and not self:is_confused() and not self:is_blind() then
                        tile = field:tile_at(self.begin_loop_position, enemies[1]:get_tile():y())
                    end
                    self:teleport(tile, ActionOrder.Immediate)
                    self:set_offset(0,0)
                    self.set_state(states.ATTACK)
                    return
                else
                    self.set_state(states.RETURN)
                    return
                end
            end
            local tile = self:get_tile(facing,1)
            --if self.can_move_to_func(tile) then
            --    print("CAN MOVE FORWARD")
                move_slide(self, facing, facing, self.frames_atk)
            --end
        end
    end
    self.action_return = function(frame)
        if frame == 1 then
            debug_print(self,"action_return()")
            self.anim:set_state("ATTACK")
            self.anim:set_playback(Playback.Loop)
            self:set_elevation(55*3*2)
            self:set_offset(0,0)
            self:toggle_hitbox(false)
            self:set_name("PASS_THROUGH")
            --self:teleport(self.original_tile, ActionOrder.Immediate)
            local orig_tile = self.original_tile
            if not self.original_tile then orig_tile = self:get_tile() end
            orig_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
            self:get_tile():remove_entity_by_id(self:get_id())
            orig_tile:add_entity(self)
            --WindPush.remove_immunity(self)
        end
        if self:get_elevation() > 0 then
            self:set_elevation(self:get_elevation()-3*2)
            if self:get_elevation() <= 10 then
                self:set_name(self.current_name)
                self:toggle_hitbox(true)
            end
        else
            self:set_elevation(0)
        end
        if frame >= 86 then
            self.set_state(states.IDLE)
        end
    end
    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    -- actions for states
    local actions = { [1] = self.action_idle, [2] = self.action_charge, [3] = self.action_attack, [4] = self.action_return }
    self.on_spawn_func = function(self)
        local field = self:get_field()
        local bridge_name = nil
        local forced_chip = nil
        local pet_attack_rank = nil

        debug_print(self,"on_spawn_func called")

        pcall(function()
            bridge_name = self:get_name()
        end)

        forced_chip, pet_attack_rank = parse_pet_bridge_name(bridge_name)

        -- Battle pets are normally team 2 on the left side, facing right.
        if self:get_team() == 2 then
            self:set_facing(Direction.Right)
        else
            self:set_facing(Direction.Left)
        end

        -- The encounter mutator has already lowered current HP from the
        -- package's 100 HP ceiling to this individual pet's trained HP.
        self.pet_hp_cap = self:get_health()

        if pet_attack_rank ~= nil then
            apply_custom_pet_rank(self, pet_attack_rank)
        end

        self:set_name(character_info.name)
        self.current_name = character_info.name
        field:spawn(self.reserving_obstacle,0,0)

        print("FishyPet bridge_name = "..tostring(bridge_name))
        print("FishyPet forced_chip = "..tostring(forced_chip and forced_chip.id or nil))
        print("FishyPet pet_hp_cap = "..tostring(self.pet_hp_cap))
        print("FishyPet pet_attack_rank = "..tostring(pet_attack_rank))

        if forced_chip then
            equip_bridge_chip(self, forced_chip)
        end
    end
    self.battle_start_func = function()
        debug_print(self,"battle_start_func called")
        if self.battle_chip_kind ~= "recovery" then
            self.battle_chip_start = true
        end
    end
    self.delete_func = function()
        debug_print(self,"delete_func called")
        self.is_deleting = true
        self.reserving_obstacle:delete()
    end
    local chip_component = Battle.Component.new(self, Lifetimes.Battlestep)
    chip_component.update_func = function()
        if self:is_deleted() then return end

        if self._pet_chip_wait > 0 then
            self._pet_chip_wait = self._pet_chip_wait - 1
            return
        end

        try_use_pet_chip(self)
    end
    self:register_component(chip_component)

    self.update_func = function()
        if self._pet_ai_pause > 0 then
            self._pet_ai_pause = self._pet_ai_pause - 1
            return
        end

        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :from(user:get_context())
        :elem(Element.None)
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if not user.collision_available or not check_characters(t, user) then
        return
    end

    -- Fishy remains assigned to a destination tile for several animation
    -- frames. Strike that tile only once during this dash, while still allowing
    -- later enemy tiles in the same row to be struck once as well.
    local tile_key = tostring(t:x())..":"..tostring(t:y())
    user.hit_tiles_this_dash = user.hit_tiles_this_dash or {}
    if user.hit_tiles_this_dash[tile_key] then
        return
    end

    user.hit_tiles_this_dash[tile_key] = true
    create_collision_attack(user, damage, t)
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_team() == self:get_team()
    end)
    return #characters > 0
end

return package_init