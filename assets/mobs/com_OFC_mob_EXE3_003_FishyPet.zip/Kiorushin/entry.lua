local shared_package_init = include("../Kiorushin/character.lua")

function package_init(character)
    -- Initialize at the shared pet HP ceiling. The encounter mutator lowers
    -- current HP to the individual pet's trained value before on_spawn_func.
    local character_info = {
        name = "Fishy",
        name_on_spawn = false,
        health = 100,
        damage = 5,
        element = Element.None,
        damage_tosshin = 5,
        damage_honoo = 5,
        dashes = 1,
        -- Vertical enemy-search movement: 64 frames is half the original speed.
        frames_move = 64,
        frames_atk = 10,
    }

    shared_package_init(character, character_info)
end
