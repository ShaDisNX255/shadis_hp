local package_id = "com.OFC.mob.EXE3-003-FishyPet"
local character_id = "com.OFC.char.EXE3-003-FishyPet"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Kiorushin")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("FishyPet")
    package:set_description("Playable Fishy pet")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local test_spawner = mob:create_spawner(character_id, Rank.V1)
    test_spawner:spawn_at(4, 2)
end
