--- Custom Chip: Tornado Toss

--- Setup Textures, Animations and Sounds
--- modpath refers to the root folder of the chip.
TORNADO_TEXTURE = Engine.load_texture(_folderpath .. "tornado.png")
TORNADO_ANIMATION = _folderpath .. "tornado.animation"
WIND_SFX = Engine.load_audio(_folderpath .. "tornado.ogg")
HIT_TEXTURE = Engine.load_texture(_folderpath .. "effect.png")
HIT_ANIM_PATH = _folderpath .. "effect.animation"
HIT_SOUND = Engine.load_audio(_folderpath .. "hitsound.ogg")
local chip = {}
function chip.card_create_action(user)
	DAMAGE = 50
    -- Creates a new cardAction that will play the play_sword animation
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    -- Prevents the user from using other cards during this animation
    action:set_lockout(make_animation_lockout())

    --Function that happens when the card actually executes.
    action.execute_func = function(self, user)
        local actor = self:get_actor()

        -- set:add_anim_action adds functions that execute on certain frames of the
        -- action animation.
        self:add_anim_action(1, function()
            -- Allows the action to be countered during this window.
            actor:toggle_counter(false)
        end)
        self:add_anim_action(2, function()
            -- Necessary code to render the hand of the user
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(actor:get_texture())
            hilt_sprite:set_layer(-2)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(actor:get_animation())
            hilt_anim:set_state("HAND")
            hilt_anim:refresh(hilt_sprite)
            -- Get the current
            local direction = user:get_facing()
            -- Play the wind effect defined earlier
            Engine.play_audio(WIND_SFX, AudioPriority.High)
            -- Now control will be handed over to the create_tornado function.
            -- Variables that are needed by that function are passed in here.
            create_tornado(user, user:get_tile(direction, 1), DAMAGE, 3, direction)
        end)
        self:add_anim_action(3, function()
        end)
        self:add_anim_action(4, function()
            -- End the counterable window
            user:toggle_counter(false)
        end)
    end
    return action
end

---comment
---@param user Entity The user summoning a tornado
---@param tile Tile The tile to summon the tornado on
---@param damage number The amount of damage the tornado will do
---@param speed number The number of frames it takes the tornado to travel 1 tile.
---@param direction any The direction the
---@return unknown
function create_tornado(user, tile, damage, speed, direction)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Spell.new(user:get_team())

    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Drag | Hit.Flash,
            Element.Wind,
            user:get_context(),
            Drag.new(direction, 1)
        )
    )
    -- Setup sprite of the spell
    local sprite = spell:sprite()
    sprite:set_texture(TORNADO_TEXTURE)
    sprite:set_layer(-1)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(TORNADO_ANIMATION)
    anim:set_state("1")
    anim:set_playback(Playback.Loop)
    anim:refresh(sprite)

    spell.update_func = function(self, dt)
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        local tile = spell:get_tile(direction, 1)
        if (tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
            spell:erase()
            return
        end
        --- Makes the spell slide to the next tile over a certain number of frames.
        spell:slide(tile, frames(speed), frames(0), ActionOrder.Voluntary, nil)
        --- Attacks the entities this spell collides with.
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other)
        -- Erases the spell once it hits something
        create_hit_effect(spell:get_field(), spell:get_current_tile(), HIT_TEXTURE, HIT_ANIM_PATH, "8", HIT_SOUND)
    end

    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

--- create hit effect.
---@param field any #A field to spawn the effect on
---@param tile Tile tile to spawn effect on
---@param hit_texture any Texture hit effect. (Engine.load_texture)
---@param hit_anim_path any The animation file path
---@param hit_anim_state any The hit animation to play
---@param sfx any Audio # Audio object to play
---@return any returns the hit fx
function create_hit_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state, sfx)
    -- Create artifact, artifacts do not have hitboxes and are used mostly for special effects
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(hit_texture, true)
    -- This will randomize the position of the effect a bit.
    hitfx:set_offset(math.random(-25, 25), math.random(-25, 25))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(hit_anim_path)
    hitfx_anim:set_state(hit_anim_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(sfx, AudioPriority.High)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    return hitfx
end

return chip
