local package_id = "com.louise.mob.VolgearPet"
local character_id = "com.louise.pet.VolgearPet"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Volgear")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("VolGearPet")
    package:set_description("Playable VolGear pet")
    package:set_preview_texture_path(_modpath.."preview.png")
end

-- This package is server-only, but keep one harmless V1 spawner for package testing.
function package_build(mob)
    local test_spawner = mob:create_spawner(character_id, Rank.V1)
    test_spawner:spawn_at(4, 2)
end
