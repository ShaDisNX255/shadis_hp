local shared_package_init = include("../Rabiree/character.lua")

local Chip1 = include("chips/EXE6-001-Recovery30/recovery/recovery.lua")
Chip1.recover_hp = 30

local Chip2 = include("chips/EXE6-002-Recovery50/recovery/recovery.lua")
Chip2.recover_hp = 50

local Chip3 = include("chips/EXE6-003-PanlSteal/steal/steal.lua")
Chip3.type = 1

local Chip4 = include("chips/EXE6-004-AreaSteal/steal/steal.lua")
Chip4.type = 2

local Chip5 = include("chips/EXE6-005-HolyPanel/stage/stage.lua")
Chip5.type = 1

local Chip6 = include("chips/EXE6-006-Sanctuary/stage/stage.lua")
Chip6.type = 2

local Chip7 = include("chips/EXE6-007-Invisible/invisible/invisible.lua")
local Chip8 = include("chips/EXE6-008-Shadow/entry.lua")
local Chip9 = include("chips/EXE6-009-Barrier/entry.lua")
local Chip10 = include("chips/EXE6-010-Barrier100/entry.lua")

local PET_BRIDGE_CHIPS = {
    ["__PETC1"]  = { id = 1,  card = Chip1,  label = "Recovery30", kind = "recovery", shortname = "Recov30", time_freeze = false },
    ["__PETC2"]  = { id = 2,  card = Chip2,  label = "Recovery50", kind = "recovery", shortname = "Recov50", time_freeze = false },
    ["__PETC3"]  = { id = 3,  card = Chip3,  label = "PanelSteal", kind = "support", shortname = "PanlStel", time_freeze = true },
    ["__PETC4"]  = { id = 4,  card = Chip4,  label = "AreaSteal",  kind = "support", shortname = "AreaStel", time_freeze = true },
    ["__PETC5"]  = { id = 5,  card = Chip5,  label = "HolyPanel", kind = "support", shortname = "HolyPanl", time_freeze = true },
    ["__PETC6"]  = { id = 6,  card = Chip6,  label = "Sanctuary", kind = "support", shortname = "Snctuary", time_freeze = true },
    ["__PETC7"]  = { id = 7,  card = Chip7,  label = "Invisible", kind = "support", shortname = "Invis", time_freeze = true },
    ["__PETC8"]  = { id = 8,  card = Chip8,  label = "Shadow", kind = "support", shortname = "Shadow", time_freeze = true },
    ["__PETC9"]  = { id = 9,  card = Chip9,  label = "Barrier", kind = "support", shortname = "Barrier", time_freeze = true },
    ["__PETC10"] = { id = 10, card = Chip10, label = "Barrier100", kind = "support", shortname = "Barr100", time_freeze = true },
}

local PET_BRIDGE_LOOKUP = {}

for rank = 1, 20 do
    PET_BRIDGE_LOOKUP["__PETR"..tostring(rank)] = {
        chip = nil,
        rank = rank,
    }

    for _, chip_def in pairs(PET_BRIDGE_CHIPS) do
        PET_BRIDGE_LOOKUP["__PETC"..tostring(chip_def.id).."R"..tostring(rank)] = {
            chip = chip_def,
            rank = rank,
        }
    end
end

local function parse_pet_bridge_name(raw_name)
    raw_name = tostring(raw_name or "")

    local entry = PET_BRIDGE_LOOKUP[raw_name]
    if entry then
        return entry.chip, entry.rank
    end

    return PET_BRIDGE_CHIPS[raw_name], nil
end

local function clamp_pet_attack_rank(rank)
    rank = math.floor(tonumber(rank) or 1)
    if rank < 1 then rank = 1 end
    if rank > 20 then rank = 20 end
    return rank
end

local function equip_bridge_chip(self, chip_def)
    if not chip_def then return false end

    self.battle_chip_amount = 1
    self.battle_chip = chip_def.card
    self.battle_chip_id = chip_def.id
    self.battle_chip_kind = chip_def.kind
    self.battle_chip_shortname = chip_def.shortname
    self.battle_chip_time_freeze = chip_def.time_freeze
    self._pet_chip_wait = 0

    print("BunnyPet bridge chip: "..tostring(chip_def.label))
    return true
end

local function get_pet_hp_cap(self)
    if self.pet_hp_cap ~= nil and self.pet_hp_cap > 0 then
        return self.pet_hp_cap
    end

    return self:get_max_health()
end

local function apply_custom_pet_rank(self, pet_attack_rank)
    pet_attack_rank = clamp_pet_attack_rank(pet_attack_rank)

    self.pet_attack_rank = pet_attack_rank
    self.damage = pet_attack_rank * 5
    self.damage_rabiring = pet_attack_rank * 5

    -- Preserve the normal Bunny family's V1/V2/V3 movement progression.
    if pet_attack_rank >= 20 then
        self.frames_between_actions = 18
        self.rabiring_stun_frames = 60
        -- Rabiree V3 is the blue/green battle-1 palette.
        self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-1.png"))
    elseif pet_attack_rank >= 11 then
        self.frames_between_actions = 26
        self.rabiring_stun_frames = 40
        -- Rabiree V2 is the yellow battle-2 palette.
        self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-2.png"))
    else
        self.frames_between_actions = 34
        self.rabiring_stun_frames = 25
        -- Rabiree V1 is the pink/white battle-0 palette.
        self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-0.png"))
    end
end

local function try_use_pet_chip(self)
    if not self.battle_chip or (self.battle_chip_amount or 0) <= 0 then
        return false
    end

    if self._pet_chip_wait > 0 or self:is_moving() then
        return false
    end

    local hp_cap = get_pet_hp_cap(self)
    local should_use = false

    if self.battle_chip_kind == "recovery" then
        should_use = self:get_health() <= (hp_cap * 0.25)
    else
        should_use = self.battle_chip_start == true
    end

    if not should_use then
        return false
    end

    self.battle_chip_amount = self.battle_chip_amount - 1

    local chip_action = self.battle_chip.card_create_action(self)
    local props = chip_action:copy_metadata()
    local chip_runtime = nil

    props.shortname = self.battle_chip_shortname or "PetChip"
    props.damage = 0
    props.time_freeze = self.battle_chip_time_freeze == true
    props.element = Element.None
    props.can_boost = false

    if self.battle_chip_kind == "recovery" then
        chip_runtime = {
            pet_hp_cap = get_pet_hp_cap(self),
        }
    end

    chip_action = self.battle_chip.card_create_action(self, props, chip_runtime)
    chip_action:set_metadata(props)
    self:card_action_event(chip_action, ActionOrder.Voluntary)

    self.battle_chip_start = false
    self._pet_chip_wait = 20

    if self.battle_chip_amount <= 0 then
        self.battle_chip = nil
        self.battle_chip_id = 0
        self.battle_chip_kind = nil
        self.battle_chip_shortname = nil
        self.battle_chip_time_freeze = false
    end

    return true
end

function package_init(character)
    local character_info = {
        name = "Bunny",
        name_on_spawn = true,
        -- Large technical engine ceiling for Pet Duel HP scaling.
        -- Current HP is restored to 100 immediately after shared init, so
        -- normal pet encounters still begin cleanly at their injected 40-100 HP.
        health = 5000,
        damage = 5,
        damage_rabiring = 5,
        -- Battle pets are neutral for consistency with the existing roster.
        element = Element.None,
        frames_between_actions = 34,
        rabiring_stun_frames = 25,
        fast_hop_frames = 4,
    }

    shared_package_init(character, character_info)

    -- Keep 5000 only as the natural engine ceiling. Encounter injection
    -- supplies the actual normal/Pet Duel battle HP before on_spawn.
    character:set_health(100)

    character.battle_chip_start = false
    character.battle_chip_amount = 0
    character.battle_chip = nil
    character.battle_chip_id = 0
    character.pet_hp_cap = nil
    character.pet_attack_rank = nil
    character.battle_chip_kind = nil
    character.battle_chip_shortname = nil
    character.battle_chip_time_freeze = false
    character._pet_chip_wait = 0

    local old_battle_start_func = character.battle_start_func
    character.battle_start_func = function(self)
        if old_battle_start_func then
            old_battle_start_func(self)
        end

        if self.battle_chip_kind ~= "recovery" then
            self.battle_chip_start = true
        end
    end

    local old_on_spawn_func = character.on_spawn_func
    character.on_spawn_func = function(self, spawn_tile)
        local current_name = nil
        local forced_chip = nil
        local pet_attack_rank = nil

        pcall(function()
            current_name = self:get_name()
        end)

        forced_chip, pet_attack_rank = parse_pet_bridge_name(current_name)

        if old_on_spawn_func then
            old_on_spawn_func(self, spawn_tile)
        end

        -- The encounter bridge has applied the actual starting HP by now.
        self.pet_hp_cap = self:get_health()

        if pet_attack_rank ~= nil then
            apply_custom_pet_rank(self, pet_attack_rank)
        else
            apply_custom_pet_rank(self, 1)
        end

        self:set_name("Bunny")

        print("BunnyPet current_name = "..tostring(current_name))
        print("BunnyPet forced_chip = "..tostring(forced_chip and forced_chip.id or nil))
        print("BunnyPet pet_hp_cap = "..tostring(self.pet_hp_cap))
        print("BunnyPet pet_attack_rank = "..tostring(pet_attack_rank))

        if forced_chip then
            equip_bridge_chip(self, forced_chip)
        end
    end

    local chip_component = Battle.Component.new(character, Lifetimes.Battlestep)
    chip_component.update_func = function(self, dt)
        if character:is_deleted() then return end

        if character._pet_chip_wait > 0 then
            character._pet_chip_wait = character._pet_chip_wait - 1
            return
        end

        try_use_pet_chip(character)
    end
    character:register_component(chip_component)
end
