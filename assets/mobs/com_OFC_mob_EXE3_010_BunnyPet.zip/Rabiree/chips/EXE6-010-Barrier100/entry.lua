nonce = function() end

local BARRIER100_TEXTURE = Engine.load_texture(_folderpath.."barrier100.png")
local BARRIER100_ANIMATION_PATH = _folderpath.."barrier.animation"
local BARRIER_UP_SOUND = Engine.load_audio(_folderpath.."Barrier.ogg")

local barrier100 = {}

local function create_barrier(user)
    local fading = false
    local isWind = false

    local barrier = Battle.Artifact.new()
    barrier.HP = 100
    barrier:sprite():set_layer(-3)
    barrier:set_texture(BARRIER100_TEXTURE, true)

    barrier:get_animation():load(BARRIER100_ANIMATION_PATH)
    barrier:get_animation():set_state("BARRIER_IDLE")
    barrier:get_animation():refresh(barrier:sprite())
    barrier:get_animation():set_playback(Playback.Loop)
    barrier:set_float_shoe(true)

    Engine.play_audio(BARRIER_UP_SOUND, AudioPriority.High)
    user:get_field():spawn(barrier, user:get_current_tile())

    local barrier_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)

    barrier_defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()

        if attacker_hit_props.flags & Hit.Impact == Hit.Impact then
            barrier.HP = barrier.HP - attacker_hit_props.damage
            judge:block_damage()
        end

        if attacker_hit_props.element == Element.Wind then
            isWind = true
        end
    end

    user:add_defense_rule(barrier_defense_rule)

    barrier.can_move_to_func = function()
        return true
    end

    local function remove_barrier()
        if fading then
            return
        end

        fading = true
        user:remove_defense_rule(barrier_defense_rule)

        barrier:get_animation():set_state("BARRIER_FADE")
        barrier:get_animation():refresh(barrier:sprite())

        barrier:get_animation():on_complete(function()
            barrier:delete()
        end)
    end

    barrier.update_func = function()
        if user:is_deleted() then
            remove_barrier()
            return
        end

        if barrier:get_current_tile() ~= user:get_current_tile() then
            barrier:teleport(user:get_current_tile(), ActionOrder.Immediate, nil)
        end

        if isWind then
            remove_barrier()
            return
        end

        if barrier.HP <= 0 then
            remove_barrier()
            return
        end

        if barrier_defense_rule:is_replaced() then
            barrier:delete()
        end
    end
end

function package_init(package)
    package:declare_package_id("com.alrysc.card.barrier100")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon2.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview2.png"))
    package:set_codes({'H', 'O', 'Y'})

    local props = package:get_card_props()
    props.shortname = "Barr100"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "Nullifies 100 HP of damage"
    props.limit = 3
end

barrier100.card_create_action = function(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local original_offset = actor:get_offset()

    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        create_barrier(user)
        actor:set_offset(original_offset.x, original_offset.y)
    end

    action.action_end_func = function(self, user)
        actor:set_offset(original_offset.x, original_offset.y)
    end

    return action
end

return barrier100