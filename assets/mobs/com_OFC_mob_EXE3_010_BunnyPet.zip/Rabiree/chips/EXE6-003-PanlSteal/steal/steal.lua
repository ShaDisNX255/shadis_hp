local print_debug = false

local STEAL_TEXTURE = Engine.load_texture(_folderpath.."gfx/steal.grayscaled.png")
local STEAL_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/steal.png")
local STEAL_ANIMPATH = _folderpath.."gfx/steal.animation"

local STEAL_AUDIO_START = Engine.load_audio(_folderpath.."sfx/EXE6_134.ogg", true)
local STEAL_AUDIO_END = Engine.load_audio(_folderpath.."sfx/EXE6_242.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Steal] "..text)
    end
end

local steal = {}

--(Function by Alrysc)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_hitbox(user, props, team, field, tile)
    local spell = Battle.Spell.new(team)
	spell:set_hit_props(
        HitProps.new()
        :dmg(10)
        :impact()
        :flinch()
        :pierce_ground()
        :retangible()
        :no_counter()
        :from(user:get_context())
    )
    spell.update_func = function(self)
        self:get_tile():attack_entities(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

local function MakeTileSplash(user, props, team, field, tile)
    local artifact = graphic_init("artifact", 0, -432, STEAL_TEXTURE, STEAL_PALETTE, STEAL_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, false, true)
	local doOnce = false
	artifact.update_func = function(self, dt)
		if self:get_offset().y >= 0 then
			if not doOnce then
				self:set_offset(0,0)
				self:get_animation():set_state("1")
                self:get_animation():refresh(self:sprite())
                self:get_animation():set_playback(Playback.Once)
				self:get_tile():set_team(team, false)
				self:get_animation():on_frame(1, function()
					Engine.play_audio(STEAL_AUDIO_END, AudioPriority.Immediate)
				end)
				create_hitbox(user, props, team, field, tile)
				doOnce = true
			end
			self:get_animation():on_complete(function()
				self:delete()
			end)
		else
			self:set_offset(0, self:get_offset().y + (8*2))
		end
	end
	artifact.delete_func = function(self)
		self:erase()
	end
    field:spawn(artifact, tile)
	return artifact
end

steal.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

		local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()

		local tile = nil
        if steal.type == 2 then
		    if facing == Direction.Right then
		    	tile = field:tile_at(1,1)
		    else
		    	tile = field:tile_at(field:width(),1)
		    end
        else
            tile = user:get_tile()
        end
        local tile_array = {}
        local tile_array_check = {}
		local tile_front = nil
		local tile_down = nil
		local check1 = false
		local check_front = false
		local check_down = false
		local stop = true

        if steal.type == 2 then
            for i=1, field:width() do
                tile_front = tile:get_tile(facing, i)
                for j=1, field:height() do
                    tile_down = tile_front:get_tile(Direction.Down, j-1)
                    check_down = tile_down and not tile_down:is_edge() and team ~= tile_down:get_team() and tile_down:get_team() ~= Team.Other and user:is_team(tile_down:get_tile(Direction.reverse(facing), 1):get_team())
                    if check_down then
                        for k=1, field:height() do
                            if stop then
                                --print("tile at ("..tile_front:get_tile(Direction.Down, k-1):x().."x, "..tile_front:get_tile(Direction.Down, k-1):y().."y) has been skipped")
                                table.insert(tile_array, tile_front:get_tile(Direction.Down, k-1))
                            end
                            if k==field:height() then
                                stop = false
                                break
                            end
                        end
                        break
                    end
                end
                debug_print("tile at ("..tile_front:x().."x, "..tile_front:y().."y) has been skipped")
            end
        else
            for i=1, field:width() do
                tile_front = tile:get_tile(facing, i)
                check_front = tile_front and team ~= tile_front:get_team() and not tile_front:is_edge() and tile_front:get_team() ~= Team.Other and user:is_team(tile_front:get_tile(Direction.reverse(facing), 1):get_team())
                if check_front then
                    table.insert(tile_array, tile_front)
                    break
                end
                debug_print("tile at ("..tile_front:x().."x, "..tile_front:y().."y) has been skipped")
            end
        end

		local a_frames = 1
		local step1 = Battle.Step.new()

        step1.update_func = function(self)
            if a_frames == 1 then
                if #tile_array > 0 and not check1 then
		        	Engine.play_audio(STEAL_AUDIO_START, AudioPriority.Immediate)
		        	for i=1, #tile_array do
		        		MakeTileSplash(user, props, team, field, tile_array[i])
		        	end
		        	check1 = true
		        end
            elseif a_frames >= 80 then
                user:get_animation():set_playback_speed(orig_speed)
                self:complete_step()
            end
            a_frames = a_frames + 1
        end
		self:add_step(step1)
    end
    return action
end

return steal