local steal = include("steal/steal.lua")

local DAMAGE = 0

steal.type = 1

steal.codes = {"*"}
steal.shortname = "PanlStel"
steal.damage = DAMAGE
steal.time_freeze = true
steal.element = Element.None
steal.description = "Repaints\n1 enmy sq\nin front"
steal.long_description = "Repaints 1 square of the enemy area in front of you into your area"
steal.can_boost = false
steal.card_class = CardClass.Standard
steal.limit = 5
steal.mb = 6

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-164-PanelSteal")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(steal.codes)

    local props = package:get_card_props()
    props.shortname = steal.shortname
    props.damage = steal.damage
    props.time_freeze = steal.time_freeze
    props.element = steal.element
    props.description = steal.description
    props.long_description = steal.long_description
    props.can_boost = steal.can_boost
	props.card_class = steal.card_class
	props.limit = steal.limit
end

card_create_action = steal.card_create_action