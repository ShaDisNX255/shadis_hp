local package_id = "com.OFC.mob.EXE3-010-BunnyPet"
local character_id = "com.OFC.char.EXE3-010-BunnyPet"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Rabiree")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("BunnyPet")
    package:set_description("Playable Bunny virus pet for ShaDis HP")
    package:set_preview_texture_path(_modpath.."preview.png")
end

-- This package is intended for the server pet bridge. The local build is only
-- a basic smoke test and is not used by the server's encounter injection.
function package_build(mob)
    local spawner = mob:create_spawner(character_id, Rank.V1)
    spawner:spawn_at(4, 2)
end
