local package_id = "com.OFC.mob.EXE5-037-Colonel3"
local character_id = "com.OFC.char.EXE5-037-Colonel0"

function package_requires_scripts()
    Engine.requires_character(character_id)
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Colonel V3 (EXE5)")
    package:set_description("Test fight with\nColonel V3\nfrom Rockman EXE5")
    package:set_speed(3)
    package:set_attack(140)
    package:set_health(1800)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."exe5-urainternet.png"
    local animPath = _modpath.."exe5-urainternet.animation"
    mob:set_background(texPath, animPath, 0, 0)
    if math.random(1,2)==1 then
        mob:stream_music(_modpath.."exe5-boss.ogg", 3771, 41841)
    else
        mob:stream_music(_modpath.."exe5ds-boss.ogg", 5986, 43642)
    end
    mob:create_spawner(character_id, Rank.V3):spawn_at(5,2)
end