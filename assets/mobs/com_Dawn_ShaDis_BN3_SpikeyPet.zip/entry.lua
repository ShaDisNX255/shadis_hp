local package_id = "com.Dawn.ShaDis.BN3.SpikeyPet"
local character_id = "com.Dawn.ShaDis.BN3.pet.SpikeyPet"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."character")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Spikey")
    package:set_description("A trainable Spikey battle pet.")
    package:set_speed(1)
    package:set_attack(5)
    package:set_health(100)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    mob:create_spawner(character_id, Rank.V1):spawn_at(4, 2)
end
