local PetBridge = {}

local Chip1 = include("chips/EXE6-001-Recovery30/recovery/recovery.lua")
Chip1.recover_hp = 30

local Chip2 = include("chips/EXE6-002-Recovery50/recovery/recovery.lua")
Chip2.recover_hp = 50

local Chip3 = include("chips/EXE6-003-PanlSteal/steal/steal.lua")
Chip3.type = 1

local Chip4 = include("chips/EXE6-004-AreaSteal/steal/steal.lua")
Chip4.type = 2

local Chip5 = include("chips/EXE6-005-HolyPanel/stage/stage.lua")
Chip5.type = 1

local Chip6 = include("chips/EXE6-006-Sanctuary/stage/stage.lua")
Chip6.type = 2

local Chip7 = include("chips/EXE6-007-Invisible/invisible/invisible.lua")
local Chip8 = include("chips/EXE6-008-Shadow/entry.lua")
local Chip9 = include("chips/EXE6-009-Barrier/entry.lua")
local Chip10 = include("chips/EXE6-010-Barrier100/entry.lua")

local BRIDGE_CHIPS = {
    ["__PETC1"]  = { id = 1,  card = Chip1,  label = "Recovery30", kind = "recovery", shortname = "Recov30", time_freeze = false },
    ["__PETC2"]  = { id = 2,  card = Chip2,  label = "Recovery50", kind = "recovery", shortname = "Recov50", time_freeze = false },
    ["__PETC3"]  = { id = 3,  card = Chip3,  label = "PanelSteal", kind = "support",  shortname = "PanlStel", time_freeze = true  },
    ["__PETC4"]  = { id = 4,  card = Chip4,  label = "AreaSteal",  kind = "support",  shortname = "AreaStel", time_freeze = true  },
    ["__PETC5"]  = { id = 5,  card = Chip5,  label = "HolyPanel",  kind = "support",  shortname = "HolyPanl", time_freeze = true  },
    ["__PETC6"]  = { id = 6,  card = Chip6,  label = "Sanctuary",  kind = "support",  shortname = "Snctuary", time_freeze = true  },
    ["__PETC7"]  = { id = 7,  card = Chip7,  label = "Invisible", kind = "support",  shortname = "Invis",    time_freeze = true  },
    ["__PETC8"]  = { id = 8,  card = Chip8,  label = "Shadow",    kind = "support",  shortname = "Shadow",   time_freeze = true  },
    ["__PETC9"]  = { id = 9,  card = Chip9,  label = "Barrier",   kind = "support",  shortname = "Barrier",  time_freeze = true  },
    ["__PETC10"] = { id = 10, card = Chip10, label = "Barrier100", kind = "support", shortname = "Barr100",  time_freeze = true  },
}

local LOOKUP = {}
for rank = 1, 20 do
    LOOKUP["__PETR"..tostring(rank)] = { chip = nil, rank = rank }
    for _, chip_def in pairs(BRIDGE_CHIPS) do
        LOOKUP["__PETC"..tostring(chip_def.id).."R"..tostring(rank)] = {
            chip = chip_def,
            rank = rank,
        }
    end
end

function PetBridge.parse(raw_name)
    raw_name = tostring(raw_name or "")
    local entry = LOOKUP[raw_name]
    if entry then
        return entry.chip, entry.rank
    end
    return BRIDGE_CHIPS[raw_name], nil
end

function PetBridge.equip(self, chip_def)
    if not chip_def then return false end

    self.battle_chip_amount = 1
    self.battle_chip = chip_def.card
    self.battle_chip_id = chip_def.id
    self.battle_chip_kind = chip_def.kind
    self.battle_chip_shortname = chip_def.shortname
    self.battle_chip_time_freeze = chip_def.time_freeze
    self.battle_chip_timer = 0

    print("SpikeyPet bridge chip: "..tostring(chip_def.label))
    return true
end

function PetBridge.get_hp_cap(self)
    if self.pet_hp_cap ~= nil and self.pet_hp_cap > 0 then
        return self.pet_hp_cap
    end
    return self:get_max_health()
end

function PetBridge.try_use(self)
    if not self.battle_chip or (self.battle_chip_amount or 0) <= 0 then
        return false
    end

    if self:is_sliding() or self.ai_taken_turn then
        return false
    end

    local hp_cap = PetBridge.get_hp_cap(self)
    local should_use = false

    if self.battle_chip_kind == "recovery" then
        should_use = self:get_health() <= (hp_cap - (hp_cap * 75) / 100)
    else
        should_use = self.battle_chip_start == true
    end

    if not should_use then
        return false
    end

    self.battle_chip_amount = self.battle_chip_amount - 1

    if self.battle_chip_kind == "recovery" then
        local heal_amount = tonumber(self.battle_chip and self.battle_chip.recover_hp or 0) or 0
        local new_hp = self:get_health() + heal_amount
        if new_hp > hp_cap then new_hp = hp_cap end
        self:set_health(new_hp)
    else
        local chip_action = self.battle_chip.card_create_action(self)
        local props = chip_action:copy_metadata()

        props.shortname = self.battle_chip_shortname or "PetChip"
        props.damage = 0
        props.time_freeze = self.battle_chip_time_freeze == true
        props.element = Element.None
        props.can_boost = false

        chip_action = self.battle_chip.card_create_action(self, props, nil)
        chip_action:set_metadata(props)
        self:card_action_event(chip_action, ActionOrder.Voluntary)
    end

    self.battle_chip_start = false
    self._chip_wait = 20

    if self.battle_chip_amount <= 0 then
        self.battle_chip = nil
        self.battle_chip_id = 0
        self.battle_chip_kind = nil
        self.battle_chip_shortname = nil
        self.battle_chip_time_freeze = false
    end

    return true
end

return PetBridge
