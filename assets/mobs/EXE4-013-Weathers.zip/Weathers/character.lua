--[[

    Confuse and Blind don't affect it.
    Can't be Dragged during the attacking state.
    TODO: a delay should be applied to every previous entity if the ranks are the same.

]]--
local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."gfx/shadow.png")

local BREATH_TEXTURE = Engine.load_texture(_folderpath.."gfx/breath.grayscaled.png")
local BREATH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/breath.png")
local BREATH_ANIMPATH = _folderpath.."gfx/breath.animation"

local ATTACK2_TEXTURE = Engine.load_texture(_folderpath.."gfx/blizzard.grayscaled.png")
local ATTACK2_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/blizzard.png")
local ATTACK2_ANIMPATH = _folderpath.."gfx/blizzard.animation"
local ATTACK1_TEXTURE = Engine.load_texture(_folderpath.."gfx/heatbreath.grayscaled.png")
local ATTACK1_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/heatbreath.png")
local ATTACK1_ANIMPATH = _folderpath.."gfx/heatbreath.animation"
local ATTACK3_TEXTURE = Engine.load_texture(_folderpath.."gfx/elecshock.grayscaled.png")
local ATTACK3_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/elecshock.png")
local ATTACK3_ANIMPATH = _folderpath.."gfx/elecshock.animation"
local ATTACK4_TEXTURE = Engine.load_texture(_folderpath.."gfx/woodypowder.grayscaled.png")
local ATTACK4_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/woodypowder.png")
local ATTACK4_ANIMPATH = _folderpath.."gfx/woodypowder.animation"

local EFFECT1_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect2.grayscaled.png")
local EFFECT1_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect2.png")
local EFFECT1_ANIMPATH = _folderpath.."gfx/effect2.animation"
local EFFECT2_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect3.grayscaled.png")
local EFFECT2_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect3.png")
local EFFECT2_ANIMPATH = _folderpath.."gfx/effect3.animation"
local EFFECT3_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect4.grayscaled.png")
local EFFECT3_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect4.png")
local EFFECT3_ANIMPATH = _folderpath.."gfx/effect4.animation"
local EFFECT4_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect5.grayscaled.png")
local EFFECT4_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect5.png")
local EFFECT4_ANIMPATH = _folderpath.."gfx/effect5.animation"

local BLIZZARD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_263.ogg", true)
local HEATBREATH_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_303.ogg", true)
local ELECSHOCK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_72.ogg", true)
local WOODYPOWDER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_15.ogg", true)

local WindPush = include("libs/WindPush.lua")

function debug_print(str)
    if print_debug then
        print("[Weathers] "..str)
    end
end

--possible states for character
local states = { IDLE_UP = 1, MOVE_DOWN = 2, IDLE_DOWN = 3, ATTACK = 4, MOVE_UP = 5 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or Playback.Once
    facing = facing or user:get_facing()
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and facing == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_breath_2(user, num)
    local facing = user:get_facing()
    local field = user:get_field()
    local breath = graphic_init("artifact", 0, 0, BREATH_TEXTURE, BREATH_PALETTE, BREATH_ANIMPATH, -99, "2_"..num, Playback.Once, user, facing)
    breath.anim = breath:get_animation()
    breath.frames = 1
    breath.update_func = function(self)
        if self.frames == 7 then
            self:hide()
        end
        if self.frames == 8 then
            self:reveal()
            self.anim:set_state("2_"..num)
            self.anim:set_playback(Playback.Loop)
            self.anim:refresh(self:sprite())
        end
        if self.frames >= 48 then
            self:delete()
            return
        end
        self.frames = self.frames + 1
    end
    breath.battle_end_func = function(self)
        self:delete()
    end
    breath.delete_func = function(self)
        self:erase()
    end
    field:spawn(breath, user:get_tile())
    return breath
end

local function create_breath_1(user)
    local facing = user:get_facing()
    local field = user:get_field()
    local breath = graphic_init("artifact", 0, 0, BREATH_TEXTURE, BREATH_PALETTE, BREATH_ANIMPATH, -99, "0", Playback.Loop, user, facing)
    breath.frames = 1
    breath.update_func = function(self)
        if self.frames == 27 then
            self:delete()
            return
        end
        self.frames = self.frames + 1
    end
    breath.battle_end_func = function(self)
        self:delete()
    end
    breath.delete_func = function(self)
        self:erase()
    end
    field:spawn(breath, user:get_tile())
    return breath
end

local function create_spread(user, facing, field, hit_props, elem_table, tile, is_spread)
    if not tile or tile:is_hole() then return end
    local anim_playback = Playback.Loop
    if elem_table.num == 2 then anim_playback = Playback.Once end
    local spell = graphic_init("spell", 0, 0, elem_table.texture, elem_table.palette, elem_table.animpath, -3, "0", anim_playback, user, facing)
    spell.anim = spell:get_animation()
    spell:set_hit_props(hit_props)
    spell.frames = 1
    spell.update_func = function(self)
        if is_spread == 1 then
            if elem_table.num == 1 then
                for i=9, 57, 8 do
                    if self.frames == i then
                        Engine.play_audio(HEATBREATH_AUDIO, AudioPriority.Immediate)
                    end
                end
            elseif elem_table.num == 4 then
                for i=10, 50, 8 do
                    if self.frames == i then
                        Engine.play_audio(WOODYPOWDER_AUDIO, AudioPriority.Immediate)
                    end
                end
            end
        end
        if self.frames == 1 then
            if elem_table.num == 2 then
                Engine.play_audio(BLIZZARD_AUDIO, AudioPriority.Immediate)
            elseif elem_table.num == 3 then
                Engine.play_audio(ELECSHOCK_AUDIO, AudioPriority.Immediate)
            end
        end
        if self.frames == 41 then
            tile:set_state(elem_table.state)
            if self.anim:has_state("1") then
                self.anim:set_state("1")
                self.anim:refresh(self:sprite())
            end
        end
        if self.anim:get_state() == "1" then
            self.anim:on_complete(function()
                self:delete()
                return
            end)
        end
        if self.frames == 51 then
            self:delete()
            return
        end
        tile:attack_entities(self)
        self.frames = self.frames + 1
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

local function create_attack(user, elem_table)
    local powder = false
    if elem_table.num == 4 then powder = true end
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    if not powder then
        spell:set_hit_props(
            HitProps.new()
            :dmg(elem_table.dmg)
            :impact()
            :flinch()
            :flash()
            :pierce_ground()
            :retangible()
            :elem(elem_table.elem)
            :from(user:get_context())
        )
    else
        spell:set_hit_props(
            HitProps.new()
            :dmg(elem_table.dmg)
            :impact()
            :flinch()
            :confuse(frames(480))
            :pierce_ground()
            :retangible()
            :elem(elem_table.elem)
            :from(user:get_context())
        )
    end
    local tile0 = user:get_tile()
    local tile1 = tile0:get_tile(facing,1)
    local tile2 = tile1:get_tile(facing,1)
    local tile2u = tile1:get_tile(Direction.join(facing,Direction.Up),1)
    local tile2d = tile1:get_tile(Direction.join(facing,Direction.Down),1)
    spell.frames = 1
    spell.update_func = function(self)
        if self.frames == 1 then
            create_spread(user, facing, field, self:copy_hit_props(), elem_table, tile1, 1)
        end
        if self.frames == 15 then
            if tile1 and not tile1:is_hole() then
                create_spread(user, facing, field, self:copy_hit_props(), elem_table, tile2, 2)
                create_spread(user, facing, field, self:copy_hit_props(), elem_table, tile2u, 2)
                create_spread(user, facing, field, self:copy_hit_props(), elem_table, tile2d, 2)
            end
            self:delete()
        end
        self.frames = self.frames + 1
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile0)
    return spell
end

local function choose_element(self, index)
    local elements = {
        [1] = { num = 1, dmg = self.damage_heatbreath,  elem = Element.Fire, state = TileState.Lava,    texture = ATTACK1_TEXTURE, palette = ATTACK1_PALETTE, animpath = ATTACK1_ANIMPATH, },
        [2] = { num = 2, dmg = self.damage_blizzard,    elem = Element.Aqua, state = TileState.Ice,     texture = ATTACK2_TEXTURE, palette = ATTACK2_PALETTE, animpath = ATTACK2_ANIMPATH, },
        [3] = { num = 3, dmg = self.damage_elecshock,   elem = Element.Elec, state = TileState.Cracked, texture = ATTACK3_TEXTURE, palette = ATTACK3_PALETTE, animpath = ATTACK3_ANIMPATH, },
        [4] = { num = 4, dmg = self.damage_woodypowder, elem = Element.Wood, state = TileState.Grass,   texture = ATTACK4_TEXTURE, palette = ATTACK4_PALETTE, animpath = ATTACK4_ANIMPATH, },
    }
    return elements[index]
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(32)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:set_elevation(256*2)
    self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self.damage = character_info.damage
    -- Weathers Specific
    self.damage_heatbreath = character_info.damage_heatbreath
    self.damage_blizzard = character_info.damage_blizzard
    self.damage_elecshock = character_info.damage_elecshock
    self.damage_woodypowder = character_info.damage_woodypowder
    self.element_cycle = character_info.element_cycle
    -- Other Setup
    self.collision_available = true
    self.elevation = 16*2
    self.wait_delay_a = 26
    self.wait_delay_orig = character_info.wait_delay
    self.wait_delay = math.floor(self.wait_delay_orig/2)
    self.element_cycle_index = 1
    self.attacked = false
    self.provoke_attack = false
    self.v_speed = 0
    -- entity will spawn with this animation.
    self.animation:set_state("SPAWN")
    --self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    -- Can't be Draged.
    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    self.defense_rule.filter_statuses_func = function(statuses)
		if self.state == states.ATTACK then
		    statuses.flags = statuses.flags & ~Hit.Drag
        end
		return statuses
	end
    self:add_defense_rule(self.defense_rule)

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print("Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print("Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil

    -- actions for states
    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_edge() then
            return false
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        -- Can't move to tiles reserved not by the Reserving Obstacle.
        if(tile:is_reserved({self:get_id(),self.reserving_obstacle:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if tile:is_hole() and not tile:is_edge() then
            return not check_obstacles(tile) and not check_characters_true(tile)
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end
    self.next_tile = nil
    -- Code that runs in the default state
    ---@param frame number
    self.action_move_down = function(frame)
        if frame == 1 then
            debug_print("MOVE_DOWN")
            self.animation:set_state("MOVE_DOWN")
            self.v_speed = 0
        end
        if self.animation:get_state() ~= "LANDING" then
            if frame == 2 then
                self.v_speed = 1
            end
            if self:get_elevation() >  self.elevation then
                for i=4, 32, 4 do
                    if frame == i then
                        self.v_speed = (i/2)
                    end
                    if frame == i+1 then
                        self.v_speed = (i/2 + 1)
                    end
                end
                self:set_elevation(self:get_elevation()-self.v_speed*2)
            end
            if self:get_elevation() <= self.elevation then
                self.v_speed = 0
                self:set_name(self.current_name)
                self:toggle_hitbox(true)
                self.prev_tile:remove_entity_by_id(self.reserving_obstacle:get_id())
                self:share_tile(false)
                self:set_elevation(self.elevation)
                if not self.provoke_attack then
                    self.animation:set_state("LANDING")
                else
                    self.set_state(states.IDLE_DOWN)
                    return
                end
            end
        else
            self.animation:on_complete(function()
                self.set_state(states.IDLE_DOWN)
            end)
        end
    end

    ---@param frame number
    self.action_move_up = function(frame)
        if frame == 1 then
            debug_print("MOVE_UP")
            self.animation:set_state("MOVE_UP")
            self.reserving = false
            self.do_once = true
            self.v_speed = 0
        end
        if frame == 2 then
            self.v_speed = 1
        end
        if frame == 7 then
            self:set_name("PASS_THROUGH")
            self:toggle_hitbox(false)
            self:share_tile(true)
            self:get_tile():reserve_entity_by_id(self.reserving_obstacle:get_id())
        end
        if self:get_elevation() <  256*2 then
            for i=4, 32, 4 do
                if frame == i then
                    self.v_speed = (i/2)
                end
                if frame == i+1 then
                    self.v_speed = (i/2 + 1)
                end
            end
            self:set_elevation(self:get_elevation()+self.v_speed*2)
        end
        if self:get_elevation() >= 256*2 then
            self.v_speed = 0
            self:set_elevation(256*2)
            self.set_state(states.IDLE_UP)
        end
    end

    ---@param frame number
    self.action_idle_down = function(frame)
        if frame == 1 then
            debug_print("PLAYER_IDLE (DOWN)")
            self.animation:set_state("PLAYER_IDLE")
            self.animation:set_playback(Playback.Loop)
        end
        if self.provoke_attack then
            self.provoke_attack = false
            self.set_state(states.ATTACK)
            return
        end
        local tiles = {
            [1] = self:get_tile(self:get_facing(),1),
            [2] = self:get_tile(self:get_facing(),2),
            [3] = self:get_tile(self:get_facing(),1):get_tile(Direction.join(self:get_facing(),Direction.Up),1),
            [4] = self:get_tile(self:get_facing(),1):get_tile(Direction.join(self:get_facing(),Direction.Down),1),
        }
        for i=1,#tiles do
            local tile = tiles[i]
            if tile and check_characters(tile,self) and not self.attacked then
                self.set_state(states.ATTACK)
                return
            end
        end
        if frame >= self.wait_delay or (frame >= self.wait_delay_a and self.attacked) then
            if not self:is_rooted() then
                self.attacked = false
                self.wait_delay = 1
                self.set_state(states.MOVE_UP)
            end
        end
    end

    ---@param frame number
    self.action_idle_up = function(frame)
        if frame == 1 then
            debug_print("PLAYER_IDLE (UP)")
            self.animation:set_state("PLAYER_IDLE")
            self.animation:set_playback(Playback.Loop)
        end
        if frame >= self.wait_delay then
            if not self:is_rooted() then
                local tile = choose_tile(self)
                local r = math.random(1,3)
                if r==1 then
                    tile = choose_tile_to_enemy(self)
                    if not tile then
                        tile = choose_tile(self)
                    else
                        self.provoke_attack = true
                    end
                end
                self.wait_delay = self.wait_delay_orig
                self.prev_tile = self:get_tile()
                self.next_tile = tile
                self:teleport(self.next_tile, ActionOrder.Immediate)
                self.set_state(states.MOVE_DOWN)
            end
        end
    end

    ---@param frame number
    self.action_attack = function(frame)
        if frame == 1 then
            debug_print("CHARGE")
            WindPush.make_entity_immune_to_status(self)
            self.animation:set_state("CHARGE")
            self.attacked = true
            self.v_speed = 0
        end
        if frame == 4 then
            local tiles = {
                [1] = self:get_tile(self:get_facing(),1),
                [2] = self:get_tile(self:get_facing(),2),
                [3] = self:get_tile(self:get_facing(),1):get_tile(Direction.join(self:get_facing(),Direction.Up),1),
                [4] = self:get_tile(self:get_facing(),1):get_tile(Direction.join(self:get_facing(),Direction.Down),1),
            }
            highlight_tiles(self, tiles, Highlight.Flash, 28)
        end
        if frame == 6 then
            create_breath_1(self)
        end
        if frame == 31 then
            self.counterable_component.timer = 10 -- Makes the Character for 10 frames.
        end
        if frame == 32 then
            self.animation:set_state("ATTACK")
            self.animation:set_playback(Playback.Loop)
            local element = choose_element(self, self.element_cycle[self.element_cycle_index])
            self.element_cycle_index = self.element_cycle_index + 1
            if self.element_cycle_index > #self.element_cycle then self.element_cycle_index = 1 end
            create_breath_2(self, element.num)
            create_attack(self, element)
        end
        if frame == 89 then
            self.animation:set_state("END")
        end
        if frame == 95 then
            WindPush.remove_immunity(self)
            self.set_state(states.IDLE_DOWN)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    local actions = { [1] = self.action_idle_up, [2] = self.action_move_down, [3] = self.action_idle_down, [4] = self.action_attack, [5] = self.action_move_up }
    -- The Reserving Obstacle. Allows Obstacles to be placed on tiles reserved by it.
    self.reserving_obstacle = Battle.Obstacle.new(self:get_team())
    self.current_name = self:get_name()
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        local rank = self:get_rank()
        local weatherses = self:get_field():find_characters(function(c)
            return c:get_animation():has_state("IS_WEATHERS") and c:get_rank() == rank
        end)
        self.wait_delay = self.wait_delay_a*(#weatherses+1)
        self:get_field():spawn(self.reserving_obstacle,0,0)
        self:set_shadow(SHADOW_TEXTURE)
        self:show_shadow(true)
    end
    self.battle_start_func = function()
        self:toggle_hitbox(false)
        self:set_name("PASS_THROUGH")
        self.prev_tile = self:get_tile()
        self.next_tile = self:get_tile()
        --[[
        local weatherses = self:get_field():find_characters(function(c)
            return c:get_animation():has_state("IS_WEATHERS")
        end)
        if #weatherses > 1 then
            for i=0,6 do
                if i~=4 then
                    local weatherses1 = self:get_field():find_characters(function(c)
                        return c:get_animation():has_state("IS_WEATHERS") and c:get_rank() == i
                    end)
                    if weatherses1 > 1 then
                        local weatherses_ids = {}
                        for i=1,#weatherses1 do
                            table.insert(weatherses_ids, weatherses1[i]:get_id())
                        end
                        local minValue = weatherses_ids[1]
                        for i=2, #weatherses_ids do
                            if weatherses_ids[i] < minValue then
                                minValue = weatherses_ids[i]
                            end
                        end
                        if self:get_id() == minValue then
                            self.wait_delay = self.wait_delay_a*#weatherses
                            break
                        end
                    end
                end
            end
        end]]
    end
    self.delete_func = function()
        self.is_deleting = true
        self.reserving_obstacle:delete() -- Removes the Reserving Obstacle.
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE_UP)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        -- collision hitbox
        check_collision(self, self.damage)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function highlight_tiles(self, list, type, time)
    local spell = Battle.Spell.new(self:get_team())
    local ref = self
    spell.update_func = function(self)
        for i=1, #list do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(type)
            end
        end
        time = time - 1
        if time == 0 then 
            self:delete()
        end
        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
    end
    self:get_field():spawn(spell, self:get_tile())
    return spell
end

function choose_tile(user)
    local tiles = user:get_field():find_tiles(function(t)
        return user.can_move_to_func(t) and t ~= user:get_tile()
    end)
    if #tiles==0 then
        return user:get_tile()
    end
    return tiles[math.random(1,#tiles)]
end

function choose_tile_to_enemy(user)
    local field = user:get_field()
    local team = user:get_team()
    local enemy = user:get_field():find_nearest_characters(user, function(c)
        return c:get_health() > 0 and not c:is_team(team)
    end)
    if #enemy==0 then
        return nil
    end
    local tile_r = nil
    for i=1,field:width() do
        local tile = enemy[1]:get_tile(user:get_facing_away(),i)
        if tile and user.can_move_to_func(tile) and tile:get_tile(user:get_facing(),1):get_team() ~= team then
            tile_r = tile
            return tile
        end
    end
    if not tile_r then
        local tiles = field:find_tiles(function(tile)
            return tile and user.can_move_to_func(tile) and tile:get_tile(user:get_facing(),1):get_team() ~= team
        end)
        if #tiles>0 then
            return tiles[math.random(1,#tiles)]
        end
    end
    return tile_r
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        --:breaking()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init