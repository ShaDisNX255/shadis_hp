local shared_package_init = include("../Weathers/character.lua")

function package_init(character)
    local character_info = {
        name = "Weathers",
        name_on_spawn = true,
        health = 80,
        damage = 30,
        element = Element.None,
        damage_heatbreath = 20,
        damage_blizzard = 20,
        damage_elecshock = 20,
        damage_woodypowder = 20,
        element_cycle = {2,2,4},
        wait_delay = 54,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "Weatherl"
        character_info.health = 130
        character_info.damage = 60
        character_info.damage_heatbreath = 40
        character_info.damage_blizzard = 40
        character_info.damage_elecshock = 40
        character_info.damage_woodypowder = 40
        character_info.element_cycle = {1,2,4}
        character_info.wait_delay = 48
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "Weatherm"
        character_info.health = 180
        character_info.damage = 90
        character_info.damage_heatbreath = 80
        character_info.damage_blizzard = 80
        character_info.damage_elecshock = 80
        character_info.damage_woodypowder = 80
        character_info.element_cycle = {2,2,3}
        character_info.wait_delay = 42
    elseif character:get_rank() == Rank.SP then
        character_info.name = "Weatherne"
        character_info.health = 240
        character_info.damage = 130
        character_info.damage_heatbreath = 120
        character_info.damage_blizzard = 120
        character_info.damage_elecshock = 120
        character_info.damage_woodypowder = 120
        character_info.element_cycle = {3,3,4}
        character_info.wait_delay = 36
    elseif character:get_rank() == Rank.Rare1 then
        character_info.name = "Weatherb"
        character_info.health = 300
        character_info.damage = 180
        character_info.damage_heatbreath = 160
        character_info.damage_blizzard = 160
        character_info.damage_elecshock = 160
        character_info.damage_woodypowder = 160
        character_info.element_cycle = {4,1,2,3}
        character_info.wait_delay = 32
    elseif character:get_rank() == Rank.Rare2 then
        character_info.name = "WeathrsEX"
        character_info.health = 380
        character_info.damage = 250
        character_info.damage_heatbreath = 200
        character_info.damage_blizzard = 200
        character_info.damage_elecshock = 200
        character_info.damage_woodypowder = 200
        character_info.element_cycle = {4,1,2,3}
        character_info.wait_delay = 26
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end