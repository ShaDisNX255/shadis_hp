local package_id = "com.OFC.mob.EXE4-013-Weathers"
local character_id = "com.OFC.char.EXE4-013-Weathers"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Weathers")
end

function package_init(package)
    --print('package init for '..package_id)
    package:declare_package_id(package_id)
    package:set_name("Weathers (EXE4)")
    package:set_description("Test fight with\nthe Weathers family\nfrom EXE4")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local test_spawner = mob:create_spawner(character_id, Rank.V1)
          test_spawner:spawn_at(4,1)
          test_spawner = mob:create_spawner(character_id, Rank.V2)
          test_spawner:spawn_at(5,2)
          test_spawner = mob:create_spawner(character_id, Rank.V3)
          test_spawner:spawn_at(6,3)
end