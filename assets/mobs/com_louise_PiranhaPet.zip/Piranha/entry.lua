local shared_package_init = include("./character.lua")

function package_init(character)
    local character_info = {
        name = "Piranha",
        hp = 5000,
        damage = 5,
        palette = _folderpath .. "V1.png",
        height = 44,
        frames_between_actions = 40,
        cursor_speed = 26
    }

    shared_package_init(character, character_info)

    -- The 5000 value is only the engine ceiling. Encounter injection
    -- supplies the actual normal/Pet Duel HP before on_spawn.
    character:set_health(100)
end
