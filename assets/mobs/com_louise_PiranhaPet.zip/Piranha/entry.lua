local shared_package_init = include("./character.lua")

function package_init(character)
    local character_info = {
        name = "Piranha",
        hp = 100,
        damage = 5,
        palette = _folderpath .. "V1.png",
        height = 44,
        frames_between_actions = 40,
        cursor_speed = 26
    }

    shared_package_init(character, character_info)
end
