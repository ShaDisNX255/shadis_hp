local battle_helpers = include("battle_helpers.lua")
local character_animation = _folderpath .. "battle.animation"
local anim_speed = 1
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local scan_sound = Engine.load_audio(_folderpath .. "scan.ogg")
local airshot_sound = Engine.load_audio(_folderpath .. "airshot.ogg")
local attack_sprite = Engine.load_texture(_folderpath .. "attack.png")
local attack_animations = _folderpath .. "attack.animation"
local teleport_texture = Engine.load_texture(_folderpath .. "teleport.png")
local teleport_anim = _folderpath .. "teleport.animation"
local impacts_texture = Engine.load_texture(_folderpath .. "impacts.png")
local impacts_animation_path = _folderpath .. "impacts.animation"

--possible states for character
local states = { IDLE = 1, SCAN = 2, ATTACK = 3, TELEPORT = 4 }

local Chip1 = include("chips/EXE6-001-Recovery30/recovery/recovery.lua")
Chip1.recover_hp = 30

local Chip2 = include("chips/EXE6-002-Recovery50/recovery/recovery.lua")
Chip2.recover_hp = 50

local Chip3 = include("chips/EXE6-003-PanlSteal/steal/steal.lua")
Chip3.type = 1

local Chip4 = include("chips/EXE6-004-AreaSteal/steal/steal.lua")
Chip4.type = 2

local Chip5 = include("chips/EXE6-005-HolyPanel/stage/stage.lua")
Chip5.type = 1

local Chip6 = include("chips/EXE6-006-Sanctuary/stage/stage.lua")
Chip6.type = 2

local Chip7 = include("chips/EXE6-007-Invisible/invisible/invisible.lua")
local Chip8 = include("chips/EXE6-008-Shadow/entry.lua")
local Chip9 = include("chips/EXE6-009-Barrier/entry.lua")
local Chip10 = include("chips/EXE6-010-Barrier100/entry.lua")

local PET_BRIDGE_CHIPS = {
    ["__PETC1"]  = { id = 1,  card = Chip1,  label = "Recovery30", kind = "recovery", shortname = "Recov30", time_freeze = false },
    ["__PETC2"]  = { id = 2,  card = Chip2,  label = "Recovery50", kind = "recovery", shortname = "Recov50", time_freeze = false },
    ["__PETC3"]  = { id = 3,  card = Chip3,  label = "PanelSteal", kind = "support",  shortname = "PanlStel", time_freeze = true  },
    ["__PETC4"]  = { id = 4,  card = Chip4,  label = "AreaSteal",  kind = "support",  shortname = "AreaStel", time_freeze = true  },
    ["__PETC5"]  = { id = 5,  card = Chip5,  label = "HolyPanel",  kind = "support",  shortname = "HolyPanl", time_freeze = true  },
    ["__PETC6"]  = { id = 6,  card = Chip6,  label = "Sanctuary",  kind = "support",  shortname = "Snctuary", time_freeze = true  },
    ["__PETC7"]  = { id = 7,  card = Chip7,  label = "Invisible",  kind = "support",  shortname = "Invis",    time_freeze = true  },
    ["__PETC8"]  = { id = 8,  card = Chip8,  label = "Shadow",     kind = "support",  shortname = "Shadow",   time_freeze = true  },
    ["__PETC9"]  = { id = 9,  card = Chip9,  label = "Barrier",    kind = "support",  shortname = "Barrier",  time_freeze = true  },
    ["__PETC10"] = { id = 10, card = Chip10, label = "Barrier100", kind = "support",  shortname = "Barr100",  time_freeze = true  },
}

local PET_BRIDGE_LOOKUP = {}

for rank = 1, 20 do
    PET_BRIDGE_LOOKUP["__PETR" .. tostring(rank)] = {
        chip = nil,
        rank = rank,
    }

    for _, chip_def in pairs(PET_BRIDGE_CHIPS) do
        PET_BRIDGE_LOOKUP["__PETC" .. tostring(chip_def.id) .. "R" .. tostring(rank)] = {
            chip = chip_def,
            rank = rank,
        }
    end
end

local function parse_pet_bridge_name(raw_name)
    raw_name = tostring(raw_name or "")

    local entry = PET_BRIDGE_LOOKUP[raw_name]
    if entry then
        return entry.chip, entry.rank
    end

    return PET_BRIDGE_CHIPS[raw_name], nil
end

local function equip_bridge_chip(self, chip_def)
    if not chip_def then return false end

    self.battle_chip_amount = 1
    self.battle_chip = chip_def.card
    self.battle_chip_id = chip_def.id
    self.battle_chip_kind = chip_def.kind
    self.battle_chip_shortname = chip_def.shortname
    self.battle_chip_time_freeze = chip_def.time_freeze
    self._pet_chip_wait = 0

    print("PiranhaPet bridge chip: " .. tostring(chip_def.label))
    return true
end

local function get_pet_hp_cap(self)
    if self.pet_hp_cap ~= nil and self.pet_hp_cap > 0 then
        return self.pet_hp_cap
    end

    return self:get_max_health()
end

local function clamp_pet_attack_rank(rank)
    rank = math.floor(tonumber(rank) or 1)
    if rank < 1 then rank = 1 end
    if rank > 20 then rank = 20 end
    return rank
end

local function face_opponents(entity)
    local direction = Direction.Left
    if entity:get_team() == 2 then
        direction = Direction.Right
    end
    entity:set_facing(direction)
    return direction
end

local function apply_custom_pet_rank(self, pet_attack_rank)
    pet_attack_rank = clamp_pet_attack_rank(pet_attack_rank)

    self.pet_attack_rank = pet_attack_rank
    self.damage = pet_attack_rank * 5
    self:set_element(Element.None)

    if pet_attack_rank >= 20 then
        -- Exactly twice as fast as rank 1: 13 scanner units and 3 frames per arrow panel.
        self.cursor_speed = 13
        self.arrow_slide_frames = 3
        self:set_palette(Engine.load_texture(_folderpath .. "V3.png"))
    elseif pet_attack_rank >= 11 then
        self.cursor_speed = 20
        self.arrow_slide_frames = 4
        self:set_palette(Engine.load_texture(_folderpath .. "V2.png"))
    else
        self.cursor_speed = 26
        self.arrow_slide_frames = 6
        self:set_palette(Engine.load_texture(_folderpath .. "V1.png"))
    end
end

local function try_use_pet_chip(self)
    if not self.battle_chip or (self.battle_chip_amount or 0) <= 0 then
        return false
    end

    if self._pet_chip_wait > 0 then
        return false
    end

    -- Do not interrupt the scanner, attack animation, or teleport sequence.
    -- At battle start, before the AI begins, support chips may fire immediately.
    if self.started and self.state ~= states.IDLE then
        return false
    end

    local hp_cap = get_pet_hp_cap(self)
    local should_use = false

    if self.battle_chip_kind == "recovery" then
        should_use = self:get_health() <= (hp_cap * 25) / 100
    else
        should_use = self.battle_chip_start == true
    end

    if not should_use then
        return false
    end

    self.battle_chip_amount = self.battle_chip_amount - 1

    local chip_action = self.battle_chip.card_create_action(self)
    local props = chip_action:copy_metadata()
    local chip_runtime = nil

    props.shortname = self.battle_chip_shortname or "PetChip"
    props.damage = 0
    props.time_freeze = self.battle_chip_time_freeze == true
    props.element = Element.None
    props.can_boost = false

    if self.battle_chip_kind == "recovery" then
        chip_runtime = {
            pet_hp_cap = hp_cap
        }
    end

    chip_action = self.battle_chip.card_create_action(self, props, chip_runtime)
    chip_action:set_metadata(props)
    self:card_action_event(chip_action, ActionOrder.Voluntary)

    self.battle_chip_start = false
    self._pet_chip_wait = 20
    self._pet_ai_pause = math.max(self._pet_ai_pause or 0, 20)

    if self.battle_chip_amount <= 0 then
        self.battle_chip = nil
        self.battle_chip_id = 0
        self.battle_chip_kind = nil
        self.battle_chip_shortname = nil
        self.battle_chip_time_freeze = false
    end

    return true
end
-- Load character resources
local piranhas = {}
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information

    local base_animation_path = character_animation
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(anim_speed)
    -- Load extra resources
    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.hop_time = (character_info.move_speed)
    self.damage = (character_info.damage)
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)
    self.cursor_speed = character_info.cursor_speed
    self.arrow_slide_frames = character_info.arrow_slide_frames or 6
    -- Pet viruses are neutral regardless of the original virus element.
    self:set_element(Element.None)
    self:set_palette(Engine.load_texture(character_info.palette))
    self:set_air_shoe(true)
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.frames_between_actions = character_info.frames_between_actions
    self.started = false
    self.attack_count = 0

    self.battle_chip_start = false
    self.battle_chip_amount = 0
    self.battle_chip = nil
    self.battle_chip_id = 0
    self.pet_hp_cap = nil
    self.battle_chip_kind = nil
    self.battle_chip_shortname = nil
    self.battle_chip_time_freeze = false
    self._pet_chip_wait = 0
    self._pet_ai_pause = 0

    self.move_direction = Direction.Right
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)

    self.battle_start_func = function()
        if self.battle_chip_kind ~= "recovery" then
            self.battle_chip_start = true
        end
    end

    -- actions for states
    -- state idle
    self.action_idle = function(frame)
        if (frame == 1) then
            self.animation:set_state("IDLE")
            self.animation:set_playback(Playback.Loop)
        end
        if (frame == self.frames_between_actions) then
            self.set_state(states.TELEPORT)
        end
    end
    ---state attack
    ---@param frame number
    self.action_attack = function(frame)
        if (frame == 1) then
            self.animation:set_state("IDLE")
            --22 frame delay before attack starts
        elseif (frame == 22) then

            self.animation:on_frame(4, function()
                self:toggle_counter(true)
                self.animation:set_state("ATTACK_BEGIN")
                self.animation:on_complete(function()
                    --create arrow
                    if (self.scanner) then
                        self.scanner:erase()
                        self.scanner = nil
                    end
                    self:toggle_counter(false)
                    Engine.play_audio(airshot_sound, AudioPriority.High)
                    create_arrow(self)
                    self.animation:set_state("ATTACK")
                    self.animation:on_complete(function()
                        self.animation:set_state("ATTACK_END")
                        self.animation:on_complete(function()
                            self.animation:set_state("IDLE")
                            self.set_state(states.IDLE)
                        end)
                    end)
                end)
            end)
        end
    end

    ---state scan
    ---@param frame number
    self.action_scan = function(frame)
        if (frame == 1) then
            self.animation:set_state("SCAN")
            create_scanner(self)
        end
    end

    ---state teleport
    ---@param frame number
    self.action_teleport = function(frame)
        if (frame == 1) then
            battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), teleport_texture, teleport_anim,
                "MEDIUM_TELEPORT_FROM",
                0, 0)
        end
        if (frame == 3) then
            local tile = self:get_tile(Direction.Down, 1);
            if (tile:is_edge()) then
                tile = self:get_tile(Direction.Up, 2)
            end
            local moved = self:teleport(tile, ActionOrder.Involuntary, nil)
            if moved then
                battle_helpers.spawn_visual_artifact(self:get_field(), tile, teleport_texture, teleport_anim,
                    "MEDIUM_TELEPORT_TO",
                    0, 0)
            end
        elseif (frame == 20) then
            self.set_state(states.SCAN)
        end
    end

    self.on_spawn_func = function(self)
        local bridge_name = nil
        local forced_chip = nil
        local pet_attack_rank = nil

        pcall(function()
            bridge_name = self:get_name()
        end)

        forced_chip, pet_attack_rank = parse_pet_bridge_name(bridge_name)

        face_opponents(self)
        self.pet_hp_cap = self:get_health()

        if pet_attack_rank ~= nil then
            apply_custom_pet_rank(self, pet_attack_rank)
        end

        self:set_name(character_info.name)
        table.insert(piranhas, self)

        print("PiranhaPet bridge_name = " .. tostring(bridge_name))
        print("PiranhaPet forced_chip = " .. tostring(forced_chip and forced_chip.id or nil))
        print("PiranhaPet pet_hp_cap = " .. tostring(self.pet_hp_cap))
        print("PiranhaPet pet_attack_rank = " .. tostring(pet_attack_rank))

        if forced_chip then
            equip_bridge_chip(self, forced_chip)
        end
    end

    self.delete_func = function(self)
        removebyId(piranhas, self)
        if (self.scanner) then
            self.scanner:erase()
            self.scanner = nil
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_scan, [3] = self.action_attack,
        [4] = self.action_teleport }

    self.update_func = function()
        if self._pet_ai_pause > 0 then
            self._pet_ai_pause = self._pet_ai_pause - 1
            return
        end

        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.current_direction = self:get_facing()
            self.enemy_dir = self:get_facing()
            self.started = true
            self.set_state(states.TELEPORT)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    local chip_component = Battle.Component.new(self, Lifetimes.Battlestep)
    chip_component.update_func = function()
        if self:is_deleted() then return end

        if self._pet_chip_wait > 0 then
            self._pet_chip_wait = self._pet_chip_wait - 1
            return
        end

        try_use_pet_chip(self)
    end
    self:register_component(chip_component)

    ---Used by piranha to create a scanner
    ---@param owner Entity
    function create_scanner(owner)
        owner.ignore_cursor = false
        local team = owner:get_team()
        local field = owner:get_field()
        local direction = face_opponents(owner)
        local y_offset = -20;
        ---@type Spell
        local spell = Battle.Spell.new(team)
        local direction_offset = 1
        if (direction == Direction.Left) then
            direction_offset = -1
        end

        spell.nextile = owner:get_tile(direction, 2)
        spell.starttile = owner:get_tile(direction, 1)
        spell:set_facing(owner:get_facing())
        local speed = spell.starttile:width() / owner.cursor_speed
        spell.speed = math.floor(speed)
        spell.fractional_speed = math.fmod(speed, 1)
        spell.fractional_portion = 0
        spell.target_found = false
        spell:sprite():set_layer(-5)
        spell:set_hit_props(HitProps.new(
            0,
            Hit.None,
            Element.None,
            owner:get_context(),
            Drag.new()
        ))


        local sprite = spell:sprite()
        sprite:set_texture(attack_sprite)
        spell:set_offset(0, y_offset)
        spell.wait_frames = 0

        local animation = spell:get_animation()
        animation:load(attack_animations)
        animation:set_state("CURSOR")
        animation:refresh(sprite)
        Engine.play_audio(scan_sound, AudioPriority.High)
        spell.update_func = function()
            if (not spell.target_found) then
                if (spell:get_actual_tile():is_edge()) then
                    spell:erase()
                    owner.scanner = nil;
                    if (not owner:is_deleted() and owner.state == states.SCAN) then
                        owner.set_state(states.IDLE)
                    end
                end
                if (spell.wait_frames == 1) then

                    local extra = 0
                    if (spell.fractional_portion > 1) then
                        extra = 1
                        spell.fractional_portion = spell.fractional_portion - 1
                    end
                    local totalSpeed = direction_offset * spell.speed + extra
                    spell:set_offset(spell:get_offset().x + totalSpeed, y_offset)
                    spell.fractional_portion = spell.fractional_portion + spell.fractional_speed
                    spell.wait_frames = 0
                end
                spell.wait_frames = spell.wait_frames + 1
                spell:get_actual_tile():attack_entities(spell)
            end
        end

        spell.get_actual_tile = function(self)
            local start_tile = self:get_current_tile()
            if (spell:get_offset().x == 0) then
                return start_tile
            end
            local tiles_travelled = math.floor(math.abs(spell:get_offset().x) / start_tile:width())
            return start_tile:get_tile(self:get_facing(), tiles_travelled)
        end

        spell.can_move_to_func = function(self)
            return true
        end

        spell.collision_func = function(self, other)
            local target = Battle.Character.from(other)
            if target == nil or target:get_team() == owner:get_team() then
                return
            end
            spell.target_found = true
            local begin = function()
                spell:set_offset(0, y_offset)
            end
            spell:teleport(spell:get_actual_tile(), ActionOrder.Involuntary, begin)

            spell:get_animation():set_state("TARGET_FOUND")
            spell:get_animation():on_complete(function()
                spell:get_animation():set_state("TARGET_LOCK")
            end)
            --all piranhas will attack
            for index, piranha in pairs(piranhas) do
                if (not piranha:is_deleted() and
                    piranha:get_team() == owner:get_team() and
                    not piranha.ignore_cursor) then
                    piranha.set_state(states.ATTACK)
                    piranha.ignore_cursor = true
                end

            end

        end
        owner.scanner = spell;
        field:spawn(spell, spell.starttile)
    end

    ---Used by piranha to create an arrow
    ---@param owner Entity
    function create_arrow(owner)
        local team = owner:get_team()
        local field = owner:get_field()
        local direction = face_opponents(owner)
        ---@type Spell
        local spell = Battle.Spell.new(team)
        spell.nextile = owner:get_tile(direction, 2)
        spell.starttile = owner:get_tile(direction, 1)
        spell:set_facing(owner:get_facing())
        spell.wait_frames = 18
        spell:sprite():set_layer(-5)
        spell:set_hit_props(HitProps.new(
            owner.damage,
            Hit.Impact | Hit.Flinch,
            owner:get_element(),
            owner:get_context(),
            Drag.new()
        ))


        local sprite = spell:sprite()
        sprite:set_texture(attack_sprite)
        spell:set_offset(0, -40)

        local animation = spell:get_animation()
        animation:load(attack_animations)
        animation:set_state("ARROW")
        animation:refresh(sprite)
        spell.update_func = function()
            spell:highlight_tile(Highlight.Solid)
            if (spell:get_current_tile():is_edge()) then
                spell:erase()
            end
            if (not spell:is_sliding()) then
                local can_slide = spell:slide(
                    spell.nextile,
                    frames(owner.arrow_slide_frames or 6),
                    frames(0),
                    ActionOrder.Immediate,
                    nil
                )
                spell.nextile = spell.nextile:get_tile(direction, 1)
                spell.wait_frames = 0
            end
            spell.wait_frames = spell.wait_frames + 1
            spell:get_current_tile():attack_entities(spell)
        end

        spell.can_move_to_func = function(self)
            return true
        end

        spell.collision_func = function(self, dt)
            local artifact = Battle.Artifact.new()
            artifact:never_flip(true)
            artifact:set_texture(impacts_texture)
            artifact:set_animation(impacts_animation_path)
            --FX
            local anim = artifact:get_animation()
            anim:set_state("3")
            anim:on_complete(function()
                artifact:erase()
            end)
            spell:erase()
            field:spawn(artifact, spell:get_current_tile())
        end
        field:spawn(spell, spell.starttile)
    end

    function tiletostring(tile)
        return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
    end

    --shuffle function to provide some randomness
    function shuffle(tbl)
        for i = #tbl, 2, -1 do
            local j = math.random(i)
            tbl[i], tbl[j] = tbl[j], tbl[i]
        end
        return tbl
    end

    function removebyId(tab, val)
        for i, v in pairs(tab) do
            if (v:get_id() == val:get_id()) then
                tab[i] = nil
            end
        end
    end


end

return package_init
