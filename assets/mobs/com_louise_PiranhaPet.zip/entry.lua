local package_id = "com.louise.PiranhaPet"
local character_id = "com.louise.pet.PiranhaPet"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath .. "Piranha")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("PiranhaPet")
  package:set_description("Playable Piranha pet")
  package:set_speed(1)
  package:set_attack(5)
  package:set_health(100)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)
  local spawner = mob:create_spawner(character_id, Rank.V1)
  spawner:spawn_at(4, 2)
end
