local attacks = include("attacks.lua")

local SHOCKDOS_TEXTURE = Engine.load_texture(
    _modpath .. "navi_ShockDOS_battle.png"
)
local SHOCKDOS_ANIMATION = _modpath .. "ShockDOS.animation"
local RECOVERY_AUDIO = Engine.load_audio(
    _modpath .. "sfx/recovery.ogg",
    true
)

local THUNDER_RAIN_GLOW_COLORS = {
    Color.new(0, 30, 0, 255),
    Color.new(0, 30, 0, 255),
    Color.new(0, 30, 0, 255),

    Color.new(0, 60, 5, 255),
    Color.new(0, 60, 5, 255),
    Color.new(0, 60, 5, 255),

    Color.new(0, 90, 10, 255),
    Color.new(0, 90, 10, 255),
    Color.new(0, 90, 10, 255),

    Color.new(0, 120, 15, 255),
    Color.new(0, 120, 15, 255),
    Color.new(0, 120, 15, 255),

    Color.new(0, 150, 20, 255),
    Color.new(0, 150, 20, 255),
    Color.new(0, 150, 20, 255),

    Color.new(0, 180, 25, 255),
    Color.new(0, 180, 25, 255),
    Color.new(0, 180, 25, 255),

    Color.new(0, 150, 20, 255),
    Color.new(0, 150, 20, 255),
    Color.new(0, 150, 20, 255),

    Color.new(0, 120, 15, 255),
    Color.new(0, 120, 15, 255),
    Color.new(0, 120, 15, 255),

    Color.new(0, 90, 10, 255),
    Color.new(0, 90, 10, 255),
    Color.new(0, 90, 10, 255),

    Color.new(0, 60, 5, 255),
    Color.new(0, 60, 5, 255),
    Color.new(0, 60, 5, 255),
}

local THUNDER_RAIN_CLEAR_COLOR = Color.new(0, 0, 0, 255)
local THUNDER_RAIN_DEFENSE_PRIORITY = 99001

local function apply_thunder_rain_glow(character)
    local frame = character.thunder_rain_glow_frame or 1

    character:set_color(
        THUNDER_RAIN_GLOW_COLORS[frame]
    )

    frame = frame + 1

    if frame > #THUNDER_RAIN_GLOW_COLORS then
        frame = 1
    end

    character.thunder_rain_glow_frame = frame
end

local function create_character_info(character)
    local character_info = {
        name = "ShockDOS",
        health = 600,
        element = Element.Elec,
        height = 52,
        initial_delay = 45,

        phases = {
            [1] = {
                minimum_health = 401,
                moves_per_group = 2,
                move_groups_per_attack = 3,
                move_recovery = 10,
                group_pause = 30,
                attack_recovery = 50,

                voltrow_sequence_chance = 65,
                voltrow_sequence = {
                    move_counts = {2, 1, 1},
                    damage = 40,
                    crack_panels = false,
                    move_recovery = 8,
                    between_volleys = 18,
                    finish_recovery = 45,
                },

                attacks = {
                    {
                        name = "voltrow",
                        damage = 40,
                        crack_panels = false,
                        weight = 4,
                    },
                    {
                        name = "hollowplus",
                        damage = 40,
                        crack_panels = false,
                        weight = 1,
                    },
                    {
                        name = "cornervolt",
                        damage = 40,
                        crack_panels = false,
                        weight = 1,
                    },
                    {
                        name = "forkbolt",
                        damage = 40,
                        crack_panels = false,
                        weight = 1,
                    },
                },
            },

            [2] = {
                minimum_health = 201,
                moves_per_group = 2,
                move_groups_per_attack = 3,
                move_recovery = 8,
                group_pause = 24,
                attack_recovery = 40,

                voltrow_sequence_chance = 70,
                voltrow_sequence = {
                    move_counts = {2, 1, 1, 1, 1},
                    damage = 50,
                    crack_panels = false,
                    move_recovery = 6,
                    between_volleys = 14,
                    finish_recovery = 40,
                },

                attacks = {
                    {
                        name = "voltrow",
                        damage = 50,
                        crack_panels = false,
                        weight = 3,
                    },
                    {
                        name = "staticcross",
                        damage = 50,
                        crack_panels = false,
                        weight = 1,
                    },
                    {
                        name = "zigvolt",
                        damage = 50,
                        crack_panels = false,
                        weight = 1,
                    },
                    {
                        name = "centercross",
                        damage = 50,
                        crack_panels = false,
                        weight = 1,
                    },
                    {
                        name = "xburst",
                        damage = 50,
                        crack_panels = false,
                        weight = 1,
                    },
                },
            },

            [3] = {
                minimum_health = 1,
                moves_per_group = 2,
                move_groups_per_attack = 3,
                move_recovery = 6,
                group_pause = 18,
                attack_recovery = 30,

                thunder_rain = {
                    shortname = "ThunderRain-Z",

                    -- Phase-three entrance:
                    -- move around several times, pause briefly,
                    -- then activate the time-freeze special.
                    prelude_moves = 4,
                    prelude_move_recovery = 6,
                    prelude_pause = 24,

                    -- Each volley is a complete VoltRow.
                    attack_name = "voltrow",
                    volleys = 16,
                    damage = 30,
                    crack_panels = false,

                    move_recovery = 4,
                    attack_recovery = 6,
                    final_wait = 35,
                    finish_recovery = 45,
                },

                attacks = {
                    {
                        name = "elecchase",
                        damage = 20,
                        crack_panels = false,
                        weight = 1,
                    },
                    {
                        name = "elecrow",
                        damage = 60,
                        crack_panels = true,
                        weight = 1,
                    },
                    {
                        name = "elecwave",
                        damage = 60,
                        crack_panels = true,
                        weight = 1,
                    },
                    {
                        name = "elecrain",
                        damage = 80,
                        crack_panels = true,
                        weight = 1,
                    },
                },
            },
        },
    }

    -- Future versions can override these values by rank while continuing
    -- to share this file and the same battle assets.
    --
    -- if character:get_rank() == Rank.V2 then
    --     character_info.health = ...
    --     character_info.phases = ...
    -- elseif character:get_rank() == Rank.V3 then
    --     character_info.health = ...
    --     character_info.phases = ...
    -- end

    return character_info
end

local function set_idle(character)
    local animation = character:get_animation()
    animation:set_state("PLAYER_IDLE")
    animation:set_playback(Playback.Loop)
    animation:refresh(character:sprite())
end

local function get_phase_number(character)
    local health = character:get_health()
    local phases = character.phases

    for phase_number = 1, #phases do
        if health >= phases[phase_number].minimum_health then
            return phase_number
        end
    end

    return #phases
end

local function is_open_tile(character, tile)
    if not tile
        or tile:is_edge()
        or tile:get_team() ~= character:get_team()
        or tile:is_reserved({})
    then
        return false
    end

    local entities = tile:find_entities(function(entity)
        return Battle.Character.from(entity) ~= nil
            or Battle.Obstacle.from(entity) ~= nil
    end)

    return #entities == 0
end

local function choose_adjacent_tile(character)
    local current_tile = character:get_current_tile()
    if not current_tile then
        return nil
    end

    local directions = {
        Direction.Up,
        Direction.Down,
        Direction.Left,
        Direction.Right,
    }

    local choices = {}

    for i = 1, #directions do
        local tile = current_tile:get_tile(directions[i], 1)

        if tile ~= current_tile and is_open_tile(character, tile) then
            choices[#choices + 1] = tile
        end
    end

    if #choices == 0 then
        return nil
    end

    return choices[math.random(1, #choices)]
end

local function choose_random_team_tile(character)
    local current_tile = character:get_current_tile()
    if not current_tile then
        return nil
    end

    local field = character:get_field()
    local choices = field:find_tiles(function(tile)
        return tile ~= current_tile
            and is_open_tile(character, tile)
    end)

    if #choices == 0 then
        return nil
    end

    return choices[math.random(1, #choices)]
end

local function begin_move(character, destination, on_complete)
    if not destination then
        character.busy = false

        if on_complete then
            on_complete()
        end

        return
    end

    character.busy = true

    local completed = false

    local function finish_move()
        if completed then
            return
        end

        completed = true
        character.busy = false

        if on_complete then
            on_complete()
        end
    end

    local move_queued = character:teleport(
        destination,
        ActionOrder.Immediate,
        function()
            local animation = character:get_animation()
            animation:set_state("PLAYER_MOVE")
            animation:refresh(character:sprite())

            animation:on_complete(function()
                finish_move()

                if character:get_health() > 0
                    and not character.flinched
                then
                    set_idle(character)
                end
            end)

            animation:on_interrupt(function()
                finish_move()
            end)
        end
    )

    if not move_queued then
        finish_move()
    end
end

local function choose_attack(character, phase_data)
    local choices = phase_data.attacks
    local available = {}

    for i = 1, #choices do
        if choices[i].name ~= character.last_attack then
            available[#available + 1] = choices[i]
        end
    end

    if #available == 0 then
        available = choices
    end

    local total_weight = 0

    for i = 1, #available do
        total_weight = total_weight + (available[i].weight or 1)
    end

    local roll = math.random(1, total_weight)

    for i = 1, #available do
        roll = roll - (available[i].weight or 1)

        if roll <= 0 then
            return available[i]
        end
    end

    return available[#available]
end

local function perform_attack(
    character,
    attack_data,
    on_complete,
    counterable
)
    character.busy = true

    local completed = false

    local function finish_attack()
        if completed then
            return
        end

        completed = true
        character.busy = false

        if on_complete then
            on_complete()
        end
    end

    local action = attacks.create(
        character,
        attack_data.name,
        attack_data.damage,
        attack_data.crack_panels,
        finish_attack,
        counterable
    )

    if not action then
        finish_attack()
        return
    end

    character:card_action_event(action, ActionOrder.Voluntary)
end

local function reset_normal_movement_cycle(character, phase_data)
    character.ai_mode = "normal"
    character.moves_remaining = phase_data.moves_per_group
    character.move_groups_remaining =
        phase_data.move_groups_per_attack
end

local function start_voltrow_sequence(character, phase_data)
    local sequence = phase_data.voltrow_sequence

    character.ai_mode = "voltrow_sequence"
    character.voltrow_sequence_data = sequence
    character.voltrow_sequence_index = 1
    character.voltrow_sequence_moves_remaining =
        sequence.move_counts[1]
end

local function start_next_cycle(character, phase_data)
    local sequence = phase_data.voltrow_sequence
    local chance = phase_data.voltrow_sequence_chance or 0

    if sequence
        and not character.last_cycle_was_voltrow_sequence
        and math.random(1, 100) <= chance
    then
        start_voltrow_sequence(character, phase_data)
        return
    end

    reset_normal_movement_cycle(character, phase_data)
end

local function complete_normal_movement_step(character, phase_data)
    character.moves_remaining = math.max(
        0,
        character.moves_remaining - 1
    )

    if character.moves_remaining > 0 then
        character.action_timer = phase_data.move_recovery
        return
    end

    character.move_groups_remaining = math.max(
        0,
        character.move_groups_remaining - 1
    )

    if character.move_groups_remaining > 0 then
        character.moves_remaining = phase_data.moves_per_group
        character.action_timer = phase_data.group_pause
    else
        character.action_timer = phase_data.move_recovery
    end
end

local function begin_normal_attack(character, phase_data)
    local attack_data = choose_attack(character, phase_data)
    character.last_attack = attack_data.name

    perform_attack(
        character,
        attack_data,
        function()
            character.last_cycle_was_voltrow_sequence = false
            character.action_timer = phase_data.attack_recovery

            local next_phase_data =
                character.phases[character.phase]

            start_next_cycle(character, next_phase_data)

            if character:get_health() > 0
                and not character.flinched
            then
                set_idle(character)
            end
        end,
        true
    )
end

local function update_voltrow_sequence(character)
    local sequence = character.voltrow_sequence_data

    if character.voltrow_sequence_moves_remaining > 0 then
        local destination = choose_adjacent_tile(character)

        begin_move(
            character,
            destination,
            function()
                character.voltrow_sequence_moves_remaining =
                    math.max(
                        0,
                        character.voltrow_sequence_moves_remaining - 1
                    )

                character.action_timer =
                    sequence.move_recovery
            end
        )

        return
    end

    local attack_data = {
        name = "voltrow",
        damage = sequence.damage,
        crack_panels = sequence.crack_panels,
    }

    character.last_attack = "voltrow"

    perform_attack(
        character,
        attack_data,
        function()
            character.voltrow_sequence_index =
                character.voltrow_sequence_index + 1

            if character.voltrow_sequence_index
                > #sequence.move_counts
            then
                character.last_cycle_was_voltrow_sequence = true
                character.action_timer =
                    sequence.finish_recovery

                local next_phase_data =
                    character.phases[character.phase]

                start_next_cycle(character, next_phase_data)

                if character:get_health() > 0
                    and not character.flinched
                then
                    set_idle(character)
                end

                return
            end

            character.voltrow_sequence_moves_remaining =
                sequence.move_counts[
                    character.voltrow_sequence_index
                ]

            character.action_timer =
                sequence.between_volleys
        end,
        true
    )
end

local prepare_thunder_rain

local function start_thunder_rain_prelude(
    character,
    config
)
    character.thunder_rain_pending = false
    character.thunder_rain_config = config
    character.ai_mode = "thunder_rain_prelude"
    character.thunder_rain_prelude_moves_remaining =
        config.prelude_moves
    character.action_timer = 0
end

local function update_thunder_rain_prelude(character)
    local config = character.thunder_rain_config

    if character.thunder_rain_prelude_moves_remaining > 0 then
        local destination = choose_random_team_tile(character)

        begin_move(
            character,
            destination,
            function()
                character.thunder_rain_prelude_moves_remaining =
                    math.max(
                        0,
                        character.thunder_rain_prelude_moves_remaining - 1
                    )

                if character.thunder_rain_prelude_moves_remaining > 0 then
                    character.action_timer =
                        config.prelude_move_recovery
                else
                    character.action_timer =
                        config.prelude_pause
                end
            end
        )

        return
    end

    prepare_thunder_rain(character, config)
end

local function remove_thunder_rain_guard(character)
    if not character.thunder_rain_guard then
        return
    end

    character:remove_defense_rule(
        character.thunder_rain_guard
    )
    character.thunder_rain_guard = nil
end

local function finish_thunder_rain(character)
    local config = character.thunder_rain_config

    remove_thunder_rain_guard(character)

    -- Black is a neutral/no-op tint while using Additive color mode.
    character:set_color(THUNDER_RAIN_CLEAR_COLOR)
    character.thunder_rain_glow_frame = 1

    character.thunder_rain_active = false
    character.busy = false
    character.thunder_rain_state = nil
    character.action_timer = config.finish_recovery
    character.last_cycle_was_voltrow_sequence = false

    local phase_data = character.phases[character.phase]
    start_next_cycle(character, phase_data)

    if character:get_health() > 0
        and not character.flinched
    then
        set_idle(character)
    end
end

local function start_thunder_rain_barrage(
    character,
    config
)
    local guard = Battle.DefenseRule.new(
        THUNDER_RAIN_DEFENSE_PRIORITY,
        DefenseOrder.Always
    )

    guard.can_block_func = function(judge)
        judge:block_impact()
        judge:block_damage()
    end

    character:add_defense_rule(guard)

    -- Match the pulsing glow used by Guts Machine instead of applying
    -- one solid green tint.
    character:sprite():set_color_mode(ColorMode.Additive)
    character.thunder_rain_glow_frame = 1
    apply_thunder_rain_glow(character)

    character.thunder_rain_guard = guard
    character.thunder_rain_config = config
    character.thunder_rain_active = true
    character.thunder_rain_state = "move"
    character.thunder_rain_volley = 1
    character.busy = false
    character.action_timer = 0
    character:toggle_counter(false)
end

prepare_thunder_rain = function(character, config)
    character.thunder_rain_pending = false
    character.thunder_rain_used = true
    character.ai_mode = "thunder_rain_intro"
    character.busy = true
    character:toggle_counter(false)

    local action = Battle.CardAction.new(
        character,
        "PLAYER_SHOOTING"
    )

    action:override_animation_frames(make_frame_data({
        {1, 0.033},
        {2, 0.017},
        {2, 0.017},
        {3, 0.033},
        {4, 0.250},
    }))

    action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, actor)
        -- ThunderRain-Z freezes on its opening shooting pose, so the
        -- BUSTER must exist immediately rather than waiting for frame 2.
        local buster = self:add_attachment("BUSTER")
        local sprite = buster:sprite()
        sprite:set_texture(actor:get_texture(), true)
        sprite:set_layer(-2)
        sprite:enable_parent_shader(true)

        local animation = buster:get_animation()
        animation:copy_from(actor:get_animation())
        animation:set_state("BUSTER")
        animation:refresh(sprite)
    end

    local metadata = action:copy_metadata()
    metadata.time_freeze = true
    metadata.shortname = config.shortname
    action:set_metadata(metadata)

    local started = false

    action.action_end_func = function()
        if started then
            return
        end

        started = true
        start_thunder_rain_barrage(
            character,
            config
        )
    end

    character:card_action_event(
        action,
        ActionOrder.Voluntary
    )
end

local function update_thunder_rain(character)
    local config = character.thunder_rain_config

    apply_thunder_rain_glow(character)

    if character.busy then
        return
    end

    if character.action_timer > 0 then
        character.action_timer =
            character.action_timer - 1
        return
    end

    if character.thunder_rain_state == "finish" then
        finish_thunder_rain(character)
        return
    end

    if character.thunder_rain_state == "move" then
        local destination = choose_random_team_tile(character)

        begin_move(
            character,
            destination,
            function()
                character.thunder_rain_state = "attack"
                character.action_timer =
                    config.move_recovery
            end
        )

        return
    end

    local attack_data = {
        name = config.attack_name or "voltrow",
        damage = config.damage,
        crack_panels = config.crack_panels,
    }

    perform_attack(
        character,
        attack_data,
        function()
            if character.thunder_rain_volley
                >= config.volleys
            then
                character.thunder_rain_state = "finish"
                character.action_timer = config.final_wait
                return
            end

            character.thunder_rain_volley =
                character.thunder_rain_volley + 1

            character.thunder_rain_state = "move"
            character.action_timer =
                config.attack_recovery
        end,
        false
    )
end

local function add_electric_absorption(character)
    local absorbed_attack_ids = {}
    local electric_absorb_rule = Battle.DefenseRule.new(
        0,
        DefenseOrder.Always
    )

    electric_absorb_rule.filter_statuses_func = function(hit_props)
        if hit_props.element == Element.Elec then
            hit_props.flags = hit_props.flags & ~Hit.Stun
        end

        return hit_props
    end

    electric_absorb_rule.can_block_func = function(
        defense_judge,
        attacker,
        target
    )
        local hit_props = attacker:copy_hit_props()

        if hit_props.element ~= Element.Elec then
            return
        end

        local attacker_id = attacker:get_id()

        if not absorbed_attack_ids[attacker_id] then
            absorbed_attack_ids[attacker_id] = true

            local healing = math.max(0, hit_props.damage or 0)
            local old_health = target:get_health()
            local new_health = math.min(
                target:get_max_health(),
                old_health + healing
            )

            if new_health > old_health then
                target:set_health(new_health)
                Engine.play_audio(
                    RECOVERY_AUDIO,
                    AudioPriority.High
                )
            end
        end

        defense_judge:block_damage()
        defense_judge:block_impact()
    end

    character:add_defense_rule(electric_absorb_rule)
end

local function add_under_shirt(character)
    local under_shirt = Battle.DefenseRule.new(
        61044,
        DefenseOrder.CollisionOnly
    )

    under_shirt.filter_statuses_func = function(hit_props)
        -- Electric attacks are handled by the absorption rule.
        if hit_props.element == Element.Elec then
            return hit_props
        end

        local damage = math.max(0, hit_props.damage or 0)
        local current_health = character:get_health()

        if current_health > 1
            and damage >= current_health
        then
            hit_props.damage = 0
            character:set_health(1)
        end

        return hit_props
    end

    character:add_defense_rule(under_shirt)
end

local function add_super_armor(character)
    local super_armor = Battle.DefenseRule.new(
        813,
        DefenseOrder.CollisionOnly
    )

    super_armor.filter_statuses_func = function(statuses)
        local has_stun =
            statuses.flags & Hit.Stun == Hit.Stun
        local has_freeze =
            statuses.flags & Hit.Freeze == Hit.Freeze

        if not has_stun and not has_freeze then
            statuses.flags =
                statuses.flags & ~Hit.Flinch
        end

        return statuses
    end

    character:add_defense_rule(super_armor)
end

function package_init(character)
    local character_info = create_character_info(character)

    character:set_name(character_info.name)
    character:set_health(character_info.health)
    character:set_element(character_info.element)
    character:set_height(character_info.height)
    character:set_float_shoe(true)
    character:set_air_shoe(true)
    character:set_texture(SHOCKDOS_TEXTURE)

    local animation = character:get_animation()
    animation:load(SHOCKDOS_ANIMATION)
    set_idle(character)

    character.phases = character_info.phases
    character.phase = 1
    character.busy = false
    character.flinched = false
    character.action_timer =
        character_info.initial_delay
    character.last_attack = nil
    character.last_cycle_was_voltrow_sequence = false

    character.thunder_rain_used = false
    character.thunder_rain_pending = false
    character.thunder_rain_active = false
    character.thunder_rain_guard = nil
    character.thunder_rain_config = nil
    character.thunder_rain_prelude_moves_remaining = 0
    character.thunder_rain_glow_frame = 1

    start_next_cycle(
        character,
        character.phases[1]
    )

    character.can_move_to_func = function(tile)
        return is_open_tile(character, tile)
    end

    add_electric_absorption(character)
    add_super_armor(character)
    add_under_shirt(character)

    local function finish_hit_animation()
        character.flinched = false
        character.busy = false
        character.action_timer =
            math.max(character.action_timer, 10)

        if character:get_health() > 0 then
            set_idle(character)
        end
    end

    local function show_hit_animation()
        if character.flinched then
            return
        end

        character:toggle_counter(false)
        character.flinched = true

        local hit_animation = character:get_animation()
        hit_animation:set_state("PLAYER_HIT")
        hit_animation:refresh(character:sprite())
        hit_animation:on_complete(finish_hit_animation)
        hit_animation:on_interrupt(function()
            character.flinched = false
        end)
    end

    character:register_status_callback(
        Hit.Flinch,
        show_hit_animation
    )
    character:register_status_callback(
        Hit.Stun,
        show_hit_animation
    )

    character.update_func = function(self)
        local new_phase = get_phase_number(self)

        if new_phase ~= self.phase then
            self.phase = new_phase

            if new_phase == 3
                and not self.thunder_rain_used
            then
                self.thunder_rain_pending = true
            end
        end

        if self.thunder_rain_active then
            update_thunder_rain(self)
            return
        end

        if self:get_health() <= 0
            or self.busy
            or self.flinched
        then
            return
        end

        if self.thunder_rain_pending then
            local phase_data = self.phases[self.phase]

            start_thunder_rain_prelude(
                self,
                phase_data.thunder_rain
            )

            return
        end

        if self.action_timer > 0 then
            self.action_timer =
                self.action_timer - 1
            return
        end

        local phase_data = self.phases[self.phase]

        if self.ai_mode == "thunder_rain_prelude" then
            update_thunder_rain_prelude(self)
            return
        end

        if self.ai_mode == "voltrow_sequence" then
            update_voltrow_sequence(self)
            return
        end

        if self.move_groups_remaining > 0 then
            local destination = choose_adjacent_tile(self)

            begin_move(
                self,
                destination,
                function()
                    complete_normal_movement_step(
                        self,
                        phase_data
                    )
                end
            )

            return
        end

        begin_normal_attack(self, phase_data)
    end
end
