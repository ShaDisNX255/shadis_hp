local attacks = {}

local THUNDERBOLT_TEXTURE = Engine.load_texture(_folderpath .. "gfx/bolt.png")
local THUNDERBOLT_ANIM = _folderpath .. "gfx/bolt.animation"
local THUNDERBOLT_SFX = Engine.load_audio(_folderpath .. "sfx/thunderBolt.ogg", true)

local THUNDER_WARNING_FRAMES = 30

local function create_attack_source(user)
    return {
        field = user:get_field(),
        team = user:get_team(),
        facing = user:get_facing(),
        hit_context = user:get_context(),
        origin_tile = user:get_tile(),
    }
end

local function create_timing_controller(source)
    local controller = Battle.Spell.new(source.team)

    controller.can_move_to_func = function()
        return true
    end

    controller.delete_func = function(self)
        self:erase()
    end

    controller.battle_end_func = function(self)
        self:erase()
    end

    return controller
end

local function find_nearest_target_tile(field, team, origin)
    if not origin then
        return nil
    end

    local best_tile = nil
    local best_distance = math.huge

    field:find_characters(function(other)
        if other:get_team() == team
            or other:get_team() == Team.Other
            or other:will_erase_eof()
        then
            return false
        end

        local tile = other:get_current_tile()
        if tile and not tile:is_edge() then
            local distance = math.abs(origin:x() - tile:x())
                + math.abs(origin:y() - tile:y())

            if distance < best_distance then
                best_distance = distance
                best_tile = tile
            end
        end

        return false
    end)

    return best_tile
end

local function get_nearest_target_tile(user)
    return find_nearest_target_tile(
        user:get_field(),
        user:get_team(),
        user:get_tile()
    )
end

local function get_front_anchor_tile(user, distance)
    local tile = user:get_tile(user:get_facing(), distance or 2)
    if tile and not tile:is_edge() then
        return tile
    end

    tile = user:get_tile(user:get_facing(), 1)
    if tile and not tile:is_edge() then
        return tile
    end

    return user:get_tile()
end

local function push_tile(list, tile)
    if tile and not tile:is_edge() then
        list[#list + 1] = tile
    end
end

local function build_tiles_from_directions(anchor, directions, include_center)
    local tiles = {}

    if not anchor then
        return tiles
    end

    if include_center then
        push_tile(tiles, anchor)
    end

    for i = 1, #directions do
        push_tile(tiles, anchor:get_tile(directions[i], 1))
    end

    return tiles
end

local CARDINAL_DIRECTIONS = {
    Direction.Up,
    Direction.Right,
    Direction.Down,
    Direction.Left,
}

local CORNER_DIRECTIONS = {
    Direction.UpLeft,
    Direction.UpRight,
    Direction.DownRight,
    Direction.DownLeft,
}

local function build_cardinal_ring(anchor)
    return build_tiles_from_directions(anchor, CARDINAL_DIRECTIONS, false)
end

local function build_corner_ring(anchor)
    return build_tiles_from_directions(anchor, CORNER_DIRECTIONS, false)
end

local function build_center_cross(anchor)
    return build_tiles_from_directions(anchor, CARDINAL_DIRECTIONS, true)
end

local function build_xburst(anchor)
    local tiles = {}

    if not anchor then
        return tiles
    end

    push_tile(tiles, anchor:get_tile(Direction.UpLeft, 1))
    push_tile(tiles, anchor:get_tile(Direction.UpRight, 1))
    push_tile(tiles, anchor)
    push_tile(tiles, anchor:get_tile(Direction.DownRight, 1))
    push_tile(tiles, anchor:get_tile(Direction.DownLeft, 1))

    return tiles
end

local function build_forkbolt_tiles(user)
    local origin = user:get_tile()
    if not origin then
        return {}
    end

    local facing = user:get_facing()
    local tiles = {}
    local front_1 = origin:get_tile(facing, 1)
    local front_2 = origin:get_tile(facing, 2)

    push_tile(tiles, front_1)

    if front_1 then
        push_tile(tiles, front_1:get_tile(Direction.Up, 1))
        push_tile(tiles, front_1:get_tile(Direction.Down, 1))
    end

    push_tile(tiles, front_2)

    return tiles
end

local function build_zigvolt_tiles(user)
    local origin = user:get_tile()
    if not origin then
        return {}
    end

    local facing = user:get_facing()
    local tiles = {}
    local front_1 = origin:get_tile(facing, 1)
    local front_2 = origin:get_tile(facing, 2)
    local front_3 = origin:get_tile(facing, 3)

    push_tile(tiles, front_1)

    if front_1 then
        push_tile(tiles, front_1:get_tile(Direction.Up, 1))
    end

    push_tile(tiles, front_2)

    if front_2 then
        push_tile(tiles, front_2:get_tile(Direction.Down, 1))
    end

    push_tile(tiles, front_3)

    return tiles
end

local function build_full_column_tiles(center_tile)
    local tiles = {}

    if not center_tile or center_tile:is_edge() then
        return tiles
    end

    local cursor = center_tile

    while true do
        local up = cursor:get_tile(Direction.Up, 1)
        if not up or up:is_edge() then
            break
        end
        cursor = up
    end

    while cursor and not cursor:is_edge() do
        push_tile(tiles, cursor)

        local down = cursor:get_tile(Direction.Down, 1)
        if not down or down:is_edge() then
            break
        end

        cursor = down
    end

    return tiles
end

local function create_thunderbolt(
    source,
    tile,
    damage,
    crack_panels,
    stun_strike
)
    if not tile or tile:is_edge() then
        return
    end

    local spell = Battle.Spell.new(source.team)

    Engine.play_audio(THUNDERBOLT_SFX, AudioPriority.Low)

    spell:set_facing(source.facing)

    local flags = Hit.Flash | Hit.Flinch | Hit.Impact
    if stun_strike then
        flags = Hit.Flinch | Hit.Impact | Hit.Stun
    end

    spell:set_hit_props(HitProps.new(
        damage,
        flags,
        Element.Elec,
        source.hit_context,
        Drag.None
    ))

    spell:set_texture(THUNDERBOLT_TEXTURE, true)
    spell:sprite():set_layer(-2)

    local animation = spell:get_animation()
    animation:load(THUNDERBOLT_ANIM)
    animation:set_state("1")
    animation:refresh(spell:sprite())
    animation:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self)
        local current_tile = self:get_current_tile()
        if not current_tile then
            return
        end

        current_tile:attack_entities(self)

        if crack_panels and current_tile:is_walkable() then
            current_tile:set_state(TileState.Cracked)
        end
    end

    spell.battle_end_func = function(self)
        self:erase()
    end

    source.field:spawn(spell, tile)
end

local function schedule_thunder_strike(
    source,
    tile,
    damage,
    crack_panels,
    stun_strike,
    warning_frames
)
    if not tile or tile:is_edge() then
        return nil
    end

    local warning = Battle.Spell.new(source.team)
    local remaining = warning_frames or THUNDER_WARNING_FRAMES

    warning.can_move_to_func = function()
        return true
    end

    warning.update_func = function(self)
        self:highlight_tile(Highlight.Flash)

        remaining = remaining - 1
        if remaining <= 0 then
            create_thunderbolt(
                source,
                tile,
                damage,
                crack_panels,
                stun_strike
            )
            self:erase()
        end
    end

    warning.battle_end_func = function(self)
        self:erase()
    end

    source.field:spawn(warning, tile)

    return warning
end

local function spawn_tile_sequence_controller(
    user,
    damage,
    tiles,
    interval,
    crack_panels,
    stun_all_strikes
)
    if #tiles == 0 then
        return nil
    end

    local source = create_attack_source(user)
    local origin_tile = source.origin_tile

    if not origin_tile then
        return nil
    end

    local controller = create_timing_controller(source)
    local index = 1
    local elapsed = 0
    local next_fire = 1
    local bolt_interval = interval or 10

    controller.update_func = function(self)
        elapsed = elapsed + 1

        if elapsed < next_fire then
            return
        end

        local tile = tiles[index]
        if tile and not tile:is_edge() then
            schedule_thunder_strike(
                source,
                tile,
                damage,
                crack_panels,
                stun_all_strikes
            )
        end

        index = index + 1
        if index > #tiles then
            self:erase()
            return
        end

        next_fire = elapsed + bolt_interval
    end

    source.field:spawn(controller, origin_tile)

    return controller
end

local function spawn_tracking_controller(
    user,
    damage,
    strikes,
    interval,
    crack_panels,
    stun_last_strike
)
    local source = create_attack_source(user)
    local origin_tile = source.origin_tile

    if not origin_tile then
        return nil
    end

    local fallback_tile = origin_tile:get_tile(source.facing, 1)
    local controller = create_timing_controller(source)
    local shots_fired = 0
    local elapsed = 0
    local next_fire = 1
    local bolt_interval = interval or 18
    local max_strikes = strikes or 5

    controller.update_func = function(self)
        elapsed = elapsed + 1

        if elapsed < next_fire then
            return
        end

        local tile = find_nearest_target_tile(
            source.field,
            source.team,
            source.origin_tile
        )

        if (not tile or tile:is_edge())
            and fallback_tile
            and not fallback_tile:is_edge()
        then
            tile = fallback_tile
        end

        local strike_number = shots_fired + 1
        local stun_this_strike = stun_last_strike
            and strike_number == max_strikes

        if tile and not tile:is_edge() then
            schedule_thunder_strike(
                source,
                tile,
                damage,
                crack_panels,
                stun_this_strike
            )
        end

        shots_fired = strike_number
        if shots_fired >= max_strikes then
            self:erase()
            return
        end

        next_fire = elapsed + bolt_interval
    end

    source.field:spawn(controller, origin_tile)

    return controller
end

local function spawn_elecrow_controller(
    user,
    damage,
    start_distance,
    interval,
    crack_panels,
    stun_all_strikes
)
    local source = create_attack_source(user)
    local origin_tile = source.origin_tile
    local facing = source.facing

    if not origin_tile then
        return nil
    end

    local controller = create_timing_controller(source)
    local distance = start_distance or 1
    local bolt_interval = interval or 16
    local elapsed = 0
    local next_fire = 1

    controller.update_func = function(self)
        elapsed = elapsed + 1

        if elapsed < next_fire then
            return
        end

        local tile = origin_tile:get_tile(facing, distance)
        if not tile or tile:is_edge() then
            self:erase()
            return
        end

        schedule_thunder_strike(
            source,
            tile,
            damage,
            crack_panels,
            stun_all_strikes
        )

        distance = distance + 1
        next_fire = elapsed + bolt_interval
    end

    source.field:spawn(controller, origin_tile)

    return controller
end

local function spawn_elecwave_controller(
    user,
    damage,
    start_distance,
    interval,
    crack_panels
)
    local source = create_attack_source(user)
    local origin_tile = source.origin_tile
    local facing = source.facing

    if not origin_tile then
        return nil
    end

    local controller = create_timing_controller(source)
    local distance = start_distance or 1
    local bolt_interval = interval or 22
    local elapsed = 0
    local next_fire = 1

    controller.update_func = function(self)
        elapsed = elapsed + 1

        if elapsed < next_fire then
            return
        end

        local center_tile = origin_tile:get_tile(facing, distance)
        if not center_tile or center_tile:is_edge() then
            self:erase()
            return
        end

        local column_tiles = build_full_column_tiles(center_tile)
        for i = 1, #column_tiles do
            schedule_thunder_strike(
                source,
                column_tiles[i],
                damage,
                crack_panels,
                false
            )
        end

        distance = distance + 1
        next_fire = elapsed + bolt_interval
    end

    source.field:spawn(controller, origin_tile)

    return controller
end

local function do_elecrain(user, damage, crack_panels)
    local source = create_attack_source(user)
    local field = source.field
    local team = source.team
    local strike_tiles = {}

    field:find_characters(function(other)
        if other:get_team() == team
            or other:get_team() == Team.Other
            or other:will_erase_eof()
        then
            return false
        end

        local tile = other:get_current_tile()
        if tile and not tile:is_edge() then
            strike_tiles[#strike_tiles + 1] = tile
        end

        return false
    end)

    if #strike_tiles == 0 and source.origin_tile then
        local tile = source.origin_tile:get_tile(source.facing, 1)
        if tile and not tile:is_edge() then
            strike_tiles[#strike_tiles + 1] = tile
        end
    end

    for i = 1, #strike_tiles do
        schedule_thunder_strike(
            source,
            strike_tiles[i],
            damage,
            crack_panels,
            i == #strike_tiles
        )
    end
end

local CAST_FUNCTIONS = {
    voltrow = function(user, damage, crack_panels)
        spawn_elecrow_controller(
            user,
            damage,
            1,
            16,
            crack_panels,
            false
        )
    end,

    hollowplus = function(user, damage, crack_panels)
        local anchor = get_nearest_target_tile(user)
            or get_front_anchor_tile(user, 2)

        spawn_tile_sequence_controller(
            user,
            damage,
            build_cardinal_ring(anchor),
            8,
            crack_panels,
            false
        )
    end,

    cornervolt = function(user, damage, crack_panels)
        local anchor = get_nearest_target_tile(user)
            or get_front_anchor_tile(user, 2)

        spawn_tile_sequence_controller(
            user,
            damage,
            build_corner_ring(anchor),
            8,
            crack_panels,
            false
        )
    end,

    forkbolt = function(user, damage, crack_panels)
        spawn_tile_sequence_controller(
            user,
            damage,
            build_forkbolt_tiles(user),
            8,
            crack_panels,
            false
        )
    end,

    staticcross = function(user, damage, crack_panels)
        local anchor = get_front_anchor_tile(user, 2)

        spawn_tile_sequence_controller(
            user,
            damage,
            build_cardinal_ring(anchor),
            8,
            crack_panels,
            false
        )
    end,

    zigvolt = function(user, damage, crack_panels)
        spawn_tile_sequence_controller(
            user,
            damage,
            build_zigvolt_tiles(user),
            10,
            crack_panels,
            false
        )
    end,

    centercross = function(user, damage, crack_panels)
        local anchor = get_nearest_target_tile(user)
            or get_front_anchor_tile(user, 2)

        spawn_tile_sequence_controller(
            user,
            damage,
            build_center_cross(anchor),
            10,
            crack_panels,
            false
        )
    end,

    xburst = function(user, damage, crack_panels)
        local anchor = get_nearest_target_tile(user)
            or get_front_anchor_tile(user, 2)

        spawn_tile_sequence_controller(
            user,
            damage,
            build_xburst(anchor),
            10,
            crack_panels,
            false
        )
    end,

    elecchase = function(user, damage, crack_panels)
        spawn_tracking_controller(
            user,
            damage,
            5,
            40,
            crack_panels,
            true
        )
    end,

    elecrow = function(user, damage, crack_panels)
        spawn_elecrow_controller(
            user,
            damage,
            1,
            16,
            crack_panels,
            true
        )
    end,

    elecwave = function(user, damage, crack_panels)
        spawn_elecwave_controller(
            user,
            damage,
            1,
            35,
            crack_panels
        )
    end,

    elecrain = function(user, damage, crack_panels)
        do_elecrain(user, damage, crack_panels)
    end,

    thunderrain = function(user, damage, crack_panels)
        spawn_tracking_controller(
            user,
            damage,
            1,
            1,
            crack_panels,
            false
        )
    end,
}

function attacks.create(
    user,
    attack_name,
    damage,
    crack_panels,
    on_complete,
    counterable
)
    local cast_func = CAST_FUNCTIONS[attack_name]
    if not cast_func then
        return nil
    end

    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")

    action:override_animation_frames(make_frame_data({
        {1, 0.033},
        {2, 0.017},
        {2, 0.017},
        {3, 0.033},
        {4, 0.250},
    }))

    action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, actor)
        -- Attach the BUSTER immediately so there is no PLAYER_SHOOTING
        -- frame where ShockDOS appears without his arm cannon.
        local buster = self:add_attachment("BUSTER")
        local sprite = buster:sprite()
        sprite:set_texture(actor:get_texture(), true)
        sprite:set_layer(-2)
        sprite:enable_parent_shader(true)

        local animation = buster:get_animation()
        animation:copy_from(actor:get_animation())
        animation:set_state("BUSTER")
        animation:refresh(sprite)

        self:add_anim_action(2, function()
            if counterable ~= false then
                actor:toggle_counter(true)
            end
        end)

        self:add_anim_action(3, function()
            cast_func(actor, damage, crack_panels == true)
        end)
    end

    local completed = false

    action.action_end_func = function()
        user:toggle_counter(false)

        if completed then
            return
        end

        completed = true

        if on_complete then
            on_complete()
        end
    end

    return action
end

return attacks
