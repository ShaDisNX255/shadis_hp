local PACKAGE_ID = "com.shadis.mob.shockdos"
local CHARACTER_ID = "com.shadis.enemy.shockdos"

function package_requires_scripts()
    Engine.define_character(CHARACTER_ID, _modpath .. "enemy")
end

function package_init(package)
    package:declare_package_id(PACKAGE_ID)
    package:set_name("ShockDOS")
    package:set_description("A basic battle against ShockDOS.")
    package:set_speed(50)
    package:set_attack(50)
    package:set_health(600)
    package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)
    mob
        :create_spawner(CHARACTER_ID, Rank.V1)
        :spawn_at(5, 2)
end
