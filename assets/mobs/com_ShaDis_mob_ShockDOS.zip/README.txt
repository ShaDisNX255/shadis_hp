ShockDOS V1 package skeleton

Included:
- entry.lua
- enemy/entry.lua
- enemy/attacks.lua
- enemy/ShockDOS.animation
- enemy/gfx/bolt.animation

Add these existing assets before testing:
- preview.png
- enemy/navi_ShockDOS_battle.png
- enemy/gfx/bolt.png
- enemy/sfx/thunderBolt.ogg

Current balance:
- 600 HP
- Elec element
- Phase 1: 600-401 HP, two normal moves before easy attacks
- Phase 2: 400-201 HP, one move before medium attacks
- Phase 3: 200-1 HP, one move before hard attacks
- No custom battle music
