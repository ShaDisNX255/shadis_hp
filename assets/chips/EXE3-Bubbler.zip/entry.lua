nonce = function() end
 
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."spread_buster.png")
local BURST_TEXTURE = Engine.load_texture(_modpath.."spread_impact.png")
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package)
    package:declare_package_id("rune.wcity.legacy.bubbler")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"P","Q","R"})
 
    local props = package:get_card_props()
    props.shortname = "Bubbler"
    props.damage = 50
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Explodes 1 square behind"  
 end

 
function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."spread_buster.animation")
		buster_anim:set_state("DEFAULT")
		
		local cannonshot = create_attack(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot, tile)
	end
    return action
end

local function spawn_burst_fx(field, tile)
    if not tile or tile:is_edge() then
        return
    end

    local fx = Battle.Artifact.new()
    fx:set_texture(BURST_TEXTURE, true)
    fx:get_animation():load(_modpath.."spread_impact.animation")
    fx:get_animation():set_state("DEFAULT")
    fx:get_animation():on_complete(function()
        fx:erase()
    end)
    fx:set_height(-16.0)

    field:spawn(fx, tile)
end

local function spawn_burst_hit(user, props, tile)
    if not tile or tile:is_edge() then
        return
    end

    local burst = Battle.Spell.new(user:get_team())

    burst:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact,
            Element.Aqua,
            user:get_context(),
            Drag.None
        )
    )

    burst._frames_alive = 0

    burst.update_func = function(self, dt)
        self._frames_alive = self._frames_alive + 1

        if self._frames_alive == 1 then
            self:get_current_tile():attack_entities(self)
        elseif self._frames_alive >= 3 then
            self:delete()
        end
    end

    burst.attack_func = function(self, other)
        -- Damage is handled by hit props; no chained explosion needed.
    end

    burst.delete_func = function(self)
        self:erase()
    end

    user:get_field():spawn(burst, tile)
end

local function tile_has_enemy_or_obstacle(tile, team)
    if not tile or tile:is_edge() then
        return false
    end

    local chars = tile:find_characters(function(c)
        return c and not c:is_deleted() and c:get_team() ~= team
    end)

    if chars and #chars > 0 then
        return true
    end

    local obstacles = tile:find_obstacles(function(o)
        return o and not o:is_deleted() and o:get_team() ~= team
    end)

    return obstacles and #obstacles > 0
end

local function explode_at_tile(user, props, field, tile, direction)
    if not tile or tile:is_edge() then
        return
    end

    -- Visual explosion on the tile Bubbler collided with
    spawn_burst_fx(field, tile)

    -- Visual + real hit one tile behind
    local behind_tile = tile:get_tile(direction, 1)
    if behind_tile and not behind_tile:is_edge() then
        spawn_burst_fx(field, behind_tile)
        spawn_burst_hit(user, props, behind_tile)
    end
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact, 
            Element.Aqua,
            user:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt)
        if self._delete_timer then
            self._delete_timer = self._delete_timer - 1
            if self._delete_timer <= 0 then
                self:delete()
            end
            return
        end

        if self._impact_started then
            return
        end

        local current_tile = self:get_current_tile()

        if not current_tile or current_tile:is_edge() then
            if self.slide_started then
                self:delete()
            end
            return
        end

        -- Important:
        -- If there is something to hit on this tile, stop here.
        -- Do NOT slide to the next tile in the same update.
        if tile_has_enemy_or_obstacle(current_tile, self:get_team()) then
            self._impact_started = true
            self._impact_tile = current_tile
            self._exploded = true
            self._delete_timer = 4

            -- Explode even if the front target blocks/guards.
            explode_at_tile(user, props, self:get_field(), current_tile, direction)

            -- Still attempt front damage. If the front target guards, only this part is blocked.
            current_tile:attack_entities(self)

            return
        end

        if self:is_sliding() == false then
            local dest = self:get_tile(direction, 1)
            local ref = self

            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true
            end)
        end
    end
    spell.attack_func = function(self, other)
        -- Main explosion is handled in update_func so guard/block cannot swallow it.
        -- Keep this as a fallback in case the engine reports a direct hit
        -- before our manual tile collision path catches it.
        if self._exploded then
            return
        end

        self._exploded = true

        local current_tile = self._impact_tile
        if not current_tile and other and other.get_current_tile then
            current_tile = other:get_current_tile()
        end
        current_tile = current_tile or self:get_current_tile()

        explode_at_tile(user, props, self:get_field(), current_tile, direction)

        self._delete_timer = 3
    end

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(AUDIO, AudioPriority.Immediate)
	return spell
end