local print_debug = false

local SHIELD_TEXTURE = Engine.load_texture(_folderpath.."gfx/shield.grayscaled.png")
local SHIELD_ANIMPATH = _folderpath.."gfx/shield.animation"
local GUARD_TEXTURE = Engine.load_texture(_folderpath.."gfx/guard.grayscaled.png")
local GUARD_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/guard.png")
local GUARD_ANIMPATH = _folderpath.."gfx/guard.animation"
local SHOCKWAVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/burst.grayscaled.png")
local SHOCKWAVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/burst.png")
local SHOCKWAVE_ANIMPATH = _folderpath.."gfx/burst.animation"

local GUARD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_6.ogg", true)
local SHIELD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_308.ogg", true)
local REFLECMET_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_234.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[ReflecMet] "..text)
    end
end

local reflecmet = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function spawn_shock_wave(user, props, tile)
    local spawn_next
    spawn_next = function()
        if not tile or tile:is_edge() then return end
        local spell = graphic_init("spell", 0, -16*2, SHOCKWAVE_TEXTURE, SHOCKWAVE_PALETTE, SHOCKWAVE_ANIMPATH, -3, "0", Playback.Once, user, user:get_facing(), false, true, true)
        spell:set_hit_props(
            HitProps.new()
            :dmg(props.damage)
            :impact()
            --:flinch()
            --:flash()
            :elem(props.element)
            :from(user:get_context())
        )
        spell.frames = 1
        spell.attacking = true
        spell.update_func = function(self)
            if self.attacking then
                self:get_tile():attack_entities(self)
            end
            if self.frames == 3 then
                tile = tile:get_tile(self:get_facing(), 1)
                spawn_next()
            end
            if self.frames == 12 then
                self:delete()
            end
            self.frames = self.frames + 1
        end
        spell.on_spawn_func = function(self)
            debug_print("spawned on tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        end
        spell.collision_func = function(self, other)
            debug_print("collided tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
            self.attacking = false
        end
        spell.attack_func = function(self, other, judge)
            debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        end
        spell.battle_end_func = function(self)
            self:delete()
        end
        spell.delete_func = function(self)
            self:erase()
        end
        user:get_field():spawn(spell, tile)
    end
    spawn_next()
end

reflecmet.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self)
        debug_print("in custom card action execute_func()!")
        local step = Battle.Step.new()
        self:add_step(step)

        local actor = self:get_actor()
        local guarding_defense_rule = nil
        local guarding = true

        local guard_animation = nil
        local guard_sprite = nil
        local guard_attachment = nil

        local offset = {}
        offset.point = actor:get_animation():point("METGUARD")
        offset.x = 16
        offset.y = 0
        if offset.point.x == 0 and offset.point.y == 0 then
        else
            offset.x = offset.point.x*2
        end

        local function add_defense()
            guard_attachment = graphic_init("artifact", (offset.x*2), (offset.y*2), SHIELD_TEXTURE, nil, SHIELD_ANIMPATH, -1, reflecmet.shield_type1, Playback.Once, user, user:get_facing(), false, true)
            guard_sprite = guard_attachment:sprite()
            guard_animation = guard_attachment:get_animation()
            guard_attachment:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/"..reflecmet.shield_palette..".png"))
            guard_attachment:set_palette(guard_attachment:get_base_palette())
            guarding_defense_rule = Battle.DefenseRule.new(3, DefenseOrder.CollisionOnly)
            guarding_defense_rule.can_block_func = function(judge, attacker, defender)
                if not guarding then
                    return
                end
                local hit_props = attacker:copy_hit_props() 
                if hit_props:has_flags(Hit.Breaking) then
                    --can't block breaking hits with guard
                    return
                end
                judge:block_damage()
                if hit_props.flags & Hit.Impact == Hit.Impact then
                    local offset_x = math.random(-7,8)
                    local offset_y = math.random(-24,-9)
                    local tink = graphic_init("artifact", (offset_x*2), (offset_y*2), GUARD_TEXTURE, GUARD_PALETTE, GUARD_ANIMPATH, -999, "0", Playback.Once, user, user:get_facing(), true, true, true)
                    user:get_field():spawn(tink, user:get_tile())
                    Engine.play_audio(GUARD_AUDIO, AudioPriority.Immediate)
                    if not guarding_defense_rule.has_reflected then
                        guarding_defense_rule.has_reflected = true
                        local spawn_component = Battle.Component.new(user, Lifetimes.Battlestep)
                        spawn_component.update_func = function(self)
                            debug_print("spawn_component update_func")
                            spawn_shock_wave(user, props, user:get_tile(user:get_facing(), 1))
                            self:eject()
                        end
                        user:register_component(spawn_component)
                        Engine.play_audio(REFLECMET_AUDIO, AudioPriority.Immediate)
                    end
                end
            end
            user:add_defense_rule(guarding_defense_rule)
            user:get_field():spawn(guard_attachment, user:get_tile())
            Engine.play_audio(SHIELD_AUDIO, AudioPriority.Immediate)
        end
        local function remove_defense()
            user:remove_defense_rule(guarding_defense_rule)
            guarding = false
        end
        local function finish_action()
            step:complete_step()
        end
        -- +1 because guarding time should last that long, etc
        -- Or maybe +1 because first update runs twice. Either way, good right now.
        local callbacks = {
            [0] = add_defense,
            [63 + 1] = remove_defense,
            -- TODO: -2 because action ends late? Will this change?
            -- Note: In BN6, this timing should allow movement on the 
            -- frame the action ends. ONB doesn't, so despite the idle 
            -- frame, this should be good.
            [63 + 3 + 1 -2] = finish_action
        }
        local i = 0
        step.update_func = function()
            local f = callbacks[i]
            if f then 
                f()
            end
            i = i + 1
        end
        action.action_end_func = function()
            --guard_attachment:set_palette(guard_attachment:get_base_palette())
            guard_animation:set_state(reflecmet.shield_type2)
            guard_animation:refresh(guard_sprite)
            guard_animation:on_complete(function()
                guard_attachment:delete()
            end)
            if guarding then 
                user:remove_defense_rule(guarding_defense_rule)
            end
        end
    end
    return action
end

return reflecmet