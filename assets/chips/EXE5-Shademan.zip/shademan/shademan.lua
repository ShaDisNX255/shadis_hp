local print_debug = false

local SHADEMAN_TEXTURE = Engine.load_texture(_folderpath.."gfx/shademan.grayscaled.png")
local SHADEMAN_ANIMPATH = _folderpath.."gfx/shademan.animation"
local CRUSHNOISE_TEXTURE = Engine.load_texture(_folderpath.."gfx/crushnoise.grayscaled.png")
local CRUSHNOISE_ANIMPATH = _folderpath.."gfx/crushnoise.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_109.ogg", true)
local SHADEMAN_SWING_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_204.ogg", true)
local CRUSHNOISE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_61.ogg", true)
local SUCCESS_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_4.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[ShadeMan] "..text)
    end
end

local shademan = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_crush_noise_hitbox(user, hit_props, facing, field, team, tile)
    if not tile --[[or tile:is_edge()]] then return end
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(hit_props)
    spell.frames = 0
    spell.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames == 59 then
            self:delete()
        end
        tile:highlight(Highlight.Solid)
        tile:attack_entities(self)
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, tile)
    return spell
end

local function create_crush_noise(user, hit_props, facing, field, team, tile, type)
    Engine.play_audio(CRUSHNOISE_AUDIO, AudioPriority.Immediate)
    if not tile --[[or tile:is_edge()]] then return end
    local palette = Engine.load_texture(_folderpath.."gfx/palette/crushnoise-"..type..".png")
    local noise = graphic_init("spell", 0, -19*2, CRUSHNOISE_TEXTURE, palette, CRUSHNOISE_ANIMPATH, -3, "0", Playback.Loop, user, facing)
    noise.frames = 0
    noise.on_spawn_func = function(self)
        create_crush_noise_hitbox(user, hit_props, facing, field, team, tile)
        create_crush_noise_hitbox(user, hit_props, facing, field, team, tile:get_tile(Direction.Up, 1))
        create_crush_noise_hitbox(user, hit_props, facing, field, team, tile:get_tile(Direction.Down, 1))
        create_crush_noise_hitbox(user, hit_props, facing, field, team, tile:get_tile(Direction.reverse(facing), 1))
    end
    noise.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames == 60 then --59
            self:delete()
        end
    end
    noise.battle_end_func = function(self)
        self:delete()
    end
    noise.delete_func = function(self)
        self:erase()
    end
    field:spawn(noise, tile)
    return noise
end

shademan.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_MOVE")
    local frame_sequence = make_frame_data({
        {1,0.0}, {2,0.017}, {3,0.017}, {4,0.517}, {4,0.017}, {4,0.55}, {4,0.017}, {3,0.017}, {2,0.017}, {1,0.4}
    })
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    ----
    local voice_lines = {
        [1] = {frame=29-1, line="kurasshunoizu1", text="Crush Noise!"}, -- Stream #31
        [2] = {frame=29-1, line="kurasshunoizu2", text="Crush Noise!"}, -- Stream #31
    }
    local random_voice = math.random(1,#voice_lines)
    local read_voice_input = true
    local use_voice = false
    ----
    local combo_reading = false
    local combo_progress = "0"
    local combo_2 = false
    local combo_3 = false
    local combo_success = "NORMAL"
    ----
    action.update_func = function(self)
        if read_voice_input and user:input_has(Input.Held.Use) then
            use_voice = true
            read_voice_input = false
        end
        ----
        if combo_reading then
            if combo_progress == "0" and user:input_has(Input.Held.Down) then
                debug_print("1")
                combo_progress = "1"
            end
            if combo_progress == "1" then
                if     user:input_has(Input.Held.Down) and user:input_has(Input.Held.Right) then
                    debug_print("2R")
                    combo_progress = "2R"
                elseif user:input_has(Input.Held.Down) and user:input_has(Input.Held.Left)  then
                    debug_print("2L")
                    combo_progress = "2L"
                end
            end
            if combo_progress == "2R" and user:input_has(Input.Held.Use) and user:input_has(Input.Held.Right) then
                debug_print("3R")
                combo_progress = "3R"
                combo_success = "PARALYZE"
                Engine.play_audio(SUCCESS_AUDIO, AudioPriority.Immediate)
            end
            if combo_progress == "2L" and user:input_has(Input.Held.Use) and user:input_has(Input.Held.Left)  then
                debug_print("3L")
                combo_progress = "3L"
                combo_success = "CONFUSE"
                Engine.play_audio(SUCCESS_AUDIO, AudioPriority.Immediate)
            end
        end
    end
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local navi = nil
        local navi_anim = nil
        local navi2 = nil
        local navi2_anim = nil
        self:add_anim_action(4, function()
            actor:hide()
        end)
        self:add_anim_action(5, function()
            read_voice_input = false
            actor:get_animation():set_playback_speed(0)
            
            navi = graphic_init("spell", 0, 0, SHADEMAN_TEXTURE, nil, SHADEMAN_ANIMPATH, -1, "WARP2", Playback.Once, user, facing, false, true)
            navi:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/shademan-"..shademan.palette_type..".png"))
            navi:set_palette(navi:get_base_palette())
            navi_anim = navi:get_animation()
            navi.state = "SPAWN"
            navi.frames = 0

            local user_tile = user:get_tile()
            if user_tile:is_hole() then
                --navi.state = "DESPAWN"
            end

            local base_damage = props.damage
            local panel_damage = 0
            local finalized_damage = 0
            if shademan.damage_type ~= "NORMAL" then
                base_damage = 140
                if shademan.damage_type == "HOLY" then
                    local holy_query = function(o)
                        return o and o:get_state() == TileState.Holy and o:get_team() == team
                    end
                    local find_holy = field:find_tiles(holy_query)
                    if find_holy[1] ~= nil then
                        if #find_holy > 10 then
                            panel_damage = (10 * 10)
                        else
                            panel_damage = (10 * #find_holy)
                        end
                    end
                elseif shademan.damage_type == "DARK" then
                    local flinch_count = Battle.Player.from(user):get_flinch_count()
                    if flinch_count > 10 then
                        panel_damage = (5 * 10)
                    else
                        panel_damage = (5 * flinch_count)
                    end
                end
                debug_print("base damage is "..base_damage..".")
                local multiplied_damage = props.damage
                if multiplied_damage ~= 777 then
                    if multiplied_damage % 2 == 0 then
                        debug_print("multiplied pre-damage is an EVEN number.")
                        if multiplied_damage / 2 < 777 then
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage) - 777)))
                            if not print_debug then
                                print("ShadeMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                            end
                        else
                            finalized_damage = math.floor((base_damage + panel_damage + ((multiplied_damage / 2) - 777))*2)
                            if not print_debug then
                                print("ShadeMan: ("..base_damage.."+"..panel_damage.."+"..math.floor((multiplied_damage / 2) - 777)..")*2 = "..finalized_damage)
                            end
                        end
                    else
                        debug_print("multiplied pre-damage is an ODD number.")
                        finalized_damage = math.floor(base_damage + panel_damage + (multiplied_damage - 777))
                        if not print_debug then
                            print("ShadeMan: "..base_damage.."+"..panel_damage.."+"..math.floor(multiplied_damage - 777).." = "..finalized_damage)
                        end
                    end
                else
                    debug_print("multiplied pre-damage is NOT multiplied at all.")
                    finalized_damage = math.floor(base_damage + panel_damage)
                    if not print_debug then
                        print("ShadeMan: "..base_damage.."+"..panel_damage.."+0 = "..finalized_damage)
                    end
                end
                debug_print("finalized damage is "..finalized_damage..".")
            else
                finalized_damage = base_damage
            end
            local holy_k = 0
            local holy_c = 0.033
		    local holy_is_reveal = false
		    local holy_own_tiles = field:find_tiles(function(tile) 
		    	return not tile:is_edge() and tile:get_state() == TileState.Holy and tile:get_team() == user:get_team()
		    end)

            navi.on_spawn_func = function(self)
                debug_print("spawned on tile ("..user_tile:x()..";"..user_tile:y()..")")
                Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
                --combo_reading = true
            end
            navi.update_func = function(self, dt)
			    if holy_k < 9 and holy_c <= 0 and shademan.damage_type == "HOLY" then
				    holy_k = holy_k + 1
				    holy_c = 0.033
			    	if holy_is_reveal then
			    		holy_is_reveal = false
			    		for i=1, #holy_own_tiles do
			    			holy_own_tiles[i]:set_state(TileState.Holy)
			    		end
			    	else
			    		holy_is_reveal = true
			    		for j=1, #holy_own_tiles do
			    			holy_own_tiles[j]:set_state(TileState.Normal)
			    		end
			    	end
			    else
			    	holy_c = holy_c - dt
			    end
                self.frames = self.frames + 1
                if self.frames == voice_lines[random_voice].frame then
                    if use_voice then
                        print("ShadeMan: "..voice_lines[random_voice].text)
                        Engine.play_audio(Engine.load_audio(_folderpath.."sfx/voice/"..voice_lines[random_voice].line..".ogg", true), AudioPriority.Immediate)
                    end
                end
                if self.frames == 6-1 then
                    combo_reading = true
                end
                if self.frames == 30-1 then
                    combo_reading = false
                    Engine.play_audio(SHADEMAN_SWING_AUDIO, AudioPriority.Immediate)
                    navi_anim:set_state("CRUSHNOISE1")
                    navi_anim:refresh(navi:sprite())
                end
                if self.frames == 52-1 then
                    local hit_props = HitProps.new()
                    :dmg(finalized_damage)
                    :impact()
                    :flinch()
                    :flash()
                    :pierce()
                    :retangible()
                    :no_counter()
                    :from(user:get_context())
                    if combo_success == "PARALYZE" then
                        hit_props = HitProps.new()
                        :dmg(finalized_damage)
                        :impact()
                        :flinch()
                        :pierce()
                        :retangible()
                        :stun(frames(150))
                        :no_counter()
                        :from(user:get_context())
                    elseif combo_success == "CONFUSE" then
                        hit_props = HitProps.new()
                        :dmg(finalized_damage)
                        :impact()
                        :flinch()
                        :flash()
                        :pierce()
                        :retangible()
                        :confuse(frames(960))
                        :no_counter()
                        :from(user:get_context())
                    end
                    create_crush_noise(user, hit_props, facing, field, team, self:get_tile(facing, 2), combo_success)
                end
                if self.frames == 113-1 then
                    navi_anim:set_state("WARP1")
                    navi_anim:refresh(navi:sprite())
                end
                if self.frames == 120-1 then
                    self:delete()
                end
            end
            navi.delete_func = function()
                actor:get_animation():set_playback_speed(1)
            end
            navi.can_move_to_func = function(tile)
                return true
            end
            field:spawn(navi, user_tile)
        end)
        self:add_anim_action(7, function()
            actor:reveal()
        end)
    end
    action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
        local actor = self:get_actor()
        actor:reveal()
    end
	return action
end

return shademan