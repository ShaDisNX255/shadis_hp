local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local THUNDERBALL_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunderball.grayscaled.png")
local THUNDERBALL_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/thunderball.png")
local THUNDERBALL_ANIMPATH = _folderpath.."gfx/thunderball.animation"

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png")
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local THUNDERBALL_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_71.ogg", true)
local DARKTHUNDER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_164.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[ThunderBall] "..text)
    end
end

local thunderball = {}

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function highlighter(user, tile)
	local hler = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
	hler.frames = 0
	hler.update_func = function(self)
		self.frames = self.frames + 1
		if self.frames == 1 then
			self:highlight_tile(Highlight.Solid)
		elseif self.frames >= 2 then
			self:erase()
		end
	end
	user:get_field():spawn(hler, tile)
	return hler
end

local function execute(user, props, spawn_tile, hler)
	local saved_direction = user:get_facing()
	-- remember position of user at time of spawning attack, 
	-- to prevent the user from being able to influence the ball afterwards
	-- The origin is the center of the sprite. Raise thunder upwards 10 pixels
	-- (keep in mind scale is 2, e.g. 10 * 2 = 20)
	local ball_type = thunderball.ball_type
	local spell = graphic_init("spell", 0, -10*2, THUNDERBALL_TEXTURE, THUNDERBALL_ANIMPATH, ball_type, Playback.Loop, -3, user, Direction.Right, true)
    spell:store_base_palette(THUNDERBALL_PALETTE)
    spell:set_palette(spell:get_base_palette())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Stun,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	spell.collided = false
	local ver_choice = thunderball.ver_choice -- controls version stats, level 3 is on par with BDT stats
	local version_options = {
		timeout = {300, 390, 480},
		speed = {60, 50, 40},
	}
	local version = {
		timeout = version_options.timeout[ver_choice],
		speed = version_options.speed[ver_choice],
	}

	-- the weak Thunder Ball lasts for 300 frames
	local timeout = version.timeout
	local elapsed = 0
	local target = nil

	local field = user:get_field()
	spell.on_spawn_func = function(self)
		if ball_type == "0" then
			Engine.play_audio(THUNDERBALL_AUDIO, AudioPriority.Low)
		elseif ball_type == "1" then
			Engine.play_audio(DARKTHUNDER_AUDIO, AudioPriority.Low)
		end
	end
	local direction = nil
	spell.update_func = function(self)
		elapsed = elapsed + 1
		if elapsed > timeout then
			self:erase()
		end
		local tile = self:get_tile()
		-- delete when going off field
		if tile:is_edge() then
			self:erase()
		end
		-- Find target if we don't have one
		if not target then
			local closest_dist = math.huge
			field:find_characters(function(character)
				local character_team = character:get_team()
				if (
					character_team == user:get_team() or
					character_team == Team.Other or
					character:will_erase_eof()
				) then
					return false
				end
				if not target then
					target = character
				else
					-- If the distance to one enemy is shorter than the other, target the shortest enemy path
					local dist = math.abs(tile:x() - character:get_tile():x()) + math.abs(tile:y() - character:get_tile():y())
					if dist < closest_dist then
						target = character
						closest_dist = dist
					end
				end
				return false
			end)
			-- We have found a target
			-- Create a notifier so we can null the target when they are deleted
			if target then
				local callback = function()
					target = nil
				end
				field:notify_on_delete(target:get_id(), self:get_id(), callback)
			end
		end
		-- If sliding is flagged to false, we know we've ended a move
		if not self:is_sliding() then
			-- If there are no targets, aimlessly move right or left
			-- (save_direction gets determined once at spawn time)
			direction = saved_direction
			if target then
				local target_tile = target:get_tile()
				if target_tile then
					if target_tile:x() < tile:x() then
						direction = Direction.Left
					elseif target_tile:x() > tile:x() then
						direction = Direction.Right
					elseif target_tile:y() < tile:y() then
						direction = Direction.Up
					elseif target_tile:y() > tile:y() then
						direction = Direction.Down
					end
					-- Poll if target is flagged for deletion, remove our mark
					if target:will_erase_eof() then
						target = nil
					end
				end
			end
			local query = function(o)
				return not o:is_team(self:get_team())
			end
			if not self.collided and #self:get_tile():find_characters(query) <= 0 then
				-- Always slide to the tile we're moving to
				local next_tile = self:get_tile(direction, 1)
				self:slide(next_tile, frames(version.speed), frames(0), ActionOrder.Voluntary, nil)
			end
		end
		-- Always affect the tile we're occupying
		tile:attack_entities(self)
		if self.collided then
			if hler and not hler:is_deleted() then
				hler:erase()
			end
			self:highlight_tile(Highlight.None)
			self:get_animation():on_complete(function() self:erase() end)
		else
			self:highlight_tile(Highlight.Solid)
		end
	end
	spell.collision_func = function(self)
		self.collided = true
	end
	spell.attack_func = function(self, other)
		debug_print("ThunderBall attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
		local offset_y = math.random(-8,7)
		local offset_x = math.random(-8,7)
		if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, self, self:get_facing(), true)
    	hit_fx:store_base_palette(EFFECT_PALETTE)
    	hit_fx:set_palette(hit_fx:get_base_palette())
        hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
        self:get_field():spawn(hit_fx, self:get_tile())
        if Battle.Obstacle.from(other) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end
	spell.can_move_to_func = function(tile)
		return true
	end
	field:spawn(spell, spawn_tile)
	return spell
end

thunderball.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local frame1 = {1,0.0} --(+)1 frame
    local frame2 = {2,0.033}
    local frame3 = {3,0.033}
    local frame4 = {4,0.183}
    local frame5 = {4,0.333} --(-)1 frame
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5})
    action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
		buster_sprite:set_texture(user:get_texture(), true)
		buster_sprite:set_layer(-1)
		local buster_anim = buster:get_animation()
		buster_anim:copy_from(user:get_animation())
		buster_anim:set_state("BUSTER")
		buster_anim:refresh(buster_sprite)
		user:toggle_counter(true)
		local thehler = highlighter(user, user:get_tile(user:get_facing(), 1))
		self:add_anim_action(2,function()
			execute(user, props, user:get_tile(user:get_facing(), 1), thehler)
		end, false)
		self:add_anim_action(5,function()
			user:toggle_counter(false)
		end)
	end
	action.action_end_func = function()
        debug_print("in custom card action action_end_func()!")
		user:toggle_counter(false)
	end
	return action
end

return thunderball