local thunderball = include("thunderball/thunderball.lua")

local DAMAGE = 40

thunderball.ver_choice = 1
thunderball.ball_type = "0"

thunderball.codes = {"B","R","S","*"}
thunderball.shortname = "ThndrBal"
thunderball.damage = DAMAGE
thunderball.time_freeze = false
thunderball.element = Element.Elec
thunderball.description = "Pralyzing electric attack!"
thunderball.long_description = "A slow-moving paralyzing electic attack!"
thunderball.can_boost = true
thunderball.card_class = CardClass.Standard
thunderball.limit = 3
thunderball.mb = 7

function package_init(package)
    package:declare_package_id("com.wcity.OFC.card.EXE6-029-ThunderBall")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(thunderball.codes)

    local props = package:get_card_props()
    props.shortname = thunderball.shortname
    props.damage = thunderball.damage
    props.time_freeze = thunderball.time_freeze
    props.element = thunderball.element
    props.description = thunderball.description
    props.long_description = thunderball.long_description
    props.can_boost = thunderball.can_boost
	props.card_class = thunderball.card_class
	props.limit = thunderball.limit
end

card_create_action = thunderball.card_create_action