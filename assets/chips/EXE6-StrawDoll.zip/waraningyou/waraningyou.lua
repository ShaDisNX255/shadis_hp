local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local ATTACHMENT_TEXTURE = Engine.load_texture(_folderpath.."gfx/attachment.png")
local ATTACHMENT_ANIMPATH = _folderpath.."gfx/attachment.animation"

local WARANINGYOU_TEXTURE = Engine.load_texture(_folderpath.."gfx/waraningyou.png")
local WARANINGYOU_ANIMPATH = _folderpath.."gfx/waraningyou.animation"
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."gfx/shadow.png")
local SHADOW_ANIMPATH = _folderpath.."gfx/shadow.animation"

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"

local POINT_TEXTURE = Engine.load_texture(_folderpath.."gfx/point.png")
local POINT_ANIMPATH = _folderpath.."gfx/point.animation"
local POINT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_335.ogg", true)

local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_345.ogg", true)

local HIT_IMPACT_TEXTURE = Engine.load_texture(_folderpath.."gfx/hit_impact.png")
local HIT_IMPACT_ANIMPATH = _folderpath.."gfx/hit_impact.animation"
local HIT_CURSE_TEXTURE = Engine.load_texture(_folderpath.."gfx/hit_curse.png")
local HIT_CURSE_ANIMPATH = _folderpath.."gfx/hit_curse.animation"

local THROW_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_118.ogg", true)
local SMOKE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_264.ogg", true)

local ObstacleInfo = include("ObstacleInfo.lua")

local function debug_print(text)
    if print_debug then
        print("[WaraNingyou] "..text)
    end
end

local waraningyou = {}

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    --[[
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end]]
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_hitbox(user, damage, field, facing, tile)
    local hitbox = graphic_init("spell", 0, 0, false, false, false, false, false, user, facing)
    hitbox:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce,
            Element.None,
            user:get_id(),
            Drag.None
        )
    )
    hitbox.on_spawn_func = function()
        debug_print("attack spawned on tile ("..tile:x()..";"..tile:y()..")")
    end
    hitbox.update_func = function(self)
		tile:attack_entities(self)
		self:erase()
    end
    hitbox.attack_func = function(self, other)
        debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
		local offset_y = math.random(-8,6)
		local offset_x = math.random(-9,8)
		if facing == Direction.Left then offset_x = -offset_x end
		local hit_curse = graphic_init("artifact", other:get_tile_offset().x+other:get_offset().x+(offset_x*2), other:get_tile_offset().y+other:get_offset().y+(offset_y*2), HIT_CURSE_TEXTURE, HIT_CURSE_ANIMPATH, "0", Playback.Once, -999, user, facing)
		hit_curse:get_animation():on_complete(function() hit_curse:erase() end)
		field:spawn(hit_curse, tile)
        if Battle.Obstacle.from(other) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    field:spawn(hitbox, tile)
	return hitbox
end

local function create_point(user, field, facing, other)
	local point = graphic_init("artifact", other:get_tile_offset().x+other:get_offset().x, other:get_tile_offset().y+other:get_offset().y, POINT_TEXTURE, POINT_ANIMPATH, "0", Playback.Loop, -99, user, facing, true)
	point.frames = 0
	point.on_spawn_func = function(self)
		Engine.play_audio(POINT_AUDIO, AudioPriority.Low)
	end
	point.update_func = function(self)
		self.frames = self.frames + 1
		for i=15, 47, 16 do
			if self.frames == i then
				Engine.play_audio(POINT_AUDIO, AudioPriority.Low)
			end
		end
		if self.frames >= 60 then
			self:erase()
		end
	end
    field:spawn(point, other:get_tile())
end

local function create_curse(user, damage, doll, facing, field, team)
	print("StrawDoll: "..damage)
    debug_print("in create_curse()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self)
        debug_print("in custom card action execute_func()!")
		local a_frames = 0
		local step1 = Battle.Step.new()
		local targets = field:find_characters(function(t)
			return t and t:get_health() > 0 and not t:is_team(team)
		end)
		step1.update_func = function(self)
			a_frames = a_frames + 1
			if a_frames == 1 then
				if targets[1] ~= nil then
					for i=1, #targets do
						debug_print("target tile: ("..targets[i]:get_tile():x()..";"..targets[i]:get_tile():y()..")")
						create_point(user, field, facing, targets[i])
					end
				end
			elseif a_frames == 71 then
				if targets[1] ~= nil then
					for i=1, #targets do
						create_hitbox(user, damage, field, facing, targets[i]:get_tile())
					end
				end
			elseif a_frames >= 101 then
				self:complete_step()
			end
			for i=72, 88, 16 do
				if a_frames == i then
					if targets[1] ~= nil then
						for j=1, #targets do
							local offset_y = math.random(-30,-2)
							local offset_x = math.random(-14,13)
							if facing == Direction.Left then offset_x = -offset_x end
							local boom_effect = graphic_init("artifact", targets[j]:get_tile_offset().x+targets[j]:get_offset().x+(offset_x*2), targets[j]:get_tile_offset().y+targets[j]:get_offset().y+(offset_y*2), 	BOOM_TEXTURE, BOOM_ANIMPATH, "0", Playback.Once, -99, user, facing)
							boom_effect:get_animation():on_complete(function() boom_effect:erase() end)
							field:spawn(boom_effect, targets[j]:get_tile())
							Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
						end
					end
				end
			end
		end
		self:add_step(step1)
	end
	local meta = action:copy_metadata()
	meta.shortname = "Curse"
	meta.damage = damage
	meta.time_freeze = true
	action:set_metadata(meta)
	user:card_action_event(action, ActionOrder.Voluntary)
end

local function create_doll(user, facing, field, team, spawn_tile)
	local obs_doll = Battle.Obstacle.new(Team.Other)
	ObstacleInfo.set_cannot_be_targeted(obs_doll, false)
	ObstacleInfo.set_cannot_be_manipulated(obs_doll, false)
	ObstacleInfo.add_to_limit_1(obs_doll, team, field)
	obs_doll:set_name("WaraNingyou")
	obs_doll:set_facing(facing)
	obs_doll:set_texture(WARANINGYOU_TEXTURE, true)
	obs_doll:sprite():set_layer(0)
	obs_doll:share_tile(false)
	obs_doll:toggle_hitbox(true)
	obs_doll:set_float_shoe(false)
	obs_doll:set_air_shoe(false)
	obs_doll:set_health(10)
	local anim = obs_doll:get_animation()
	anim:load(WARANINGYOU_ANIMPATH)
	anim:set_state("0")
	anim:refresh(obs_doll:sprite())
				
	-- deletion process var
	local delete_self = nil
	local countdown = 430

	local total_damage = 0
	local punishing = false
	local cube_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
	cube_defense_rule.filter_statuses_func = function(hit_props)
		--print("Damage: "..hit_props.damage)
		if hit_props.damage > 0 then
			total_damage = total_damage + hit_props.damage
			hit_props.damage = -1
		else
			hit_props.damage = 0
		end
		hit_props.flags = hit_props.flags & (~Hit.Flinch)
		hit_props.flags = hit_props.flags & (~Hit.Flash)
		hit_props.flags = hit_props.flags & (~Hit.Stun)
		hit_props.flags = hit_props.flags & (~Hit.Root)
		hit_props.flags = hit_props.flags & (~Hit.Shake)
		hit_props.flags = hit_props.flags & (~Hit.Pierce)
		hit_props.flags = hit_props.flags & (~Hit.Retangible)
		hit_props.flags = hit_props.flags & (~Hit.Bubble)
		hit_props.flags = hit_props.flags & (~Hit.Freeze)
		hit_props.flags = hit_props.flags & (~Hit.Blind)
		hit_props.element = Element.None
		return hit_props
	end
	cube_defense_rule.can_block_func = function(judge, attacker, defender)
		local attacker_hit_props = attacker:copy_hit_props()
		if attacker_hit_props.damage == 0 then
			judge:block_damage()
			judge:block_impact()
		else
			punishing = true
		end
	end
	obs_doll:add_defense_rule(cube_defense_rule)
	local cube_component = Battle.Component.new(obs_doll, Lifetimes.Scene)
	cube_component.update_func = function(self, dt)
		if punishing then
			if total_damage > 0 then
				punishing = false
				local d_facing = obs_doll:get_facing()
				local d_field = obs_doll:get_field()
				create_curse(user, total_damage, obs_doll, d_facing, d_field, team)
				obs_doll:set_health(0)
				cube_component:eject()
			else
				punishing = false
			end
		end
	end
	obs_doll:register_component(cube_component)
	obs_doll.on_spawn_func = function(self)
		spawn_tile:set_state(TileState.Poison)
		Engine.play_audio(SMOKE_AUDIO, AudioPriority.Low)
		self:set_shadow(SHADOW_TEXTURE)
		self:show_shadow(true)
	end
	obs_doll.update_func = function(self)
		local tile = self:get_tile()
		if not tile or tile:is_hole() then
			self:set_health(0)
		end
		if tile:get_state() == TileState.Lava then
			tile:set_state(TileState.Normal)
			total_damage = 50
			punishing = true
		end
		if countdown > 0 then countdown = countdown - 1 else self:set_health(0) end
		
		-- deletion handler in main loop, starts running once something in here has requested deletion
		if delete_self then
			if type(delete_self) ~= "number" then
				delete_self = 2
			end
			if delete_self > 0 then
				delete_self = delete_self - 1
			elseif delete_self == 0 then
				delete_self = -1
				self:erase()
			end
		end
	end
	obs_doll.delete_func = function(self)
		if self:get_health() <= 0 then
    		local move_effect = graphic_init("artifact", 0, (-19*2), MOB_MOVE_TEXTURE, MOB_MOVE_ANIMPATH, "0", Playback.Once, -99, user, facing, true)
			move_effect:get_animation():on_complete(function() move_effect:erase() end)
			field:spawn(move_effect, self:get_tile())
		end
		if type(delete_self) ~= "number" then
			delete_self = true
		end
	end
	field:spawn(obs_doll, spawn_tile)
	--return obs_doll
	local doll_observer = Battle.Artifact.new()
end

--(Function by Keristero)
local function toss_spell(tosser, toss_height, target_tile, frames_in_air, arrival_callback)
    local starting_height = -100
    local start_tile = tosser:get_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(WARANINGYOU_ANIMPATH)
    spell_animation:set_state("0")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end
    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(WARANINGYOU_TEXTURE)
    spell:set_offset(spell.x_offset,spell.y_offset)
    spell:set_hit_props(
        HitProps.new(
            10,
            Hit.Impact | Hit.Flinch,
            Element.None,
            tosser:get_context(),
            Drag.None
        )
    )
	spell.on_spawn_func = function(self)
		self:set_shadow(SHADOW_TEXTURE)
		self:show_shadow(true)
	end
    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
			local new_x = self.x_offset
			if new_x%2 ~= 0 then
				new_x = new_x - 1
			end
			local new_y = self.y_offset
			if new_y%2 ~= 0 then
				new_y = new_y - 1
			end
            self:set_offset(new_x,0)
            self:set_elevation(-new_y)
			if self.y_offset >= -10 then
				target_tile:attack_entities(self)
			end
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.collision_func = function(self)
		self:delete()
	end
    spell.attack_func = function(self, other)
        debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
		local offset_y = math.random(-24,-9)
		local offset_x = math.random(-11,2)
		if facing == Direction.Left then offset_x = -offset_x end
		local hit_impact = graphic_init("artifact", other:get_tile_offset().x+other:get_offset().x+(offset_x*2), other:get_tile_offset().y+other:get_offset().y+(offset_y*2), HIT_IMPACT_TEXTURE, HIT_IMPACT_ANIMPATH, "0", Playback.Once, -999, user, facing)
		hit_impact:get_animation():on_complete(function() hit_impact:erase() end)
		field:spawn(hit_impact, target_tile)
        if Battle.Obstacle.from(other) == nil then
            if Battle.Player.from(tosser) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

waraningyou.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
	local action = Battle.CardAction.new(user, "PLAYER_THROW")
	local action_frame = 3
	if user:get_animation():has_state("PLAYER_THROW52") then
		action = Battle.CardAction.new(user, "PLAYER_THROW52")
		action_frame = 4
	end
	action:set_lockout(make_animation_lockout())
	local c_frames = 0
    action.update_func = function(self)
		c_frames = c_frames + 1
		if c_frames >= 15 then
            user:toggle_counter(false)
		end
	end
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()

        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(ATTACHMENT_TEXTURE)
        attachment_sprite:set_layer(-2)
        local attachment_animation = attachment:get_animation()
        attachment_animation:load(ATTACHMENT_ANIMPATH)
        attachment_animation:set_state("0")

        user:toggle_counter(true)
        Engine.play_audio(THROW_AUDIO, AudioPriority.Low)
		local query = function(ent)
			if ent:get_health() <= 0 or ent:get_id() == obs_cube:get_id() then return false end
			return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil
		end
        self:add_anim_action(action_frame, function()
            attachment_sprite:hide()
            --self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 60
            local toss_height = 100
            local target_tile = user:get_tile(facing,tiles_ahead)
            if not target_tile then
                return
            end
            action.on_landing = function()
				local chars = {}
				local obs = {}
				field:find_entities(function(e)
				  	local id = e:get_id()
				  	if Battle.Obstacle.from(e) then 
				  	  	table.insert(obs, id)
				  	elseif Battle.Character.from(e) then 
				  	  	table.insert(chars, id)
				  	end
				end)
                if not target_tile:is_hole() and #target_tile:find_entities(query) <= 0 and ((target_tile:is_reserved(chars) and target_tile:is_reserved(obs)) or (target_tile:is_reserved(chars) and not target_tile:is_reserved(obs)) or (not target_tile:is_reserved(chars) and not target_tile:is_reserved(obs))) then
					create_doll(user, facing, field, team, target_tile)
                else
					local offset_x = -1
					if facing == Direction.Left then offset_x = -offset_x end
					local move_effect = graphic_init("artifact", offset_x, (-19*2), MOB_MOVE_TEXTURE, MOB_MOVE_ANIMPATH, "0", Playback.Once, -99, user, facing, true)
					move_effect:get_animation():on_complete(function() move_effect:erase() end)
					field:spawn(move_effect, target_tile)
                end
            end
            toss_spell(user, toss_height, target_tile, frames_in_air, action.on_landing)
		end)
        self.action_end_func = function()
            --user:toggle_counter(false)
        end
    end
	action.action_end_func = function(self)
		user:toggle_counter(false)
	end
    return action
end

return waraningyou