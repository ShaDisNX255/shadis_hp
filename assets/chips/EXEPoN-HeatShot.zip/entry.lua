local shotgun = include("shotgun/shotgun.lua")

local DAMAGE = 40

shotgun.type = 1

shotgun.codes = {"B","C","H","*"}
shotgun.shortname = "HeatShot"
shotgun.damage = DAMAGE
shotgun.time_freeze = false
shotgun.element = Element.Fire
shotgun.description = "Spreads to 1 sqr behind!"
shotgun.long_description = "When hits, spreads to 1 square behind!"
shotgun.can_boost = true
shotgun.card_class = CardClass.Standard
shotgun.limit = 4
shotgun.mb = 16

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-014-HeatShot")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(shotgun.codes)

    local props = package:get_card_props()
    props.shortname = shotgun.shortname
    props.damage = shotgun.damage
    props.time_freeze = shotgun.time_freeze
    props.element = shotgun.element
    props.description = shotgun.description
    props.long_description = shotgun.long_description
    props.can_boost = shotgun.can_boost
	props.card_class = shotgun.card_class
	props.limit = shotgun.limit
end

card_create_action = shotgun.card_create_action