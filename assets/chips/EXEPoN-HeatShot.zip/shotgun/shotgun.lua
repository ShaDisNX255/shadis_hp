local DAMAGE = 30

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local SHOTGUN_TEXTURE = Engine.load_texture(_folderpath.."shotgun.png")
local SHOTGUN_ANIMPATH = _folderpath.."shotgun.animation"
local BURST_TEXTURE = Engine.load_texture(_folderpath.."burst.png")
local BURST_ANIMPATH = _folderpath.."burst.animation"
local BURST_AUDIO = Engine.load_audio(_folderpath.."EXE4_336.ogg")
local BUBBLE_TEXTURE = Engine.load_texture(_folderpath.."bubble.png")
local BUBBLE_ANIMPATH = _folderpath.."bubble.animation"
local BUBBLE_AUDIO = Engine.load_audio(_folderpath.."EXE4_119.ogg")
local HEAT_TEXTURE = Engine.load_texture(_folderpath.."heat.png")
local HEAT_ANIMPATH = _folderpath.."heat.animation"
local HEAT_AUDIO = Engine.load_audio(_folderpath.."EXE4_132.ogg")

local shotgun = {
    type = 1,

    codes = {"B","G","J","*"},
	shortname = "ShotGun",
	damage = DAMAGE,
	time_freeze = false,
	element = Element.None,
	description = "Spreads to 1 sqr behind!",
	long_description = "When hits, spreads to 1 square behind!",
	can_boost = true,
	card_class = CardClass.Standard,
	limit = 4,
	mb = 8
}

shotgun.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local frame1 = {1, 0.017}
	local frame2 = {2, 0.017}
	local frame3 = {3, 0.017}
	local frame4 = {4, 0.250}
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4})
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
	local original_offset = actor:get_offset()
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

		local buster = self:add_attachment("BUSTER")
		local sprite = buster:sprite()
		sprite:set_texture(actor:get_texture(), false)
		sprite:set_layer(-2)
        sprite:enable_parent_shader(true)
		local buster_anim = buster:get_animation()
		buster_anim:copy_from(actor:get_animation())
		buster_anim:set_state("BUSTER")
		buster_anim:refresh(sprite)
		local shotgun = buster:add_attachment("Origin")
		local shotgun_sprite = shotgun:sprite()
		shotgun_sprite:set_texture(SHOTGUN_TEXTURE)
		shotgun_sprite:set_layer(-1)
		local shotgun_anim = shotgun:get_animation()
		shotgun_anim:load(SHOTGUN_ANIMPATH)
		shotgun_anim:set_state("0")
		shotgun_anim:refresh(shotgun_sprite)
		self:add_anim_action(2, function()
            Engine.play_audio(BURST_AUDIO, AudioPriority.Low)
        end)
		self:add_anim_action(4, function()
			local tile = user:get_tile(facing, 1)
			create_attack(user, props, team, facing, field, tile)
        end)
		actor:set_offset(original_offset.x, original_offset.y)
	end
	action.action_end_func = function(self)
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function create_attack2(user, props, team, facing, field, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end
    	--print("Spread on tile ("..tile:x()..";"..tile:y()..")")
    	local spell = Battle.Spell.new(team)
    	spell:set_facing(facing)
    	spell:set_hit_props(
    	    HitProps.new(
    	        props.damage, 
    	        Hit.Impact, 
    	        props.element,
    	        user:get_id(), 
    	        Drag.None
    	    )
    	)
		local anim = spell:get_animation()
		anim:load(_folderpath.."testdot.animation")
		anim:set_state("0")
		anim:on_complete(function() spell:delete() end)
		local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
    	spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            self_tile:attack_entities(self)
			if 		props.element == Element.Aqua then
				if self_tile ~= nil and
					not self_tile:is_edge() and
					#self_tile:find_characters(query_TeamHP) <= 0 and 
					#self_tile:find_obstacles(query_TeamHP) <= 0 and 
					self_tile:get_state() == TileState.Lava
					then
					self_tile:set_state(TileState.Normal)
				end
			elseif	props.element == Element.Fire then
				if self_tile ~= nil and
					not self_tile:is_edge() and
					#self_tile:find_characters(query_TeamHP) <= 0 and 
					#self_tile:find_obstacles(query_TeamHP) <= 0 and 
					self_tile:get_state() == TileState.Grass
					then
					self_tile:set_state(TileState.Normal)
				end
			end
    	end
		spell.attack_func = function(self, ent)
			if Battle.Obstacle.from(ent) == nil then
				if Battle.Player.from(user) ~= nil then
					Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
				end
			else
				Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
			end
		end
		spell.battle_end_func = function(self)
			spell:delete()
		end
		spell.can_move_to_func = function(tile)
			return true
		end
		spell.delete_func = function(self)
			spell:erase()
		end
		if 		props.element == Element.Aqua then
			Engine.play_audio(BUBBLE_AUDIO, AudioPriority.Low)
			create_effect(facing, BUBBLE_TEXTURE, BUBBLE_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		elseif 	props.element == Element.Fire then
			Engine.play_audio(HEAT_AUDIO, AudioPriority.Low)
			create_effect(facing, HEAT_TEXTURE, HEAT_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		else
			create_effect(facing, BURST_TEXTURE, BURST_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		end
		field:spawn(spell, tile)
	end
    spawn()
end

function create_attack(user, props, team, facing, field, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end
		--print("Spread Gun attack spawned at tile ("..tile:x()..";"..tile:y()..")")
		local spell = Battle.Spell.new(team)
		spell.slide_started = false
		--[[local sprite = spell:sprite()
    	sprite:set_texture(Engine.load_texture(_folderpath.."testdot.png"), true)
		sprite:set_layer(-3)
    	local anim = spell:get_animation()
		anim:load(_folderpath.."testdot.animation")
		anim:set_state("0")]]
		spell:set_facing(facing)
		spell:set_hit_props(
    	    HitProps.new(
    	        0, 
    	        Hit.Impact, 
    	        Element.None,
    	        user:get_id(), 
    	        Drag.None
    	    )
    	)
		spell.update_func = function(self) 
    	    self:get_current_tile():attack_entities(self)
    	    if self:is_sliding() == false then
    	        if self:get_current_tile():is_edge() and self.slide_started then 
    	            self:delete()
    	        end
    	        local dest = self:get_tile(facing, 1)
    	        local ref = self
    	        self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, function()
    	            ref.slide_started = true 
    	        end)
    	    end
    	end
		spell.collision_func = function(self, ent)
			--print("Spread Gun attack collided tile ("..ent:get_current_tile():x()..";"..ent:get_current_tile():y()..")")
			create_attack2(user, props, team, facing, field, ent:get_current_tile())													                        --cur tile
			if 		shotgun.type == 1 then
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(facing, 1))													--forward
			elseif	shotgun.type == 2 then
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.join(Direction.Up, facing), 1))						--up-forward
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.join(Direction.Down, facing), 1))					--down-forward
			elseif	shotgun.type == 3 then
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.Up, 1))												--up
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.Down, 1))											--down
			else
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(facing, 1))													--forward
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.Up, 1))												--up
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.Down, 1))											--down
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.reverse(facing), 1))									--back
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.join(Direction.Up, facing), 1))						--up-forward
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.join(Direction.Down, facing), 1))					--down-forward
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.join(Direction.Up, Direction.reverse(facing)), 1))	--up-back
				create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.join(Direction.Down, Direction.reverse(facing)), 1))	--down-back
			end
			self:delete()
		end
    	spell.attack_func = function(self, other)
    	end
		spell.battle_end_func = function(self)
			self:delete()
		end
		spell.can_move_to_func = function(tile)
    	    return true
    	end
    	spell.delete_func = function(self)
			self:erase()
    	end
		field:spawn(spell, tile)
	end
    spawn()
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return shotgun