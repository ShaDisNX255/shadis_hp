local sword = include("sword/sword.lua")

local DAMAGE = 120

sword.type = 3
sword.palette = 0

sword.codes = {"B","D","N"}
sword.shortname = "BambBlde"
sword.damage = DAMAGE
sword.time_freeze = false
sword.element = Element.Wood
sword.description = "Wood swrd that cuts 2sq fwrd"
sword.long_description = "Wood sword that cuts 2 horizontal squares in front"
sword.can_boost = true
sword.card_class = CardClass.Standard
sword.limit = 2
sword.mb = 51

function package_init(package)
    package:declare_package_id("com.wcity.OFC.card.EXEPoN-050-BambooBlade")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(sword.codes)

    local props = package:get_card_props()
    props.shortname = sword.shortname
    props.damage = sword.damage
    props.time_freeze = sword.time_freeze
    props.element = sword.element
    props.description = sword.description
    props.long_description = sword.long_description
    props.can_boost = sword.can_boost
	props.card_class = sword.card_class
	props.limit = sword.limit
end

card_create_action = sword.card_create_action