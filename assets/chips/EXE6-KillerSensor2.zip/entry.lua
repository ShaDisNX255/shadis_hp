local killersensor = include("killersensor/killersensor.lua")

local DAMAGE = 130

killersensor.sensor_name = "KillerSensor2"
killersensor.sensor_health = 30
killersensor.sensor_palette = "v2"

killersensor.codes = {"N","U","Y"}
killersensor.shortname = "KlrSnsr2"
killersensor.damage = DAMAGE
killersensor.time_freeze = true
killersensor.element = Element.Elec
killersensor.description = "KillrsEye\nbeam attk\nwhen trig"
killersensor.long_description = "Beam attack when triggered by the KillersEye sensor"
killersensor.can_boost = true
killersensor.card_class = CardClass.Standard
killersensor.limit = 1
killersensor.mb = 35

function package_init(package)
    package:declare_package_id("com.wcity.OFC.card.EXE6-117-KillerSensor2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(killersensor.codes)

    local props = package:get_card_props()
    props.shortname = killersensor.shortname
    props.damage = killersensor.damage
    props.time_freeze = killersensor.time_freeze
    props.element = killersensor.element
    props.description = killersensor.description
    props.long_description = killersensor.long_description
    props.can_boost = killersensor.can_boost
	props.card_class = killersensor.card_class
	props.limit = killersensor.limit
end

card_create_action = killersensor.card_create_action