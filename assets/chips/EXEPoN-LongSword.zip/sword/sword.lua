local DAMAGE = 80

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local SLASH_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_slashes.png")
local SLASH_ANIMPATH = _folderpath.."spell_sword_slashes.animation"
local AUDIO = Engine.load_audio(_folderpath.."EXE4_13.ogg")

local BLADE_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_blades.png")
local BLADE_ANIMPATH = _folderpath.."spell_sword_blades.animation"
local FLAME_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_flame.png")
local FLAME_ANIMPATH = _folderpath.."spell_sword_flame.animation"
local AQUA_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_aqua.png")
local AQUA_ANIMPATH = _folderpath.."spell_sword_aqua.animation"
local ELEC_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_elec.png")
local ELEC_ANIMPATH = _folderpath.."spell_sword_elec.animation"
local BAMBOO_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_bamboo.png")
local BAMBOO_ANIMPATH = _folderpath.."spell_sword_bamboo.animation"

local sword = {
	type = 1,
	palette = 0,

	codes = {"E","L","S"},
	shortname = "Sword",
	damage = DAMAGE,
	time_freeze = false,
	element = Element.None,
	description = "Cuts enmy in front! Range: 1",
	long_description = "Cuts the enemy in front! Attack range: 1 square",
	can_boost = true,
	card_class = CardClass.Standard,
	limit = 4,
	mb = 12
}

sword.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	local frame1 = {1, 0.133}
	local frame2_1 = {2, 0.017}
	local frame2_2 = {2, 0.017}
	local frame3 = {3, 0.033}
	local frame4 = {4, 0.033}
	local frame5 = {4, 0.117}
	local frame_sequence = make_frame_data({frame1, frame2_1, frame2_2, frame3, frame4, frame4, frame4, frame4, frame4, frame5})
	local original_offset = actor:get_offset()
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()
		self:add_anim_action(1, function()
			actor:set_offset(original_offset.x, original_offset.y)
			Engine.play_audio(AUDIO, AudioPriority.Low)
		end)
		self:add_anim_action(2, function()
			local texture = nil
			local animpath = nil
			if 		props.element == Element.None then
				texture = BLADE_TEXTURE
				animpath = BLADE_ANIMPATH
			elseif	props.element == Element.Fire then
				texture = FLAME_TEXTURE
				animpath = FLAME_ANIMPATH
			elseif	props.element == Element.Aqua then
				texture = AQUA_TEXTURE
				animpath = AQUA_ANIMPATH
			elseif	props.element == Element.Elec then
				texture = ELEC_TEXTURE
				animpath = ELEC_ANIMPATH
			elseif	props.element == Element.Wood then
				texture = BAMBOO_TEXTURE
				animpath = BAMBOO_ANIMPATH
			end
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-1)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HILT")
			local blade = hilt:add_attachment("ENDPOINT")
			local blade_sprite = blade:sprite()
			blade_sprite:set_texture(texture)
			blade_sprite:set_layer(-2)
			local blade_anim = blade:get_animation()
			blade_anim:load(animpath)
			blade_anim:set_state("0")
		end)
		self:add_anim_action(3,function()
			local tile = user:get_tile(facing, 1)
			create_slash(user, props, team, facing, field, tile)
			if 		sword.type == 1 then
				local slash = create_effect(facing, SLASH_TEXTURE, SLASH_ANIMPATH, "DEFAULT", 0, 0, false, -3, field, tile)
				slash:set_palette(Engine.load_texture(_folderpath..sword.palette..".palette.png"))
			elseif	sword.type == 2 then
				create_slash(user, props, team, facing, field, tile:get_tile(Direction.Up, 1))
				create_slash(user, props, team, facing, field, tile:get_tile(Direction.Down, 1))
				local slash = create_effect(facing, SLASH_TEXTURE, SLASH_ANIMPATH, "WIDE", 0, 0, false, -3, field, tile)
				slash:set_palette(Engine.load_texture(_folderpath..sword.palette..".palette.png"))
			elseif	sword.type == 3 then
				create_slash(user, props, team, facing, field, tile:get_tile(facing, 1))
				local slash = create_effect(facing, SLASH_TEXTURE, SLASH_ANIMPATH, "LONG", 0, 0, false, -3, field, tile)
				slash:set_palette(Engine.load_texture(_folderpath..sword.palette..".palette.png"))
			end
		end)
	end
	action.action_end_func = function(self)
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function create_slash(user, props, team, facing, field, tile)
	local spell = Battle.Spell.new(team)
	spell:set_facing(facing)
	--spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	--[[local sprite = spell:sprite()
    sprite:set_texture(Engine.load_texture(_folderpath.."testdot.png"), true)
	sprite:set_layer(-3)]]
    local anim = spell:get_animation()
	anim:load(_folderpath.."testdot.animation")
	anim:set_state("0")
	anim:on_complete(function() spell:delete() end)

	spell.update_func = function(self) 
		self:get_current_tile():attack_entities(self)
	end

	spell.attack_func = function(self, ent)
		if 		props.element == Element.Fire then
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "2", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
		elseif	props.element == Element.Aqua then
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "3", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
		elseif	props.element == Element.Elec then
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "4", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
		elseif	props.element == Element.Wood then
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "5", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
		end
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end

	spell.battle_end_func = function(self)
		self:delete()
    end

	spell.can_move_to_func = function(tile)
		return true
	end

	spell.delete_func = function(self)
		self:erase()
    end

	field:spawn(spell, tile)

	return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return sword