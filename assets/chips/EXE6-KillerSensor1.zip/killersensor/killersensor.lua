local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local KILLERSEYE_TEXTURE = Engine.load_texture(_folderpath.."gfx/killerseye.grayscaled.png")
local KILLERSEYE_ANIMPATH = _folderpath.."gfx/killerseye.animation"
local CURSOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/cursor.png")
local CURSOR_ANIMPATH = _folderpath.."gfx/cursor.animation"
local KILLERSBEAM_TEXTURE = Engine.load_texture(_folderpath.."gfx/killersbeam.png")
local KILLERSBEAM_ANIMPATH = _folderpath.."gfx/killersbeam.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_65.ogg", true)
local CURSOR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_211.ogg", true)
local KILLERSBEAM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_70.ogg", true)

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_132.ogg", true)

local ObstacleInfo = include("ObstacleInfo.lua")

local function debug_print(text)
    if print_debug then
        print("[KillerSensor] "..text)
    end
end

local killersensor = {}

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_killerseye(user, props, spawn_tile, facing, field, team, direction)
	local beam_tile = spawn_tile:get_tile(direction, 1)
	local killerseye = Battle.Obstacle.new(team)
	ObstacleInfo.set_cannot_be_targeted(killerseye, true)
    ObstacleInfo.set_cannot_be_manipulated(killerseye, false)
	ObstacleInfo.add_to_limit_1(killerseye, team, field)
	killerseye:set_name(killersensor.sensor_name)
	killerseye:set_health(killersensor.sensor_health)
	killerseye:set_facing(facing)
	killerseye:set_texture(KILLERSEYE_TEXTURE, true)
	killerseye:set_palette(Engine.load_texture(_folderpath.."gfx/palette/palette_"..killersensor.sensor_palette..".png"))
	killerseye:sprite():set_layer(0)
	killerseye:set_air_shoe(true)
	killerseye:set_float_shoe(true)
	killerseye:share_tile(false)
	local anim = killerseye:get_animation()
	anim:load(KILLERSEYE_ANIMPATH)
	anim:set_state("0")
	anim:refresh(killerseye:sprite())
	killerseye.frames = 0
	killerseye.l_frames = 0
	killerseye.f_frames = 0
	killerseye.state = "SPAWN"
	killerseye.cursor = nil
	killerseye.flinching = false
	killerseye.attack_delete = false
	killerseye.time_to_delete = false
	
	local sensor_defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    sensor_defense_rule.filter_statuses_func = function(hit_props)
        hit_props.flags = hit_props.flags & (~Hit.Stun)
        hit_props.flags = hit_props.flags & (~Hit.Root)
        hit_props.flags = hit_props.flags & (~Hit.Shake)
        hit_props.flags = hit_props.flags & (~Hit.Pierce)
        hit_props.flags = hit_props.flags & (~Hit.Retangible)
        hit_props.flags = hit_props.flags & (~Hit.Bubble)
        hit_props.flags = hit_props.flags & (~Hit.Freeze)
		if hit_props.flags & Hit.Impact == Hit.Impact & Hit.Drag == Hit.Drag then
			killerseye.f_frames = 0
			killerseye.flinching = true
		else
			hit_props.flags = hit_props.flags & (~Hit.Drag)
		end
        return hit_props
    end
	killerseye:add_defense_rule(sensor_defense_rule)

	local function create_hitbox(new_tile)
		local hitbox = graphic_init("spell", 0, 0, false, false, false, false, false, user, facing)
		hitbox:set_hit_props(
			HitProps.new(
				props.damage,
				Hit.Impact | Hit.Stun | Hit.Breaking | Hit.Pierce | Hit.Retangible,
				props.element,
				user:get_context(),
				Drag.None
			)
		)
		hitbox.update_func = function(self)
			self:get_tile():attack_entities(self)
			self:erase()
		end
		hitbox.attack_func = function(self, other)
			debug_print("beam attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
			local offset_y = math.random(-30,-18)
			local offset_x = math.random(-8,7)
			if facing == Direction.Left then offset_x = -offset_x end
			local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, self, facing)
			hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
			field:spawn(hit_effect, other:get_tile())
			if Battle.Obstacle.from(other) == nil then
				if Battle.Player.from(user) ~= nil then
					Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
				end
			else
				Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
			end
		end
		field:spawn(hitbox, new_tile)
		return hitbox
	end

	local function create_killersbeam()
		for i=1, field:width() do
			local start_tile = beam_tile:get_tile(direction, i-1)
			if start_tile and not start_tile:is_edge() then
				local state = nil
				if direction == Direction.join(facing, Direction.Up) then
					state = "1"
				elseif direction == Direction.join(facing, Direction.Down) then
					state = "2"
				else
					state = "0"
				end
				local beam = graphic_init("spell", 0, -22*2, KILLERSBEAM_TEXTURE, KILLERSBEAM_ANIMPATH, state, Playback.Loop, -3, user, facing)
				--[[
				beam:set_hit_props(
					HitProps.new(
						props.damage,
						Hit.Impact | Hit.Stun | Hit.Breaking | Hit.Pierce | Hit.Retangible,
						props.element,
						user:get_context(),
						Drag.None
					)
				)]]
				beam.attacking = true
				beam.do_once = true
				local hit_query = function(ent)
					return (Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) and ent:get_health() > 0 and not ent:is_team(team)
				end
				beam.on_spawn_func = function()
					debug_print("beam spawned on tile ("..start_tile:x()..";"..start_tile:y()..")")
				end
				beam.update_func = function(self)
					--[[
					if self.attacking then
						self:get_tile():attack_entities(self)
					else
						if #self:get_tile():find_entities(hit_query) > 0 then
							self.attacking = true
						end
					end
					]]
					if #self:get_tile():find_entities(hit_query) > 0 then
						if self.do_once then
							self.do_once = false
							create_hitbox(self:get_tile())
						end
					else
						if not self.do_once then
							self.do_once = true
						end
					end
					if killerseye:is_deleted() or killerseye.flinching then
						self:erase()
					end
				end
				beam.attack_func = function(self, other)
					--self.attacking = false
					--create_hitbox(self:get_tile())
					--[[
					local offset_y = math.random(-30,-18)
					local offset_x = math.random(-8,7)
					if facing == Direction.Left then offset_x = -offset_x end
					local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, self, facing)
					hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
					field:spawn(hit_effect, other:get_tile())
					if Battle.Obstacle.from(other) == nil then
						if Battle.Player.from(user) ~= nil then
							Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
						end
					else
						Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
					end
					]]
				end
				beam.battle_end_func = function(self)
					self:erase()
				end
				field:spawn(beam, start_tile)
			else
				break
			end
		end
	end

	local function create_cursor()
		local cursor = graphic_init("spell", 0, 0, CURSOR_TEXTURE, CURSOR_ANIMPATH, "0", Playback.Once, -1, user, facing)
		cursor.frames = 0
		local query_obs = function(o)
			return o and o:get_health() > 0
		end
		local query_enemy = function(o)
			return o and o:get_health() > 0 and not o:is_team(team)
		end
		cursor.on_spawn_func = function(self)
			debug_print("cursor spawned on tile ("..spawn_tile:x()..";"..spawn_tile:y()..")")
			Engine.play_audio(CURSOR_AUDIO, AudioPriority.Highest)
			--[[
			if #beam_tile:find_obstacles(query_obs) > 0 then
				self:hide()
			end
			]]
		end
		cursor.update_func = function(self)
			self.frames = self.frames + 1
			if self.frames >= 9 then
				local next_tile = self:get_tile(direction, 1)
				if (self:get_tile() == nil or self:get_tile():is_edge() or #self:get_tile():find_obstacles(query_obs) > 0) or (next_tile == nil or next_tile:is_edge() or #next_tile:find_obstacles(query_obs) > 0) then
					next_tile = beam_tile
					--[[
					if next_tile ~= self:get_tile() then
						self:reveal()
					end
					]]
				end
				self:teleport(next_tile, ActionOrder.Immediate, function()
					Engine.play_audio(CURSOR_AUDIO, AudioPriority.Highest)
					self.frames = 0
				end)
			end
			if killerseye:is_deleted() or killerseye.flinching then
				self:erase()
			end
			if #self:get_tile():find_characters(query_enemy) > 0 then
				killerseye.frames = 0
				killerseye.state = "ATTACK"
				if direction == Direction.join(facing, Direction.Up) then
					anim:set_state("ATTACK_U")
					anim:refresh(killerseye:sprite())
				elseif direction == Direction.join(facing, Direction.Down) then
					anim:set_state("ATTACK_D")
					anim:refresh(killerseye:sprite())
				else
					anim:set_state("ATTACK_F")
					anim:refresh(killerseye:sprite())
				end
				killerseye.l_frames = 0
				killerseye.attack_delete = true
				self:erase()
			end
		end
		cursor.battle_end_func = function(self)
			self:erase()
		end
		cursor.can_move_to_func = function(tile)
			return true
		end
		field:spawn(cursor, beam_tile)
		return cursor
	end

	killerseye.on_spawn_func = function(self)
		Engine.play_audio(SPAWN_AUDIO, AudioPriority.Low)
	end
	killerseye.update_func = function(self)
		self.l_frames = self.l_frames + 1
		if (not self.attack_delete and self.l_frames > 800) or (self.attack_delete and self.l_frames > 120) then --800 or 120
			self:share_tile(true)
			self.l_frames = 0
			self.time_to_delete = true
		end
		if self.time_to_delete then
			for i=1, 9, 2 do
				if self.l_frames == i then
					self:hide()
				end
			end
			for j=2, 10, 2 do
				if self.l_frames == j then
					self:reveal()
				end
			end
			if self.l_frames >= 11 then
				self:delete()
			end
		end
		if not self.flinching then -- The Killer's Eye is NOT flinching.
			self.frames = self.frames + 1
			if self.state == "SPAWN" then
				anim:on_complete(function()
					self.frames = 0
					self.state = "SEARCH"
					anim:set_state("IDLE_F")
					anim:refresh(killerseye:sprite())
					anim:set_playback(Playback.Loop)
				end)
			elseif self.state == "SEARCH" then
				if self.frames == 11 then
					if direction == Direction.join(facing, Direction.Up) then
						anim:set_state("F_TO_U")
						anim:refresh(killerseye:sprite())
					elseif direction == Direction.join(facing, Direction.Down) then
						anim:set_state("F_TO_D")
						anim:refresh(killerseye:sprite())
					end
				elseif self.frames == 25-1 then
					create_cursor()
				elseif self.frames == 25 then
					if direction == Direction.join(facing, Direction.Up) then
						anim:set_state("IDLE_U")
						anim:set_playback(Playback.Loop)
						anim:refresh(killerseye:sprite())
					elseif direction == Direction.join(facing, Direction.Down) then
						anim:set_state("IDLE_D")
						anim:set_playback(Playback.Loop)
						anim:refresh(killerseye:sprite())
					end
				end
			elseif self.state == "ATTACK" then
				if self.frames == 2 then
					Engine.play_audio(KILLERSBEAM_AUDIO, AudioPriority.Low) 
					create_killersbeam(user, props, facing, field, direction, beam_tile)
				end
			end
		else -- The Killer's Eye IS flinching.
			self.f_frames = self.f_frames + 1
			if self.f_frames >= 68 then
				self.frames = 0
				anim:refresh(killerseye:sprite())
				self.f_frames = 0
				self.flinching = false
			end
		end
	end
	killerseye.battle_end_func = function(self)
		self:set_health(0)
	end
	killerseye.delete_func = function(self)
		if self:get_health() <= 0 then
			local hit_effect = graphic_init("artifact", 0, (-20*2), BOOM_TEXTURE, BOOM_ANIMPATH, "0", Playback.Once, -999, self, Direction.Right, true)
            hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
            field:spawn(hit_effect, self:get_tile())
			Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
		end
	end
	killerseye.can_move_to_func = function(tile)
		if not tile:is_edge() then
			return true
		end
	end
	field:spawn(killerseye, spawn_tile)
	return killerseye
end

killersensor.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()
		local step1 = Battle.Step.new()
		local frames = 0
		step1.update_func = function(self, dt)
			frames = frames + 1
			if frames == 1 then
				local direction = facing
				if user:get_tile():y() <= 1 then
					direction = Direction.join(facing, Direction.Down)
				elseif user:get_tile():y() >= field:height() then
					direction = Direction.join(facing, Direction.Up)
				end
				local query = function(o)
					return o and o:get_health() > 0
				end
				local tile = user:get_tile(facing, 1)
				if not tile:is_edge() and #tile:find_characters(query) <= 0 and #tile:find_obstacles(query) <= 0 then
					create_killerseye(user, props, tile, facing, field, team, direction)
				end
			elseif frames >= 66 then
				self:complete_step()
			end
		end
		self:add_step(step1)
	end
	return action
end

return killersensor