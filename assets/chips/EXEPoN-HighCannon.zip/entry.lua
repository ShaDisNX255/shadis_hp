local cannon = include("cannon/cannon.lua")

local DAMAGE = 80

cannon.type = 2

cannon.codes = {"C","D","E","*"}
cannon.shortname = "HiCannon"
cannon.damage = DAMAGE
cannon.time_freeze = false
cannon.element = Element.None
cannon.description = "Cannon attack to 1 enemy"
cannon.long_description = "A Cannon that can attack 1 enemy ahead"
cannon.can_boost = true
cannon.card_class = CardClass.Standard
cannon.limit = 4
cannon.mb = 26

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-002-HighCannon")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(cannon.codes)

    local props = package:get_card_props()
    props.shortname = cannon.shortname
    props.damage = cannon.damage
    props.time_freeze = cannon.time_freeze
    props.element = cannon.element
    props.description = cannon.description
    props.long_description = cannon.long_description
    props.can_boost = cannon.can_boost
	props.card_class = cannon.card_class
	props.limit = cannon.limit
end

card_create_action = cannon.card_create_action