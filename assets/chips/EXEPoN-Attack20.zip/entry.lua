local attack = include("attack/attack.lua")

local DAMAGE = 0

attack.multiplier = 20

attack.codes = {"*"}
attack.shortname = "Atk+20"
attack.damage = DAMAGE
attack.time_freeze = false
attack.element = Element.None
attack.description = "+20 for selected atk chip"
attack.long_description = "+20 attack power if selected after the attack chip"
attack.can_boost = true
attack.card_class = CardClass.Standard
attack.limit = 1
attack.mb = 30

function package_init(package) 
    package:declare_package_id("com.wcity.OFC.card.EXEPoN-121-Attack+20")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(attack.codes)

    local props = package:get_card_props()
    props.shortname = attack.shortname
    props.damage = attack.damage
    props.time_freeze = attack.time_freeze
    props.element = attack.element
    props.description = attack.description
    props.long_description = attack.long_description
    props.can_boost = attack.can_boost
	props.card_class = attack.card_class
	props.limit = attack.limit

    package.filter_hand_step = function(in_props, adj_cards) 
        if adj_cards:has_card_to_left() and adj_cards.left_card.can_boost then
            adj_cards.left_card.damage = adj_cards.left_card.damage + attack.multiplier
            adj_cards:discard_incoming()
        end
	end
end

card_create_action = attack.card_create_action