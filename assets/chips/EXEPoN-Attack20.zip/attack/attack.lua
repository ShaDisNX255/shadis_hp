local DAMAGE = 0

local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."smoke.png")
local SMOKE_ANIMPATH = _folderpath.."smoke.animation"
local SMOKE_AUDIO = Engine.load_audio(_folderpath.."EXE4_344.ogg")

local attack = {
    multiplier = 10,

    codes = {"*"},
    shortname = "Atk+10",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.None,
    description = "+10 for selected atk chip",
    long_description = "+10 attack power if selected after the attack chip",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 10,
}

attack.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_async_lockout(0.339))
	action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local fx = create_effect(facing, SMOKE_TEXTURE, SMOKE_ANIMPATH, "1", 0, (user:get_height()*2)*(-1), true, -999999, field, user:get_current_tile())
        fx.update_func = function(self)
            fx:set_offset(fx:get_offset().x, fx:get_offset().y - (2*2))
        end
        Engine.play_audio(SMOKE_AUDIO, AudioPriority.Low)
	end
	return action
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return attack