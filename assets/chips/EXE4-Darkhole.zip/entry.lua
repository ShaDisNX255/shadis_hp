local darkhole = include("darkhole/darkhole.lua")

local DAMAGE = 0

darkhole.codes = {"*"}
darkhole.shortname = "DarkHole"
darkhole.damage = DAMAGE
darkhole.time_freeze = true
darkhole.element = Element.None
darkhole.description = "Create a\nDarkHole\nin front!"
darkhole.long_description = "Create a DarkHole in the square in front of you!"
darkhole.can_boost = true
darkhole.card_class = CardClass.Standard
darkhole.limit = 4
darkhole.mb = 23

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE4-132-DarkHole")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(darkhole.codes)

    local props = package:get_card_props()
    props.shortname = darkhole.shortname
    props.damage = darkhole.damage
    props.time_freeze = darkhole.time_freeze
    props.element = darkhole.element
    props.description = darkhole.description
    props.long_description = darkhole.long_description
    props.can_boost = darkhole.can_boost
	props.card_class = darkhole.card_class
	props.limit = darkhole.limit
end

card_create_action = darkhole.card_create_action