local print_debug = false

local DARKHOLE_TEXTURE = Engine.load_texture(_folderpath.."gfx/darkhole.png")
local DARKHOLE_ANIMPATH = _folderpath.."gfx/darkhole.animation"
local DARKHOLE_AUDIO = Engine.load_audio(_folderpath.."sfx/darkhole.ogg", true)
local ObstacleInfo = include("ObstacleInfo.lua")

local function debug_print(text)
    if print_debug then
        print("[DarkHole] "..text)
    end
end

local darkhole = {}

local function create_darkhole(user, tile)
	if not tile or tile:is_edge() then return end
	local darkhole_o = Battle.Obstacle.new(Team.Other)
	darkhole_o:share_tile(true)
	darkhole_o:toggle_hitbox(false)
	darkhole_o:set_name("DarkHole")
	darkhole_o:set_health(0)
	darkhole_o:set_facing(Direction.Right)
	darkhole_o:never_flip(true)
	darkhole_o:set_texture(DARKHOLE_TEXTURE, true)
	darkhole_o:sprite():set_layer(999)
	local anim = darkhole_o:get_animation()
	anim:load(DARKHOLE_ANIMPATH)
	anim:set_state("DARKHOLE")
	anim:refresh(darkhole_o:sprite())
	anim:set_playback(Playback.Loop)
	ObstacleInfo.set_cannot_be_targeted(darkhole_o, true)
    ObstacleInfo.set_cannot_be_manipulated(darkhole_o, true)
	darkhole_o.on_spawn_func = function(self)
		local tile = darkhole_o:get_tile()
		if not tile:is_walkable() then
			darkhole_o:delete()
		end
		tile:set_state(TileState.Normal)
	end
	darkhole_o.can_move_to_func = function(tile)
		return false
	end
	darkhole_o.tile = nil
	darkhole_o.update_func = function(self, dt)
		if self.tile == nil then self.tile = self:get_tile() end
		if self.tile:get_state() ~= TileState.Normal then self:delete() end
	end
	--[[local query = function(ent)
		return Battle.Obstacle.from(ent) ~= nil
	end
	if #tile:find_entities(query) == 0 and not tile:is_edge() then return cube end]]
	if not tile:is_edge() then return darkhole_o end
	return nil
end

darkhole.card_create_action = function(actor, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

		local dark_query = function(o)
			return o and o:get_health() == 0 and o:get_name() == "DarkHole" and o:get_animation():get_state() == "DARKHOLE" --and o:get_tile():get_team() == team
		end
		local step1 = Battle.Step.new()
		local k = 0
		local do_once = true
		step1.update_func = function(self, dt)
			k = k + 1
			if do_once then
				Engine.play_audio(DARKHOLE_AUDIO, AudioPriority.High)
				do_once = false
				local desired_tile = user:get_tile(user:get_facing(), 1)
				local dark_hole = create_darkhole(user, desired_tile)
				local dark_check = desired_tile:find_obstacles(dark_query)
				if desired_tile ~= nil and not desired_tile:is_edge() and #dark_check <= 0 then
					desired_tile:set_state(TileState.Normal)
					user:get_field():spawn(dark_hole, desired_tile)
				end
			end
			if k >= 67 then
                user:get_animation():set_playback_speed(orig_speed)
				self:complete_step()
			end	
		end
		self:add_step(step1)
	end
    return action
end

return darkhole