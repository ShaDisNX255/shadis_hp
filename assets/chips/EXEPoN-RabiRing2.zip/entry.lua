local rabiring = include("rabiring/rabiring.lua")

local DAMAGE = 40

rabiring.frames = 3

rabiring.codes = {"B","R","W","*"}
rabiring.shortname = "RabiRng2"
rabiring.damage = DAMAGE
rabiring.time_freeze = false
rabiring.element = Element.Elec
rabiring.description = "Pralyzing electric ring atk!"
rabiring.long_description = "An electric ring attack! Paralyzes opponent for a while!"
rabiring.can_boost = true
rabiring.card_class = CardClass.Standard
rabiring.limit = 4
rabiring.mb = 20

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-018-RabiRing2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(rabiring.codes)

    local props = package:get_card_props()
    props.shortname = rabiring.shortname
    props.damage = rabiring.damage
    props.time_freeze = rabiring.time_freeze
    props.element = rabiring.element
    props.description = rabiring.description
    props.long_description = rabiring.long_description
    props.can_boost = rabiring.can_boost
	props.card_class = rabiring.card_class
	props.limit = rabiring.limit
end

card_create_action = rabiring.card_create_action