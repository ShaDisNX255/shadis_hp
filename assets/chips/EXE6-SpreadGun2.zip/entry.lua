local spreadgun = include("spreadgun/spreadgun.lua")

local DAMAGE = 60

spreadgun.codes = {"A","B","C","*"}
spreadgun.shortname = "SprdGun2"
spreadgun.damage = DAMAGE
spreadgun.time_freeze = false
spreadgun.element = Element.None
spreadgun.description = "Spreads\nto 1 sqr\naround!"
spreadgun.long_description = "When it hits, spreads to 1 square around!"
spreadgun.can_boost = true
spreadgun.card_class = CardClass.Standard
spreadgun.limit = 5
spreadgun.mb = 18

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-010-SpreadGun2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(spreadgun.codes)

    local props = package:get_card_props()
    props.shortname = spreadgun.shortname
    props.damage = spreadgun.damage
    props.time_freeze = spreadgun.time_freeze
    props.element = spreadgun.element
    props.description = spreadgun.description
    props.long_description = spreadgun.long_description
    props.can_boost = spreadgun.can_boost
	props.card_class = spreadgun.card_class
	props.limit = spreadgun.limit
end

card_create_action = spreadgun.card_create_action