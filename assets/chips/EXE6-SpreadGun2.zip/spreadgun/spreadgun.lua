local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)
 
local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/buster.png")
local BUSTER_ANIMPATH = _folderpath.."gfx/buster.animation"
local BURST_TEXTURE = Engine.load_texture(_folderpath.."gfx/burst.png")
local BURST_ANIMPATH = _folderpath.."gfx/burst.animation"

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local BURST_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_282.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[SpreadGun] "..text)
    end
end

local spreadgun = {}

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_attack2(user, props, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end
		local spell = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    	spell:set_hit_props(
    	    HitProps.new(
    	        props.damage,
    	        Hit.Impact,
    	        props.element,
    	        user:get_context(),
    	        Drag.None
    	    )
    	)
		spell.on_spawn_func = function()
			debug_print("spreaded on tile ("..tile:x()..";"..tile:y()..")")
			local hit_effect = graphic_init("artifact", 0, -16*2, BURST_TEXTURE, BURST_ANIMPATH, "0", Playback.Once, -9, user, user:get_facing())
			hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
			user:get_field():spawn(hit_effect, tile)
		end
    	spell.update_func = function(self)
    	    self:get_tile():attack_entities(self)
    	    self:erase()
    	end
		spell.attack_func = function(self, other)
			debug_print("spread attacked tile ("..tile:x()..";"..tile:y()..")")
			local offset_x = math.random(-8,7)
			local offset_y = math.random(-22,-9)
			local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, user, Direction.Right, true)
			if Battle.Obstacle.from(other) == nil then
				if Battle.Player.from(user) ~= nil then
					Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
				end
			else
				Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
			end
		end
		user:get_field():spawn(spell, tile)
	end
    spawn()
end

local function create_attack(user, props, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end
		debug_print("attack spawned at tile ("..tile:x()..";"..tile:y()..")")
		local spell = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    	spell:set_hit_props(
    	    HitProps.new(
    	        props.damage,
    	        Hit.Impact,
    	        props.element,
    	        user:get_context(),
    	        Drag.None
    	    )
    	)
		spell.slide_started = false
		spell.update_func = function(self) 
    	    self:get_tile():attack_entities(self)
    	    if not self:is_sliding() then
    	        if self:get_tile():is_edge() and self.slide_started then 
    	            self:erase()
    	        end 
    	        local dest = self:get_tile(self:get_facing(), 1)
    	        local ref = self
    	        self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, function()
    	            ref.slide_started = true 
    	        end)
    	    end
    	end
		spell.collision_func = function(self, other)
			debug_print("attack collided tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
			local offset_x = math.random(-8,7)
			local offset_y = math.random(-22,-9)
			local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "1", Playback.Once, -999, user, Direction.Right, true)
			hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
			user:get_field():spawn(hit_effect, other:get_tile())
			for i=0,7 do
				create_attack2(user, props, other:get_tile(math.floor(2^i),1))
			end
			--[[
			create_attack2(user, props, other:get_tile())																		--cur tile
			create_attack2(user, props, other:get_tile():get_tile(Direction.Up, 1))												--up
			create_attack2(user, props, other:get_tile():get_tile(Direction.Down, 1))											--down
			create_attack2(user, props, other:get_tile():get_tile(user:get_facing(), 1))										--forward
			create_attack2(user, props, other:get_tile():get_tile(user:get_facing_away(), 1))									--back
			create_attack2(user, props, other:get_tile():get_tile(Direction.join(user:get_facing(), Direction.Up), 1))			--up-forward
			create_attack2(user, props, other:get_tile():get_tile(Direction.join(user:get_facing(), Direction.Down), 1))		--down-forward
			create_attack2(user, props, other:get_tile():get_tile(Direction.join(user:get_facing_away(), Direction.Up), 1))		--up-back
			create_attack2(user, props, other:get_tile():get_tile(Direction.join(user:get_facing_away(), Direction.Down), 1))	--down-back
			]]
			self:erase()
		end
    	spell.attack_func = function(self, other)
    	end
    	spell.can_move_to_func = function(tile)
    	    return true
    	end
		user:get_field():spawn(spell, tile)
	end
    spawn()
end

spreadgun.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	local frame1 = {1,0.0} --(+)1 frame
	local frame2 = {2,0.017}
	local frame3 = {2,0.033}
	local frame4 = {3,0.05}
	local frame5 = {4,0.15}
	local frame6 = {4,0.117} --(-)1 frame
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local buster = self:add_attachment("BUSTER")
		local buster_sprite = buster:sprite()
		buster_sprite:set_texture(BUSTER_TEXTURE, true)
		buster_sprite:set_layer(-1)
		local buster_anim = buster:get_animation()
		buster_anim:load(BUSTER_ANIMPATH)
		buster_anim:set_state("0")
		buster_anim:refresh(buster_sprite)
		user:toggle_counter(true)
		self:add_anim_action(3, function()
            Engine.play_audio(BURST_AUDIO, AudioPriority.Low)
			create_attack(user, props, user:get_tile(user:get_facing(), 1))
        end)
		self:add_anim_action(6, function()
			user:toggle_counter(false)
        end)
	end
	action.action_end_func = function()
		user:toggle_counter(false)
	end
    return action
end

return spreadgun