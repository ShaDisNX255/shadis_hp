local print_debug = false

local METEOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/meteor.grayscaled.png")
local METEOR_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/meteor.png")
local METEOR_ANIMPATH = _folderpath.."gfx/meteor.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png") -- flip for Player 2?
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png") -- flip for Player 2?
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local METEOR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_181.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_20.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[MeteorEarth] "..text)
    end
end

local meteorearth = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_boom(user, props, meteor, facing, tile)
    local query = function(e)
        return e:get_health() > 0 and not e:is_team(meteor:get_team())
    end
    if not tile or (tile:is_hole() and (#tile:find_characters(query) <= 0 and #tile:find_obstacles(query) <= 0)) then return end
	Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
    local boom_fx = graphic_init("artifact", 0, 0, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -9, "0", Playback.Once, meteor, facing, true, true, true)
    meteor:get_field():spawn(boom_fx, tile)
    local boom_hit = Battle.Spell.new(meteor:get_team())
    boom_hit:set_facing(facing)
    boom_hit:set_hit_props(
        HitProps.new()
        :dmg(props.damage)
        :impact()
        :flinch()
        :flash()
        :pierce_ground()
        :retangible()
        :elem(props.element)
        :from(user:get_context())
    )
    boom_hit.update_func = function(self)
        if props.element == Element.Fire and self:get_tile():get_state() == TileState.Grass then
            boom_hit:set_hit_props(
                HitProps.new()
                :dmg(math.floor(props.damage*2))
                :impact()
                :flinch()
                :flash()
                :pierce_ground()
                :retangible()
                :elem(props.element)
                :from(user:get_context())
            )
            self:get_tile():set_state(TileState.Normal)
        end
        if self:get_tile():get_state() == TileState.Holy then
            boom_hit:set_hit_props(
                HitProps.new()
                :dmg(math.floor(props.damage/2))
                :impact()
                :flinch()
                :flash()
                :pierce_ground()
                :retangible()
                :elem(props.element)
                :from(user:get_context())
            )
        end
        self:get_tile():attack_entities(self)
        if self:get_tile():get_state() == TileState.Cracked then
            self:get_tile():set_state(TileState.Broken)
        else
            self:get_tile():set_state(TileState.Cracked)
        end
	    self:shake_camera(10, 0.233)
        self:delete()
    end
    boom_hit.attack_func = function(self, other, judge)
		debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-8,5)
        local offset_x = math.random(-7,6)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_effect, other:get_tile())
	end
    boom_hit.battle_end_func = function(self)
        self:delete()
    end
    boom_hit.delete_func = function(self)
        self:erase()
    end
    meteor:get_field():spawn(boom_hit, tile)
end

local function create_meteor(user, props, spawner, facing, tile)
    if not tile or tile:is_edge() then return end
    local meteor = graphic_init("spell", -((16*2)*16), -((16*2)*16), METEOR_TEXTURE, METEOR_PALETTE, METEOR_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, true)
    meteor.frames = 0
    meteor.falling = false
    meteor.x_speed = (16*2)
    if facing == Direction.Left then meteor.x_speed = -meteor.x_speed end
    meteor.update_func = function(self)
        self:highlight_tile(Highlight.Flash)
        self.frames = self.frames + 1
        if self.frames == 37-1 then
			Engine.play_audio(METEOR_AUDIO, AudioPriority.Immediate)
            self.falling = true
        end
        if self.falling then
            if self:get_offset().y >= 0 then
                create_boom(user, props, meteor, meteor:get_facing(), tile)
                self:delete()
            else
                self:set_offset(self:get_offset().x+self.x_speed, self:get_offset().y+(16*2))
            end
        end
    end
    meteor.battle_end_func = function(self)
        self:delete()
    end
    meteor.delete_func = function(self)
        self:erase()
    end
    spawner:get_field():spawn(meteor, tile)
    return meteor
end

local function meteor_spawner(user, props, tile)
    local spawner = Battle.Spell.new(user:get_team())
    spawner:set_facing(user:get_facing())
    spawner:set_name("MeteorEarth")
    spawner.frames = 0
    local query = function(c)
        return c and c:get_health() > 0 and not c:is_team(spawner:get_team())
    end
    spawner.update_func = function(self) --1 21 42 62 82 101
        self.frames = self.frames + 1
        for i=1, meteorearth.meteor_number do 
            if self.frames == 1+(20*(i-1)) then
                local enemies = self:get_field():find_characters(query) -- MeteorEarth chooses all enemies on the field, even if they are behind the user.
                local rand_enemy = enemies[math.random(1, #enemies)]:get_tile()
                local new_tile = nil
                local r = math.random(1,3)
                if r == 1 or r == 2 then
                    new_tile = rand_enemy
                else
                    local around_tiles = {}
			        for i=0,3 do
                        local around_tile = rand_enemy:get_tile(math.floor(2^i),1)
                        if around_tile and not around_tile:is_edge() then
                            table.insert(around_tiles, around_tile)
                        end
			        end
                    new_tile = around_tiles[math.random(1, #around_tiles)]
                end
                create_meteor(user, props, spawner, self:get_facing(), new_tile)
            end
        end
        if self.frames == 2+(20*(meteorearth.meteor_number-1)) then
            self:delete()
        end
    end
    spawner.battle_end_func = function(self)
        self:delete()
    end
    spawner.delete_func = function(self)
        self:erase()
    end
    user:get_field():spawn(spawner, tile)
end

meteorearth.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(1))
    local frame_sequence = make_frame_data({{1,0.0}})
	action:override_animation_frames(frame_sequence)
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        meteor_spawner(user, props, user:get_tile())
    end
    return action
end

return meteorearth