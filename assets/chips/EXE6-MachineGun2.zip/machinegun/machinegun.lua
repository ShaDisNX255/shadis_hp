local print_debug = false

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/machinegun.png")
local BUSTER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/machinegun.png")
local BUSTER_ANIMPATH = _folderpath.."gfx/machinegun.animation"
local TARGET_TEXTURE = Engine.load_texture(_folderpath.."gfx/target.grayscaled.png")
local TARGET_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/target.png")
local TARGET_ANIMPATH = _folderpath.."gfx/target.animation"
local TILE_HIT_TEXTURE = Engine.load_texture(_folderpath.."gfx/tile_hit.grayscaled.png")
local TILE_HIT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/tile_hit.png")
local TILE_HIT_ANIMPATH = _folderpath.."gfx/tile_hit.animation"

local EFFECT0_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect0.grayscaled.png")
local EFFECT0_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect0.png")
local EFFECT0_ANIMPATH = _folderpath.."gfx/effect0.animation"

local GUN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_301.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[MachineGun] "..text)
    end
end

local machinegun = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function spawn_attack(user, x, y, props)
    local spell = graphic_init("spell", 0, 0, TILE_HIT_TEXTURE, TILE_HIT_PALETTE, TILE_HIT_ANIMPATH, -3, "0", Playback.Once, user, user:get_facing(), true)
    spell:set_hit_props(
        HitProps.new()
        :dmg(props.damage)
        :impact()
        :flinch()
        :pierce_ground()
        :retangible()
        :elem(props.element)
        :from(user:get_context())
    )
    spell.frames = 1
    spell.on_spawn_func = function()
        debug_print("attack spawned on tile ("..x..";"..y..")")
        Engine.play_audio(GUN_AUDIO, AudioPriority.Immediate)
    end
    spell.update_func = function(self)
        if self.frames == 1 then
            self:get_current_tile():attack_entities(self)
            self:highlight_tile(Highlight.Solid)
        elseif self.frames >= 2 then
            self:highlight_tile(Highlight.None)
        end
        self.frames = self.frames + 1
    end
    spell.attack_func = function(self, other, judge)
        debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
        if not judge:hint_spawn_gfx() then return end
        local offset_x = math.random(2,6)
        if self:get_facing() == Direction.Left then offset_x = math.random(-7,-3) end
        local hit_effect = graphic_init("artifact", (offset_x*2), (math.random(-8,3)*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
        hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
        user:get_field():spawn(hit_effect, other:get_tile())
    end
    user:get_field():spawn(spell, x, y)
end
  
local function spawn_target(user, x, y, props)
    local spell = graphic_init("spell", 0, 0, TARGET_TEXTURE, TARGET_PALETTE, TARGET_ANIMPATH, -3, "0", Playback.Once, user, user:get_facing(), false, false, true)
    local ATTACK_INTERVAL = 7
    local next_attack = ATTACK_INTERVAL
    spell.update_func = function(self)
        next_attack = next_attack - 1
        if next_attack <= 0 then
            spawn_attack(user, x, y, props)
            self:hide()
            self:erase()
        end
        if next_attack == 3 then 
            self:highlight_tile(Highlight.Solid)
        end
    end
    user:get_field():spawn(spell, x, y)
end
  
local function execute(action, user, props)
    local buster = action:add_attachment("BUSTER")
    buster:sprite():set_texture(BUSTER_TEXTURE, true)
    buster:sprite():set_layer(-1)
    local buster_anim = buster:get_animation()
    buster_anim:load(BUSTER_ANIMPATH)
    buster_anim:set_state("0")
    buster_anim:refresh(buster:sprite())
    
    local field = user:get_field()
    local target = nil
    local target_tile = nil
    local move_up = true
    local first_spawn = true

    local move_rectical
    move_rectical = function(col_move)
        -- Figure out where our last rectical was.
        --if not target or not target_tile then
            --return target_tile
        --end
      
        local char_tile = nil
        if target then 
            char_tile = target:get_current_tile()
        end
      
        --if not char_tile then return target_tile end
      
        local next_tile = nil
        col_move = char_tile and col_move
        
        if col_move and char_tile:x() ~= target_tile:x() then
            if char_tile:x() < target_tile:x() then
                next_tile = field:tile_at(target_tile:x() - 1, target_tile:y())
                
                if next_tile:is_edge() then
                    next_tile = field:tile_at(target_tile:x() + 1, target_tile:y())
                end
                
                return next_tile
            elseif char_tile:x() > target_tile:x() then
                next_tile = field:tile_at(target_tile:x() + 1, target_tile:y())
                
                if next_tile:is_edge() then
                    next_tile = field:tile_at(target_tile:x() - 1, target_tile:y())
                end
                
                return next_tile
            end
        end
  
        -- If you cannot move left/right keep moving up/down.
        local step
        
        if move_up then
            step = -1
        else
            step = 1
        end
    
        next_tile = field:tile_at(target_tile:x(), target_tile:y() + step)
    
        if next_tile:is_edge() then
            move_up = not move_up
            return move_rectical(true)
        else
            return next_tile
        end
    end
  
    local shoot = function()
        if target == nil or target:will_erase_eof() then
            local closest_distance = math.huge
            local actor_x = user:get_current_tile():x()
            local actor_team = user:get_team()
            local facing = user:get_facing()
        
            -- Find the closest.
            field:find_characters(function(character)
                local team = character:get_team()
            
                -- Get health check matters for in time freeze, just in case.
                if character:is_deleted() or team == actor_team or team == Team.Other or character:get_health() == 0 then
                    -- not targetable
                    return false
                end
            
                local x = character:get_current_tile():x()
                local distance = x - actor_x
            
                -- Does not target next to or behind.
                if (facing == Direction.Right and distance < 1) or (facing == Direction.Left and distance > -1) then 
                    return false
                end
            
                if user:get_facing() == Direction.Left then
                    distance = -distance
                end
            
                if distance < closest_distance then
                    closest_distance = distance
                    target = character
                end
            
                return false
            end)
        
            if target then
                local erase_callback = function()
                    target = nil
                end
            
                -- Notify doesn't happn until they are actually gone (we catch exploding viruses).
                field:notify_on_delete(target:get_id(), user:get_id(), erase_callback)
            end
        end
  
        if not target_tile and target then
            target_tile = field:tile_at(target:get_current_tile():x(), 3)
        elseif not target_tile and not target then
            -- pick back col
            if user:get_facing() == Direction.Right then
                target_tile = field:tile_at(field:width(), field:height())
            else
                target_tile = field:tile_at(1, field:height())
            end
        end
    
        -- We initially spawn the rectical where we want to start.
        -- Do note move it around.
        if not first_spawn then
            target_tile = move_rectical(false)
        else
            first_spawn = false
        end
  
        -- Spawn rectical where the target_tile is positioned which will attack for us.
        -- Code above shoot in update func handles instead, but I kept this here in case, for next version.
        if target_tile then
            spawn_target(user, target_tile:x(), target_tile:y(), props)
        end
    end
  
    -- Shoots 9 times total.
    action:add_anim_action(2, function()
        local counter = -1
        action.update_func = function()
            counter = counter + 1
            if counter % 9 == 0 then 
                if target and (target:is_deleted() or target:get_health() == 0) then 
                    target = nil
                end
                shoot()
            end
        end
    end)
    action:add_anim_action(3, function()
        buster_anim:set_state("1")
        buster_anim:set_playback(Playback.Loop)
        buster_anim:refresh(buster:sprite())
    end)
    action:add_anim_action(11, function()
        user:toggle_counter(false)
    end)
end
  
machinegun.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local frame0 = {1,0.0} -- 0 because engine adds an extra frame to start oops.
    local frame01 = {1,0.017}
    local frame02 = {1,0.033}
    local frame2 = {2,0.033}
    local frame_sequence = make_frame_data({
        frame0,
        frame01, frame02, frame2, frame02, frame01, frame2, frame02, frame01, frame2,
        frame02, frame01, frame2, frame02, frame01, frame2, frame02, frame01, frame2,
        frame02, frame01, frame2, frame02, frame01, frame2, frame02, frame01, frame2,
        frame02, frame01, frame2, frame02, frame01, frame2, frame02, frame01, frame2,
        frame02, frame01, frame2, frame02, frame01, frame2, frame02, frame01, frame2,
        frame02, frame01, frame2
    })
    action:override_animation_frames(frame_sequence)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        user:toggle_counter(true)
        execute(self, user, props)
    end
    action.action_end_func = function(self)
        debug_print("in custom card action action_end_func()!")
        user:toggle_counter(false)
    end
    return action
end

return machinegun