local ratton = include("ratton/ratton.lua")

local DAMAGE = 80

ratton.palette = "palette2.png"

ratton.codes = {"A","C","F"}
ratton.shortname = "Ratton2"
ratton.damage = DAMAGE
ratton.time_freeze = false
ratton.element = Element.None
ratton.description = "Rat moves and turns once"
ratton.long_description = "A rat missile moves along the ground and can only turn once"
ratton.can_boost = true
ratton.card_class = CardClass.Standard
ratton.limit = 4
ratton.mb = 28

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXEPoN-032-Ratton2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(ratton.codes)

    local props = package:get_card_props()
    props.shortname = ratton.shortname
    props.damage = ratton.damage
    props.time_freeze = ratton.time_freeze
    props.element = ratton.element
    props.description = ratton.description
    props.long_description = ratton.long_description
    props.can_boost = ratton.can_boost
	props.card_class = ratton.card_class
	props.limit = ratton.limit
end

card_create_action = ratton.card_create_action