local toppuu = include("toppuu/toppuu.lua")

local DAMAGE = 0

toppuu.box_name = "WindBox"
toppuu.box_type = "Toppuu"
toppuu.box_health = 40
toppuu.box_palette = "windbox1"

toppuu.codes = {"*"}
toppuu.shortname = "WindGust"
toppuu.damage = DAMAGE
toppuu.time_freeze = true
toppuu.element = Element.Wind
toppuu.description = "WindBox\nblows at\nenmy area"
toppuu.long_description = "Place a WindBox that blows wind at the enemy area"
toppuu.can_boost = false
toppuu.card_class = CardClass.Standard
toppuu.limit = 5
toppuu.mb = 10

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-134-Toppuu")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(toppuu.codes)

    local props = package:get_card_props()
    props.shortname = toppuu.shortname
    props.damage = toppuu.damage
    props.time_freeze = toppuu.time_freeze
    props.element = toppuu.element
    props.description = toppuu.description
    props.long_description = toppuu.long_description
    props.can_boost = toppuu.can_boost
	props.card_class = toppuu.card_class
	props.limit = toppuu.limit
end

card_create_action = toppuu.card_create_action