local print_debug = false

local WINDBOX_TEXTURE = Engine.load_texture(_folderpath.."gfx/windbox.grayscaled.png")
local WINDBOX_ANIMPATH = _folderpath.."gfx/windbox.animation"
local WINDGUST_TEXTURE = Engine.load_texture(_folderpath.."gfx/windgust.grayscaled.png")
local WINDGUST_ANIMPATH = _folderpath.."gfx/windgust.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_65.ogg", true)
local TOPPUU_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_57.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_132.ogg", true)

local ObstacleInfo = include("libs/ObstacleInfo.lua")
local WindPush = include("libs/WindPush.lua")

local function debug_print(text)
    if print_debug then
        print("[Toppuu] "..text)
    end
end

local toppuu = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_wind_gust(user, props, box, facing, field, team, spawn_tile, type)
    local query = function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        end
        return o:get_team() == Team.Other
    end
    if not spawn_tile or spawn_tile:is_edge() or #spawn_tile:find_obstacles(query)>0 then return end
    local palette = Engine.load_texture(_folderpath.."gfx/palette/"..type..".png")
    local spell = graphic_init("spell", 0, 0, WINDGUST_TEXTURE, palette, WINDGUST_ANIMPATH, 1, "0", Playback.Once, box, facing, false, false, false, team)
    spell:set_hit_props(
        HitProps.new()
        :dmg(0)
        :no_counter()
        :elem(props.element)
        :from(user:get_context())
        :drg(Drag.new(facing, field:width()))
    )
    spell.update_func = function(self)
        self:get_tile():attack_entities(self)
        if not self:is_sliding() then
            local tile = self:get_tile(facing,1)
            if not tile then
                self:delete()
            else
                self:slide(tile, frames(4), frames(0), ActionOrder.Voluntary)
            end
        else
            local tile = self:get_tile()
            if tile:is_edge() or (type=="Suikomi" and tile:get_team()==team) then
                self:delete()
            end
        end
    end
    spell.collision_func = function(self, other)
        if Battle.Obstacle.from(other) ~= nil and other:get_team() == Team.Other then
            self:delete()
            return
        end
    end
    spell.attack_func = function(self, other, judge)
        WindPush.apply(other, facing)
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell, spawn_tile)
    return spell
end

local function create_wind_box(user, props, facing_away, facing, field, team, spawn_tile)
    local tile = spawn_tile
	local chars = {}
	local obs = {}
	field:find_entities(function(e)
	  	local id = e:get_id()
	  	if Battle.Obstacle.from(e) then 
	  	  	table.insert(obs, id)
	  	elseif Battle.Character.from(e) then 
	  	  	table.insert(chars, id)
	  	end
	end)
	local ignore_list = obs
	-- https://paintylux.github.io/OpenNetBattleDocs/api/#tile-is_reserved
	local not_reserved_by_ob = tile:is_reserved(obs)
	--print(tile:is_walkable())
	--print(tile:is_reserved(chars))
	--print(tile:is_reserved(obs))
	--print(#tile:find_entities(query))
	if not tile:is_hole() and not check_obstacles(tile) and not check_characters_true(tile) and ((tile:is_reserved(chars) and tile:is_reserved(obs)) or (tile:is_reserved(chars) and not tile:is_reserved(obs)) or (not tile:is_reserved(chars) and not tile:is_reserved(obs))) then
	else
		return
    end
    --if not spawn_tile or spawn_tile:is_hole() or check_obstacles(spawn_tile) or check_characters_true(spawn_tile) then return end
    -- Destroyed Obstacle
	local function create_destroyedobstacle(self)
	    local field = self:get_field()
	    local objs = field:find_entities(function(e)
	        return e:get_name() == "DestroyedObstacle"
	    end)
	    if #objs >= 3 then return end
	    local dobj = Battle.Artifact.new()
	    dobj:set_name("DestroyedObstacle")
	    dobj.battle_end_func = function()
	    	dobj:delete()
	    end
	    field:spawn(dobj, self:get_tile())
	    return dobj
	end
    -- Obs. controller
	local obs_control = nil
    local function create_controller(orig_obs, tile)
		local controller = Battle.Artifact.new()
	    controller:set_name("OSControl_"..orig_obs:get_id())
        controller.update_func = function(self)
            if not orig_obs or orig_obs:is_deleted() then
                self:delete()
                return
            end
            local new_offset = self:get_offset()
            local new_elevation = self:get_elevation()
            if self:get_tile() ~= orig_obs:get_tile() then
                self:teleport(orig_obs:get_tile(), ActionOrder.Immediate)
            end
            orig_obs:set_offset(new_offset.x, new_offset.y)
            orig_obs:set_elevation(new_elevation)
        end
        controller.can_move_to_func = function(self)
            return true
        end
	    controller.battle_end_func = function(self)
	    	self:delete()
	    end
        field:spawn(controller, tile)
        return controller
    end
    ----
    local palette = Engine.load_texture(_folderpath.."gfx/palette/"..toppuu.box_palette..".png")
    local box = graphic_init("obstacle", 0, 0, WINDBOX_TEXTURE, palette, WINDBOX_ANIMPATH, -3, "0", Playback.Once, user, facing, false, false, false, team)
    box.anim = box:get_animation()
	ObstacleInfo.set_cannot_be_targeted(box, true)
	ObstacleInfo.set_cannot_be_manipulated(box, false)
	ObstacleInfo.add_to_limit_1(box, team, field)
	ObstacleInfo.set_obstacle_damage(box, Element.None, 0)
    local hit_props_c = HitProps.new()
    :dmg(0)
    :impact()
    :flinch()
    :flash()
    :no_counter()
    :elem(Element.None)
    :from(user:get_context())
    --box:set_hit_props(hit_props)
    box:set_name(toppuu.box_name)
    box:set_health(toppuu.box_health)
    box:set_float_shoe(false)
    box:set_air_shoe(false)
    box:share_tile(false)
    box:toggle_hitbox(true)
    -- Other props
    box.collision_available = true
    box.drag_dir = facing
    box.tile_y = spawn_tile:y()
    if toppuu.box_type == "Suikomi" then box.drag_dir = facing_away end
    local hit_props_w = HitProps.new()
    :dmg(0)
    :no_counter()
    :elem(props.element)
    :from(user:get_context())
    :drg(Drag.new(box.drag_dir, field:width()))
    box.countdown = 1500
    box.deleting = false
    box.state = "SPAWN"
    box.frames = 1
    local starting_component = Battle.Component.new(box, Lifetimes.Battlestep)
	starting_component.update_func = function(self, dt)
        if box.state == "SPAWN" then
	        Engine.play_audio(TOPPUU_AUDIO, AudioPriority.Immediate)
            box.anim:set_state("1")
            box.anim:set_playback(Playback.Loop)
            box.anim:refresh(box:sprite())
            box.state = "IDLE"
        else
            box.countdown = box.countdown - 1
            if box.countdown <= 0 then
                box:set_health(0)
                self:eject()
            end
        end
	end
	box:register_component(starting_component)
    -- Defense Rule
    local box_defense = Battle.DefenseRule.new(1, DefenseOrder.Always)
    box_defense.filter_statuses_func = function(a_props)
        a_props.flags = a_props.flags & (~Hit.Flash)
        --a_props.flags = a_props.flags & (~Hit.Drag)
        return a_props
    end
    box_defense.can_block_func = function(judge, attacker, defender)
        if attacker:get_id() == box:get_id() or attacker:get_name() == tostring(box:get_id()) then
            judge:block_collision()
        end
    end
    box:add_defense_rule(box_defense)
    box.on_spawn_func = function(self)
        obs_control = create_controller(self, field:tile_at(0,0))
	    Engine.play_audio(SPAWN_AUDIO, AudioPriority.Immediate)
    end
    box.update_func = function(self)
        check_collision(self, hit_props_c)
        if self.state == "IDLE" then
            if self.frames == 2 then --15 28 , 14
                local tile = nil
                if self.drag_dir == facing_away then
                    local x_start = field:width()
                    local x_end = 1
                    local x_mid = -1
                    if self:get_facing() == Direction.Left then
                        x_start = 1
                        x_end = field:width()
                        x_mid = 1
                    end
                    for i=x_start,x_end,x_mid do
                        local tile0 = field:tile_at(i,self.tile_y)
                        if tile0:get_team() ~= self:get_team() then
                            tile = tile0
                            break
                        end
                    end
                else
                    local x_start = 1
                    local x_end = field:width()
                    local x_mid = 1
                    if self:get_facing() == Direction.Left then
                        x_start = field:width()
                        x_end = 1
                        x_mid = -1
                    end
                    for i=x_start,x_end,x_mid do
                        local tile0 = field:tile_at(i,self.tile_y)
                        if tile0:get_team() ~= self:get_team() and tile0:get_tile(self:get_facing_away(),1):get_team() == self:get_team() then
                            tile = tile0
                            break
                        end
                    end
                end
                create_wind_gust(user, props, self, self.drag_dir, field, team, tile, toppuu.box_type)
                self.tile_y = self.tile_y - 1
                if self.tile_y < 1 then self.tile_y = field:height() end
            end
            if self.frames >= 14 then
                self.frames = 1
                return
            end
            self.frames = self.frames + 1
        end
    end
    box.can_move_to_func = function(tile)
        if not tile:is_walkable() then
            return false
        end
        return true
    end
    box.battle_end_func = function(self)
        self:set_health(0)
    end
    box.delete_func = function(self)
        if self:get_health() <= 0 then
            create_destroyedobstacle(self)
	        Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
            local move_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x, self:get_tile_offset().y+self:get_offset().y, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, false, true)
            field:spawn(move_fx, self:get_tile())
        end
        self:erase()
    end
    field:spawn(box, spawn_tile)
    return box
end

toppuu.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

        local facing_away = user:get_facing_away()
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

		self.frames = 1
		local step1 = Battle.Step.new()
		step1.update_func = function()
			if self.frames == 1 then
                local tile = user:get_tile(facing,1)
                create_wind_box(user, props, facing_away, facing, field, team, tile)
            end
			if self.frames == 51 then
                actor:get_animation():set_playback_speed(orig_speed)
				step1:complete_step()
            end
			self.frames = self.frames + 1
		end
		self:add_step(step1)
	end
	return action
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self, hit_props)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, hit_props, t)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function create_collision_attack(user, hit_props, tile)
    local spell = Battle.Spell.new(Team.Other)
    spell:set_facing(user:get_facing())
    spell:set_hit_props(hit_props)
    spell:set_name(tostring(user:get_id()))
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.collision_func = function(self, other)
        if other:get_id() ~= user:get_id() and not other:get_animation():has_state("PASS_THROUGH") and other:get_name() ~= "CANTINTERACT" then
            user:set_health(0)
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    user:get_field():spawn(spell, tile)
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_name() ~= "PASS_THROUGH" and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_name() ~= "PASS_THROUGH"
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_name() ~= "PASS_THROUGH" and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return toppuu