local shockwave = include("shockwave/shockwave.lua")

local DAMAGE = 60

shockwave.type = "0"

shockwave.codes = {"D","J","R","*"}
shockwave.shortname = "ShokWave"
shockwave.damage = DAMAGE
shockwave.time_freeze = false
shockwave.element = Element.None
shockwave.description = "Shock through enemies"
shockwave.long_description = "A piercing attack that moves across the ground"
shockwave.can_boost = true
shockwave.card_class = CardClass.Standard
shockwave.limit = 4
shockwave.mb = 16

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-051-ShockWave")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(shockwave.codes)

    local props = package:get_card_props()
    props.shortname = shockwave.shortname
    props.damage = shockwave.damage
    props.time_freeze = shockwave.time_freeze
    props.element = shockwave.element
    props.description = shockwave.description
    props.long_description = shockwave.long_description
    props.can_boost = shockwave.can_boost
	props.card_class = shockwave.card_class
	props.limit = shockwave.limit
end

card_create_action = shockwave.card_create_action