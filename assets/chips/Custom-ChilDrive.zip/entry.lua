local BUSTERUP_TEXTURE = Engine.load_texture(_modpath.."busterup.png")
local BUSTERUP_ANIMATION_PATH = _modpath.."busterup.animation"
local BUSTERUP_SOUND = Engine.load_audio(_modpath.."busterup.ogg") 

local ZapRing1 = include("charged/wave.lua")


function package_init(package) 
    package:declare_package_id("com.darkware.card.PKMN026")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'C'})

    local props = package:get_card_props()
    props.shortname = "ChilDrive"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.None
    props.description = "Change charged atk"
	props.long_description = "Changes Charged Attack to Ice Shockwave." 
    props.limit = 1
    props.can_boost = false
	props.card_class = CardClass.Standard

end

function charge_attack_zap(player)
    local props = Battle.CardProperties:new()
    props.damage = (player:get_attack_level() * 10)
    local ZapRing1_action = ZapRing1.card_create_action(player, props)
    return ZapRing1_action
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_async_lockout(.33))

    local artifact = Battle.Artifact.new()
    artifact:sprite():set_layer(-2)
    artifact:set_facing(user:get_facing())
    artifact:set_texture(BUSTERUP_TEXTURE, true)
    artifact:set_offset(0, 0)
    artifact:get_animation():load(BUSTERUP_ANIMATION_PATH)
    artifact:get_animation():set_state("DEFAULT")
    artifact:get_animation():refresh(artifact:sprite())

    artifact:get_animation():on_complete(function()
        artifact:delete()
    end)

    action.execute_func = function()
        Engine.play_audio(BUSTERUP_SOUND, AudioPriority.Low)
        user:get_field():spawn(artifact, user:get_current_tile())

        local player = Battle.Player.from(user)

         if player then 

                Battle.Player.from(player).charged_attack_func = charge_attack_zap
            

            

            
        end
    end

    return action
end

