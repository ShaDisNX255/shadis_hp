nonce = function() end

local DAMAGE = 10 --default damage (should be overriden by caller with action.damage)
local sub_folder_path = _folderpath
local WAVE_TEXTURE = Engine.load_texture(sub_folder_path.."shockwave.png")
local AUDIO = Engine.load_audio(sub_folder_path.."shockwave.ogg")

local iceslash = {

}

iceslash.card_create_action = function(actor, props)
local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local pega_buster_texture = Engine.load_texture(sub_folder_path.."pegashot.png")
		local pega_buster_animation_path = sub_folder_path.."pegashot.animation"
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(pega_buster_texture)
        buster_sprite:set_layer(-2)
        local buster_anim = buster:get_animation()
        buster_anim:load(pega_buster_animation_path)
        buster_anim:set_state("BUSTER")
		local cannonshot = create_iceslash(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot, tile)
	end
    return action
end

function create_iceslash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())

	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flash,
			Element.None,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	spell:set_texture(WAVE_TEXTURE, true)
	anim:load(sub_folder_path.."shockwave.animation")
	anim:set_state("DEFAULT")
	spell.update_func = function(self, dt)
		self:get_tile():attack_entities(self)
		if self:is_sliding() == false then
			if self:get_current_tile():is_edge() and self.slide_started then 
				self:delete()
			end 

			local dest = self:get_tile(spell:get_facing(), 1)
			local ref = self
			self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary, 
				function()
					ref.slide_started = true 
				end
			)
		end

	end
    	spell.collision_func = function(self, other) 
				local tile = self:get_current_tile()
		if tile and not tile:is_edge() then
			tile:set_state(TileState.Ice)
	
		end
		self:delete()
    	end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

return iceslash