local BUSTERUP_TEXTURE = Engine.load_texture(_modpath.."busterup.png")
local BUSTERUP_ANIMATION_PATH = _modpath.."busterup.animation"
local BUSTERUP_SOUND = Engine.load_audio(_modpath.."busterup.ogg") 




function package_init(package) 
    package:declare_package_id("com.darkware.card.PKMN025")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'D'})

    local props = package:get_card_props()
    props.shortname = "DoseDrive"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Change charged atk"
	props.long_description = "Changes Charged Attack to Bubbler." 
    props.limit = 1
    props.can_boost = false
	props.card_class = CardClass.Standard

end

function charge_attack_zap(player)
		local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
		local frame1 = {1, 0.1}
		local frame2 = {2, 0.066}
		local frame3 = {3, 0.066}
		local frame4 = {4, 0.066}
		local frame5 = {5, 0.033}
		local frame6 = {6, 0.033}
		local new_frames = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6})
		
		action:override_animation_frames(new_frames)
		
		action:set_lockout(make_animation_lockout())
		
		action.execute_func = function(self, user)
			local buster = self:add_attachment("BUSTER")
			local sprite = buster:sprite()
			sprite:set_texture(Engine.load_texture(_modpath.."spout_cross.png"), false)
			sprite:set_layer(-1)
			local buster_anim = buster:get_animation()
			buster_anim:load(_modpath.."spout_cross.animation")
			buster_anim:set_state("BUSTER_CHARGED")
			Engine.play_audio(Engine.load_audio(_modpath.."spout_shoot.ogg", true), AudioPriority.High)
			self:add_anim_action(3, function()
				local DAMAGE = ((player:get_attack_level() * 10))
				local props = HitProps.new(
					DAMAGE,
					Hit.Impact | Hit.Flinch | Hit.Flash, 
					Element.Aqua,
					player:get_context(),
					Drag.None
				)
				local cannonshot = create_bubbler(player, props)
				local tile = player:get_tile(player:get_facing(), 1)
				player:get_field():spawn(cannonshot, tile)
			end)
		end
		return action
	end


function create_bubbler(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell.slide_started = false
	local direction = spell:get_facing()
    spell:set_hit_props(props)
	local query = function(ent)
		return Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil
	end
	spell.has_hit = false
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end
			if not self.has_hit then
				local dest = self:get_tile(direction, 1)
				local ref = self
				self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
					function()
						ref.slide_started = true 
					end
				)
			end
        end
    end
	spell.collision_func = function(self, other)
		self.has_hit = true
		Engine.play_audio(Engine.load_audio(_modpath.."hit.ogg", true), AudioPriority.High)
		Engine.play_audio(Engine.load_audio(_modpath.."spout_bubbles.ogg", true), AudioPriority.High)
		spell:set_texture(Engine.load_texture(_modpath.."bubbler.png"), true)
		spell:get_animation():load(_modpath.."bubbler.animation")
		spell:get_animation():set_state("DEFAULT")
		spell:sprite():set_layer(-1)
		spell:get_animation():refresh(spell:sprite())
		spell:set_height(-20)
		local tile = spell:get_tile():get_tile(spell:get_facing(), 1)
		if tile and not tile:is_edge() then
			local hitbox = Battle.Hitbox.new(spell:get_team())
			hitbox:set_hit_props(spell:copy_hit_props())
			local fx = Battle.Artifact.new()
			fx:set_texture(Engine.load_texture(_modpath.."bubbler.png"), true)
			local anim = fx:get_animation()
			anim:load(_modpath.."bubbler.animation")
			anim:set_state("DEFAULT")
			fx:sprite():set_layer(-1)
			fx:set_offset(0.0, 20.0)
			anim:refresh(fx:sprite())
			anim:on_complete(function()
				fx:erase()
			end)
			user:get_field():spawn(fx, tile)
			user:get_field():spawn(hitbox, tile)
		end
		spell:get_animation():on_complete(function()
			spell:erase()
		end)
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	-- Engine.play_audio(Engine.load_audio(_modpath.."forms/airshot.ogg", true), AudioPriority.High)
	return spell
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_async_lockout(.33))

    local artifact = Battle.Artifact.new()
    artifact:sprite():set_layer(-2)
    artifact:set_facing(user:get_facing())
    artifact:set_texture(BUSTERUP_TEXTURE, true)
    artifact:set_offset(0, 0)
    artifact:get_animation():load(BUSTERUP_ANIMATION_PATH)
    artifact:get_animation():set_state("DEFAULT")
    artifact:get_animation():refresh(artifact:sprite())

    artifact:get_animation():on_complete(function()
        artifact:delete()
    end)

    action.execute_func = function()
        Engine.play_audio(BUSTERUP_SOUND, AudioPriority.Low)
        user:get_field():spawn(artifact, user:get_current_tile())

        local player = Battle.Player.from(user)

         if player then 
            
                Battle.Player.from(player).charged_attack_func = charge_attack_zap
            

            

            
        end
    end

    return action
end

