local blind = include("blind/blind.lua")

local DAMAGE = 0

blind.codes = {"*"}
blind.shortname = "Blind"
blind.damage = DAMAGE
blind.time_freeze = true
blind.element = Element.None
blind.description = "Blind the\nenemy w/\nlight!"
blind.long_description = "Blind your opponent with powerful light!"
blind.can_boost = false
blind.card_class = CardClass.Standard
blind.limit = 1
blind.mb = 9

function package_init(package)
    package:declare_package_id("com.wcity.OFC.card.EXE4-129-Blind")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(blind.codes)

    local props = package:get_card_props()
    props.shortname = blind.shortname
    props.damage = blind.damage
    props.time_freeze = blind.time_freeze
    props.element = blind.element
    props.description = blind.description
    props.long_description = blind.long_description
    props.can_boost = blind.can_boost
	props.card_class = blind.card_class
	props.limit = blind.limit
end

card_create_action = blind.card_create_action