local print_debug = false

local FLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/flash.png")
local FLASH_ANIMPATH = _folderpath.."gfx/flash.animation"
local FLASH_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_237.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[Blind] "..text)
    end
end

local blind = {}

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_hitbox(user, facing, field, team, tile)
    local hitbox = Battle.Spell.new(team)
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(0)
        --:impact()
        :pierce()
        :retangible()
        :blind(frames(480))
        :no_counter()
        :elem(Element.None)
        :from(user:get_context())
    )
    hitbox.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

blind.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()
		local all_enemy_tiles = field:find_tiles(function(tile)
			return tile and not tile:is_edge() and tile:get_team() ~= team
		end)
		self.frames = 1
		local step1 = Battle.Step.new()
		step1.update_func = function()
            for i=1, 71 do
			    if self.frames == i then
                    user:set_color(Color.new(255, 255, 255, 255))
                end
            end
			if self.frames == 12 then
				Engine.play_audio(FLASH_AUDIO, AudioPriority.Immediate)
				local flash_fx = graphic_init("artifact", 0, 0, FLASH_TEXTURE, nil, FLASH_ANIMPATH, 999, "0", Playback.Once, user, Direction.Right, true, false, true)
				field:spawn(flash_fx, field:tile_at(0,0))
                for i=1, #all_enemy_tiles do
                    create_hitbox(user, facing, field, team, all_enemy_tiles[i])
                end
            end
			if self.frames == 74 then
                user:get_animation():set_playback_speed(orig_speed)
				step1:complete_step()
			end
			self.frames = self.frames + 1
		end
		self:add_step(step1)
	end
	return action
end

return blind