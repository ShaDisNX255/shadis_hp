local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/buster.png")
local BUSTER_ANIMPATH = _folderpath.."gfx/buster.animation"
local FLAME_TEXTURE = Engine.load_texture(_folderpath.."gfx/flame.png")
local FLAME_ANIMPATH = _folderpath.."gfx/flame.animation"

local FLAME_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_344.ogg", true)

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local hellsburner = {}

local function debug_print(text)
    if print_debug then
        print("[HellsBurner] "..text)
    end
end

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    --[[
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end]]
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_flame_spell(user, props, tile, flame_x, flame_y)
    if not tile or tile:is_edge() then return end
    local spell = graphic_init("spell", flame_x, flame_y, FLAME_TEXTURE, FLAME_ANIMPATH, "0", Playback.Loop, -3, user, user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    spell.frames = 0
    spell.update_func = function(self)
        self.frames = self.frames + 1
        tile:attack_entities(self)
        if self.frames == 1 then
            self:highlight_tile(Highlight.Solid)
        elseif self.frames >= 2 then
            if not tile:is_hole() then
                if not tile:is_cracked() then
                    tile:set_state(TileState.Cracked)
                end
            end
        end
        if self.frames > 31 then
            spell:delete()
        end
    end
    spell.attack_func = function(self, other)
        local offset_y = math.random(math.floor(flame_y/2),math.floor(flame_y/2+10))
        local offset_x = math.random(-14,-3)
        if self:get_facing() == Direction.Left then offset_x = math.random(2,13) end
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, self, self:get_facing(), true)
        hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
        self:get_field():spawn(hit_effect, other:get_tile())
        if Battle.Obstacle.from(other) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    user:get_field():spawn(spell, tile)
    return spell
end

local function create_spawner(user, props, tile)
    local spawner = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    --[[
    local user_width = user:sprite():get_width()
    local user_height = user:sprite():get_height()
    local point = user:get_animation():point("BUSTER")
    print("user_width: "..user_width)
    print("point: "..point.x)
    local offset_x = user_width-(point.x*2)
    if spawner:get_facing() == Direction.Left then offset_x = -offset_x end
    local offset_y = -user_height+(point.y*2)
    ]]
    local anim = user:get_animation()
    local origin = anim:point("ORIGIN")
    local origin_b = anim:point("BUSTER")
    local offset_y = (origin_b.y-origin.y)*2
    local offset_x = (origin_b.x-origin.x)*2
    if spawner:get_facing() == Direction.Left then offset_x = -offset_x end
    spawner.frames = 0
    spawner.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames == 1 then
            Engine.play_audio(FLAME_AUDIO, AudioPriority.Low)
            create_flame_spell(user, props, tile:get_tile(user:get_facing(), 1), offset_x, offset_y)
        elseif self.frames == 5 then
            create_flame_spell(user, props, tile:get_tile(user:get_facing(), 2), offset_x, offset_y)
        elseif self.frames == 9 then
            create_flame_spell(user, props, tile:get_tile(user:get_facing(), 3), offset_x, offset_y)
        elseif self.frames == 17 then
            Engine.play_audio(FLAME_AUDIO, AudioPriority.Low)
        elseif self.frames > 17 then
            spawner:erase()
        end
    end
    user:get_field():spawn(spawner, tile)
    return spawner
end

hellsburner.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local frame0 = {1,0.0} -- 0 because engine adds an extra frame to start oops.
	local frame12 = {1,0.017}
	local frame11 = {1,0.033}
	local frame1 = {1,0.05}
	local frame2 = {1,0.033}
	local frame_sequence = make_frame_data({frame0,
    frame12, frame11, frame2,
    frame12, frame11, frame2,
    frame12, frame11, frame2,
    frame12, frame11, frame2,
    frame12, frame11, frame2,
    frame12, frame11, frame2,
    frame12, frame11, frame2
    })
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		local buster_anim = buster:get_animation()
		buster_anim:load(BUSTER_ANIMPATH)
		buster_anim:set_state("0")
		buster_anim:set_playback(Playback.Loop)
		buster_anim:refresh(buster:sprite())
		user:toggle_counter(true)
        create_spawner(user, props, user:get_tile())
        self:add_anim_action(3, function()
            buster_anim:set_state("1")
            buster_anim:set_playback(Playback.Loop)
            buster_anim:refresh(buster:sprite())
        end)
        self:add_anim_action(11, function()
            user:toggle_counter(false)
        end)
	end
	action.action_end_func = function()
		user:toggle_counter(false)
	end
    return action
end

return hellsburner