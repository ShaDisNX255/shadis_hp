local DAMAGE = 60
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local TEXTURE = Engine.load_texture(_folderpath.."boomerang.png")
local ANIMATION_PATH = _folderpath.."boomerang.animation"
local BOOMERANG_AUDIO = Engine.load_audio(_folderpath.."EXE4_143.ogg")

local boomerang = {
    codes = {"L","M","N","*"},
    shortname = "Boomrng1",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.Wood,
    description = "Boomerang that circ batlfield",
    long_description = "A piercing Boomerang flies along the edge of the battlefield",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 4,
    mb = 18,
}

boomerang.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(0.509))

    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        execute_func(user, props, team, facing, field)
    end

    return action
end

function execute_func(user, props, team, facing, field)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            props.element,
            user:get_id(),
            Drag.None
        )
    )
    spell:set_facing(facing)
    spell:set_texture(TEXTURE, true)
    spell:set_offset(0, -14)
    spell:highlight_tile(Highlight.Solid)
    local anim = spell:get_animation()
    anim:load(ANIMATION_PATH)
    anim:set_state("DEFAULT")
    anim:set_playback(Playback.Loop)
    Engine.play_audio(BOOMERANG_AUDIO, AudioPriority.Low)
    spell.slide_started = false
    spell.state = 0
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        if not self:is_sliding() then
            local direction = self:get_tile(facing, 1)
            local is_at = self:get_current_tile()
            local ref = self
            if facing == Direction.Right then
                if is_at == field:tile_at(0,1) then
                    spell:erase()
                end
                if is_at == field:tile_at(6,3) and ref.state == 0 then
                    ref.state = 1
                elseif is_at == field:tile_at(6,1) and ref.state == 1 then
                    ref.state = 2
                end
            else
                if is_at == field:tile_at(7,1) then
                    spell:erase()
                end
                if is_at == field:tile_at(1,3) and ref.state == 0 then
                    ref.state = 1
                elseif is_at == field:tile_at(1,1) and ref.state == 1 then
                    ref.state = 2
                end
            end
            if ref.state == 1 then
                direction = self:get_tile(Direction.Up, 1)
            elseif ref.state == 2 then
                direction = self:get_tile(Direction.reverse(facing), 1)
            else
                direction = self:get_tile(facing, 1)
            end
            spell:slide(direction, frames(4), frames(0), ActionOrder.Voluntary, 
            function()
                ref.slide_started = true
            end)
        end
    end
    spell.attack_func = function(self, ent)
		create_effect(Direction.Right, EFFECT_TEXTURE, EFFECT_ANIMPATH, "5", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end
    spell.can_move_to_func = function()
        return true
    end
    if facing == Direction.Right then
        field:spawn(spell, 1,3)
    else 
        field:spawn(spell, 6,3)
    end
    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return boomerang