local cube = include("cube/cube.lua")

local DAMAGE = 0

cube.cube_name = "StoneCube"
cube.cube_type = "STONE"
cube.cube_health = 200

cube.codes = {"*"}
cube.shortname = "StonCube"
cube.damage = DAMAGE
cube.time_freeze = true
cube.element = Element.Summon
cube.description = "Place a\nStoneCube\nin front"
cube.long_description = "Place a StoneCube on the square in front of you"
cube.can_boost = false
cube.card_class = CardClass.Standard
cube.limit = 5
cube.mb = 6

function package_init(package) 
    package:declare_package_id("com.OFC.card.EXE6-138-StoneCube")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(cube.codes)

    local props = package:get_card_props()
    props.shortname = cube.shortname
    props.damage = cube.damage
    props.time_freeze = cube.time_freeze
    props.element = cube.element
    props.description = cube.description
    props.long_description = cube.long_description
    props.can_boost = cube.can_boost
	props.card_class = cube.card_class
	props.limit = cube.limit
end

card_create_action = cube.card_create_action