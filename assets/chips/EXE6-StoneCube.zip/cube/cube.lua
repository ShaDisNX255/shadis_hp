local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local CUBE_TEXTURE = Engine.load_texture(_folderpath.."gfx/cube.grayscaled.png")
local CUBE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/cube.png")
local CUBE_ANIMPATH = _folderpath.."gfx/cube.animation"
local SHADOW_TEXTURE_1 = Engine.load_texture(_folderpath.."gfx/shadow1.png")
local SHADOW_TEXTURE_2 = Engine.load_texture(_folderpath.."gfx/shadow2.png")

local PIECES_TEXTURE = Engine.load_texture(_folderpath.."gfx/pieces.grayscaled.png")
local PIECES_PALETTE_STONE = Engine.load_texture(_folderpath.."gfx/palette/stone.png")
local PIECES_PALETTE_ICE = Engine.load_texture(_folderpath.."gfx/palette/ice.png")
local PIECES_ANIMPATH = _folderpath.."gfx/pieces.animation"

local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."gfx/smoke.grayscaled.png") -- flip for Player 2
local SMOKE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/smoke.png")
local SMOKE_ANIMPATH = _folderpath.."gfx/smoke.animation"

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png") -- flip for Player 2
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local SPAWN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_87.ogg", true)
local CRACK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_324.ogg", true)

local ObstacleInfo = include("ObstacleInfo.lua")

local function debug_print(text)
    if print_debug then
        print("[Cube] "..text)
    end
end

local cube = {}

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    --[[
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end]]
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_piece(user, facing, field, tile, state, end_frames, cube_o_x, cube_o_y)
	local piece = graphic_init("artifact", 0, 0, PIECES_TEXTURE, PIECES_ANIMPATH, state, Playback.Once, -3, user, facing, true)
	if cube.cube_type == "ICE" then
		piece:store_base_palette(PIECES_PALETTE_ICE)
	else
		piece:store_base_palette(PIECES_PALETTE_STONE)
	end
	piece:set_palette(piece:get_base_palette())
	piece.frames = 0
	piece.x_change = 0
	piece.y_change = 0
	piece.y_change1 = math.random(-9,-3)
	piece.y_change2 = math.floor(piece.y_change1/2)
	piece.y_change3 = math.floor(piece.y_change2/2)
	piece.update_func = function(self)
		self.frames = self.frames + 1
		if self.frames == 1 then
			self.x_change = math.random(-5,5)
			self.y_change = self.y_change1
		elseif self.frames == 4 then
			self.y_change = self.y_change2
		elseif self.frames == 7 then
			self.y_change = self.y_change3
		elseif self.frames == 10 then
			self.y_change = 0
		elseif self.frames == 13 then
			self.y_change = -self.y_change3
		elseif self.frames == 16 then
			self.y_change = -self.y_change2
		elseif self.frames == 19 then
			self.y_change = -self.y_change1
		elseif self.frames >= end_frames then
			self:delete()
		end
		self:set_offset(self:get_offset().x+(self.x_change*2),self:get_offset().y+(self.y_change*2))
	end
	piece.delete_func = function(self)
		local smoke_fx = graphic_init("artifact", self:get_offset().x+self:get_tile_offset().x, self:get_offset().y+self:get_tile_offset().y, SMOKE_TEXTURE, SMOKE_ANIMPATH, "0", Playback.Once, -3, user, facing, true)
		smoke_fx:store_base_palette(SMOKE_PALETTE)
		smoke_fx:set_palette(smoke_fx:get_base_palette())
		smoke_fx:get_animation():on_complete(function() smoke_fx:erase() end)
		field:spawn(smoke_fx, self:get_tile())
	end
	field:spawn(piece, tile)
	return piece
end

cube.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()
		local step1 = Battle.Step.new()
		local obs_cube = Battle.Obstacle.new(Team.Other)
		ObstacleInfo.set_cannot_be_targeted(obs_cube, false)
		ObstacleInfo.set_cannot_be_manipulated(obs_cube, false)
		ObstacleInfo.add_to_limit_2(obs_cube, obs_cube:get_team(), field)
		local obs_hitbox = nil
		local function create_hitbox(spawn_tile)
			local hitbox = Battle.Spell.new(obs_cube:get_team())
			hitbox:set_hit_props(
				HitProps.new(
					cube.cube_health,
					Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
					Element.None,
					user:get_id(),
					Drag.None
				)
			)
			hitbox.do_once = true
			local hit_query = function(ent)
				return (Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) and ent:get_health() > 0 and not ent:is_team(user:get_team()) and ent:get_id() ~= obs_cube:get_id()
			end
			hitbox.update_func = function(self)
				if #self:get_tile():find_entities(hit_query) > 0 then
					self:get_tile():attack_entities(self)
					--if self.do_once then
					--	self.do_once = false
						--create_breath_hitbox(user, self:get_tile())
					--end
				else
					--if not self.do_once then
					--	self.do_once = true
					--end
				end
				if obs_cube == nil or obs_cube:is_deleted() then
					self:delete()
				else
					if self:get_tile() ~= obs_cube:get_tile() then
						self:teleport(obs_cube:get_tile(), ActionOrder.Immediate)
					end
				end
			end
			hitbox.attack_func = function(self, other)
				debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
				local offset_y = math.random(-7,5)
				local offset_x = math.random(-7,6)
				if facing == Direction.Left then offset_x = -offset_x end
				local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, user, facing, true)
				hit_fx:store_base_palette(EFFECT_PALETTE)
				hit_fx:set_palette(hit_fx:get_base_palette())
				hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
				field:spawn(hit_fx, other:get_tile())
				if Battle.Obstacle.from(other) == nil then
					if Battle.Player.from(user) ~= nil then
						Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
					end
				else
					Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
				end
			end
			hitbox.collision_func = function(self, other)
				--print("COLLIDE")
				if obs_cube == nil or obs_cube:is_deleted() then
				else
					if other:get_id() ~= obs_cube:get_id() then
						obs_cube:set_health(0)
					end
				end
			end
			hitbox.can_move_to_func = function(tile)
				return true
			end
			field:spawn(hitbox, spawn_tile)
			return hitbox
		end

		local a_frames = 0
		local do_once = true
		local query = function(ent)
			if ent:get_health() <= 0 or ent:get_id() == obs_cube:get_id() then return false end
			return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil
		end
		step1.update_func = function(self)
			a_frames = a_frames + 1
			if a_frames >= 60 then
				self:complete_step()
			end
			if do_once then
				do_once = false
				local desired_tile = user:get_tile(facing, 1)
				Engine.play_audio(SPAWN_AUDIO, AudioPriority.Low)
				obs_cube:set_name(cube.cube_name)
				obs_cube:set_facing(facing)
				obs_cube:set_texture(CUBE_TEXTURE, true)
				obs_cube:store_base_palette(CUBE_PALETTE)
				obs_cube:set_palette(obs_cube:get_base_palette())
				obs_cube:never_flip(true)
				obs_cube:sprite():set_layer(-3)
				local anim = obs_cube:get_animation()
				anim:load(CUBE_ANIMPATH)
				anim:set_state("SPAWN")
				anim:refresh(obs_cube:sprite())
				anim:on_frame(2, function()
					if cube.cube_type == "METAL" then
						obs_cube:set_shadow(SHADOW_TEXTURE_2)
					else
						obs_cube:set_shadow(SHADOW_TEXTURE_1)
					end
					obs_cube:show_shadow(true)
				end)
				anim:on_complete(function()
					local tile = obs_cube:get_tile()
					local chars = {}
					local obs = {}
					field:find_entities(function(e)
					  	local id = e:get_id()
					  	if Battle.Obstacle.from(e) then 
					  	  	table.insert(obs, id)
					  	elseif Battle.Character.from(e) then 
					  	  	table.insert(chars, id)
					  	end
					end)
					local ignore_list = obs
					-- https://protobasilisk.github.io/OpenNetBattleDocs/api/#tile-is_reserved
					local not_reserved_by_ob = tile:is_reserved(obs)
					--print(tile:is_walkable())
					--print(tile:is_reserved(chars))
					--print(tile:is_reserved(obs))
					--print(#tile:find_entities(query))
					if not tile:is_hole() and #tile:find_entities(query) <= 0 and ((tile:is_reserved(chars) and tile:is_reserved(obs)) or (tile:is_reserved(chars) and not tile:is_reserved(obs)) or (not tile:is_reserved(chars) and not tile:is_reserved(obs))) then
						anim:set_state(cube.cube_type)
						anim:refresh(obs_cube:sprite())
						anim:set_playback(Playback.Loop)
						obs_hitbox = create_hitbox(tile)
					else
						obs_cube:set_health(0)
					end
				end)
				obs_cube:set_health(cube.cube_health)

				-- deletion process var
				local delete_self = nil
				--local spawned_hitbox = false
				local countdown = 6000
				-- slide tracker
				local continue_slide = false
				local prev_tile = {}
				local cube_speed = 4

				-- define cube collision hitprops
				local props = HitProps.new(
					cube.cube_health,
					Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking, 
					Element.Break,
					user:get_context(),
					Drag.None
				)

				local cube_defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
				cube_defense_rule.filter_statuses_func = function(hit_props)
					if (hit_props.flags & Hit.Impact == Hit.Impact) and (hit_props.flags & Hit.Drag == Hit.Drag) then
						hit_props.damage = 0
						continue_slide = true
					end
					hit_props.flags = hit_props.flags & (~Hit.Flinch)
					hit_props.flags = hit_props.flags & (~Hit.Flash)
					hit_props.flags = hit_props.flags & (~Hit.Stun)
					hit_props.flags = hit_props.flags & (~Hit.Root)
					hit_props.flags = hit_props.flags & (~Hit.Shake)
					hit_props.flags = hit_props.flags & (~Hit.Pierce)
					hit_props.flags = hit_props.flags & (~Hit.Retangible)
					hit_props.flags = hit_props.flags & (~Hit.Bubble)
					hit_props.flags = hit_props.flags & (~Hit.Freeze)
					hit_props.flags = hit_props.flags & (~Hit.Blind)
					--hit_props.element = Element.None
					return hit_props
				end
				cube_defense_rule.can_block_func = function(judge, attacker, defender)
					local attacker_hit_props = attacker:copy_hit_props()
					if obs_hitbox ~= nil and not obs_hitbox:is_deleted() and attacker:get_id() == obs_hitbox:get_id() then
						judge:block_damage()
						judge:block_impact()
					else
						if attacker_hit_props.damage == 0 then
							judge:block_damage()
							judge:block_impact()
						else
							if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
								obs_cube:set_health(0)
							end
						end
					end
				end
				obs_cube:add_defense_rule(cube_defense_rule)

				-- upon tangible collision
				--[[
				obs_cube.collision_func = function(self)
					-- define the hitbox with its props every frame
					local hitbox = Battle.Hitbox.new(obs_cube:get_team())
					hitbox:set_hit_props(props)

					if not spawned_hitbox then
						obs_cube:get_field():spawn(hitbox, obs_cube:get_tile())
						spawned_hitbox = true
					end
					obs_cube.delete_func()
				end
				-- upon passing the defense check
				]]

				obs_cube.can_move_to_func = function(tile)
					if tile then
						-- get a list of every obstacle with Team.Other on the field
						local field = obs_cube:get_field()
						local cube_team = obs_cube:get_team()
						local Other_obstacles = function(obstacle)
							return obstacle:get_team() == cube_team
						end
						local obstacles_here = field:find_obstacles(Other_obstacles)
						local donotmove = false
						-- look through the list of obstacles and read their tile position, check if we're trying to move to their tile.
						for ii=1,#obstacles_here do
							if tile == obstacles_here[ii]:get_tile() then
								donotmove = true
							end
						end
						if tile:is_edge() or donotmove or not tile:is_walkable() then
							return false
						end
					end
					return true
				end
				obs_cube.update_func = function(self)
					local tile = obs_cube:get_tile()
					if not tile then
						obs_cube.delete_func()
					end
					if tile:is_edge() then
						obs_cube.delete_func()
					end
					if not delete_self then
						--tile:attack_entities(obs_cube)
					end
					local direction = self:get_facing()
					if self:is_sliding() then
						table.insert(prev_tile,1, tile)
						prev_tile[cube_speed+1] = nil
						local target_tile = tile:get_tile(direction, 1)
						if self.can_move_to_func(target_tile) then
							continue_slide = true
						else
							continue_slide = false
						end
					else
						-- become aware of which direction you just moved in, turn to face that direction
						if prev_tile[cube_speed] then
							if prev_tile[cube_speed]:get_tile(direction, 1):x() ~= tile:x() then
								direction = self:get_facing_away()
								self:set_facing(direction)
							end
						end
					end
					if not self:is_sliding() and continue_slide then
						self:slide(self:get_tile(direction, 1), frames(cube_speed), frames(0), ActionOrder.Voluntary, function() end)
					end
					if countdown > 0 then countdown = countdown - 1 else obs_cube:set_health(0) end
					-- deletion handler in main loop, starts running once something in here has requested deletion
					if delete_self then
						if type(delete_self) ~= "number" then
							delete_self = 2
						end
						if delete_self > 0 then
							delete_self = delete_self - 1
						elseif delete_self == 0 then
							delete_self = -1
							self:erase()
						end
					end
				end
				obs_cube.delete_func = function(self)
					if obs_cube:get_health() <= 0 then
						Engine.play_audio(CRACK_AUDIO, AudioPriority.Low)
						local smoke_fx = graphic_init("artifact", obs_cube:get_offset().x+obs_cube:get_tile_offset().x, obs_cube:get_offset().y+(-16*2)+obs_cube:get_tile_offset().y, SMOKE_TEXTURE, SMOKE_ANIMPATH, "1", Playback.Once, -3, user, facing, true)
						smoke_fx:store_base_palette(SMOKE_PALETTE)
						smoke_fx:set_palette(smoke_fx:get_base_palette())
						smoke_fx:get_animation():on_complete(function() smoke_fx:erase() end)
						field:spawn(smoke_fx, obs_cube:get_tile())
						create_piece(user, facing, field, obs_cube:get_tile(), tostring(math.random(0,1)), math.random(21,27), obs_cube:get_offset().x+obs_cube:get_tile_offset().x, obs_cube:get_offset().y+obs_cube:get_tile_offset().y)
						create_piece(user, facing, field, obs_cube:get_tile(), tostring(math.random(0,1)), math.random(21,27), obs_cube:get_offset().x+obs_cube:get_tile_offset().x, obs_cube:get_offset().y+obs_cube:get_tile_offset().y)
					end
					if type(delete_self) ~= "number" then
						delete_self = true
					end
				end
				if --[[#desired_tile:find_entities(query) == 0 and]] not desired_tile:is_edge() then
					field:spawn(obs_cube, desired_tile)
				end
			end
		end
		self:add_step(step1)
	end
    return action
end

return cube