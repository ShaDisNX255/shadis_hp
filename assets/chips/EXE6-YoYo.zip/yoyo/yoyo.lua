local print_debug = false

local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/buster.png")
local BUSTER_ANIMPATH = _folderpath.."gfx/buster.animation"
local YOYO_TEXTURE = Engine.load_texture(_folderpath.."gfx/yoyo.png")
local YOYO_ANIMPATH = _folderpath.."gfx/yoyo.animation"

local YOYO_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_342.ogg", true)

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local yoyo = {}

local function debug_print(text)
    if print_debug then
        print("[Yo-Yo] "..text)
    end
end

--(Function by Alrysc)
local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function spawn_hitbox(user, team, field, tile, hitbox_props)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(hitbox_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    spell.attack_func = function(self, other)
        local offset_y = nil
        local offset_x = nil
        if self:is_sliding() then
            offset_y = math.random(-35,-20)
            if self:get_tile() == self.prev_tile then
                offset_x = math.random(11,26)
                if self:get_move_direction() == Direction.Left then offset_x = math.random(-27,-12) end
            elseif self:get_tile() == self.next_tile then
                offset_x = math.random(-27,-12)
                if self:get_move_direction() == Direction.Left then offset_x = math.random(11,26) end
            end
        else
            offset_y = math.random(-34,-21)
            offset_x = math.random(-9,8)
            local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, user, Direction.Right, true)
            hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
            user:get_field():spawn(hit_effect, other:get_tile())
        end
        if Battle.Obstacle.from(other) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    field:spawn(spell, tile)
end

local function spawn_yoyo(user, props, team, field, tile, facing)
    local spell = graphic_init("spell", 0, 0, YOYO_TEXTURE, YOYO_ANIMPATH, "0", Playback.Loop, -3, user, facing)
    spell:set_move_direction(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            Element.Sword,
            user:get_context(),
            Drag.None
        )
    )
    local tile2 = tile:get_tile(spell:get_facing(), 1)
    local tile3 = tile:get_tile(spell:get_facing(), 2)
    spell.prev_tile = nil
    spell.next_tile = nil
    spell.on_spawn_func = function(tile)
        Engine.play_audio(YOYO_AUDIO, AudioPriority.Low)
    end
    spell.attacking = true
    spell.frames = 0
    spell.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames == 1 then
            self:highlight_tile(Highlight.Solid)
        elseif self.frames == 3 then
            if tile2 then
                self:slide(tile2, frames(7), frames(0), ActionOrder.Immediate)
                spell.prev_tile = tile
                spell.next_tile = tile2
            end
        elseif self.frames == 11 then
            if tile3 then
                self:slide(tile3, frames(7), frames(0), ActionOrder.Immediate)
                spell.prev_tile = tile2
                spell.next_tile = tile3
            end
        elseif self.frames == 20 then
            self.attacking = false
        elseif self.frames == 27 then
            if tile3 then
                spawn_hitbox(user, team, field, tile3, self:copy_hit_props())
            end
        elseif self.frames == 35 then
            if tile3 then
                spawn_hitbox(user, team, field, tile3, self:copy_hit_props())
            end
        elseif self.frames == 37 then
            self:set_move_direction(self:get_facing_away())
            self.attacking = true
            if tile2 then
                self:slide(tile2, frames(7), frames(0), ActionOrder.Immediate)
                spell.prev_tile = tile3
                spell.next_tile = tile2
            end
        elseif self.frames == 45 then
            self:slide(tile, frames(7), frames(0), ActionOrder.Immediate)
            spell.prev_tile = tile2
            spell.next_tile = tile
        elseif self.frames > 52 then
            self:erase()
        end
        if self.attacking then
            self:get_tile():attack_entities(self)
        end
    end
    spell.attack_func = function(self, other)
        local offset_y = nil
        local offset_x = nil
        if self:is_sliding() then
            offset_y = math.random(-35,-20)
            if self:get_tile() == self.prev_tile then
                offset_x = math.random(11,26)
                if self:get_move_direction() == Direction.Left then offset_x = math.random(-27,-12) end
            elseif self:get_tile() == self.next_tile then
                offset_x = math.random(-27,-12)
                if self:get_move_direction() == Direction.Left then offset_x = math.random(11,26) end
            end
        else
            offset_y = math.random(-34,-21)
            offset_x = math.random(-9,8)
        end
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", Playback.Once, -999, user, Direction.Right, true)
        hit_effect:get_animation():on_complete(function() hit_effect:erase() end)
        user:get_field():spawn(hit_effect, other:get_tile())
        if Battle.Obstacle.from(other) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, tile)
    return spell
end

yoyo.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local frame1 = {1,0.25}
    local frame2 = {1,0.617}
    local frame3 = {1,0.133}
    local frame_sequence = make_frame_data({frame1, frame2, frame3})
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(BUSTER_TEXTURE, false)
        buster_sprite:set_layer(-1)
        local buster_anim = buster:get_animation()
        buster_anim:load(BUSTER_ANIMPATH)
        buster_anim:set_state("0")
        buster_anim:refresh(buster_sprite)
        user:toggle_counter(true)
        spawn_yoyo(user, props, user:get_team(), user:get_field(), user:get_tile(user:get_facing(), 1), user:get_facing())
        self:add_anim_action(2, function()
            user:toggle_counter(false)
        end)
    end
	action.action_end_func = function()
		user:toggle_counter(false)
	end
    return action
end

return yoyo