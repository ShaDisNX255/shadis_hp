local yoyo = include("yoyo/yoyo.lua")

local DAMAGE = 50

yoyo.codes = {"L","M","N"}
yoyo.shortname = "Yo-Yo"
yoyo.damage = DAMAGE
yoyo.time_freeze = false
yoyo.element = Element.None
yoyo.description = "Yo-Yo atk\nreaches\n3sqr ahd!"
yoyo.long_description = "Yo-Yo attack reaches up to 3 squares ahead! 3 hits 3 squares ahead!"
yoyo.can_boost = true
yoyo.card_class = CardClass.Standard
yoyo.limit = 3
yoyo.mb = 32

function package_init(package) 
    package:declare_package_id("com.wcity.OFC.card.EXE6-018-YoYo")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(yoyo.codes)

    local props = package:get_card_props()
    props.shortname = yoyo.shortname
    props.damage = yoyo.damage
    props.time_freeze = yoyo.time_freeze
    props.element = yoyo.element
    props.description = yoyo.description
    props.long_description = yoyo.long_description
    props.can_boost = yoyo.can_boost
	props.card_class = yoyo.card_class
	props.limit = yoyo.limit
end

card_create_action = yoyo.card_create_action