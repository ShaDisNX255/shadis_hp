local boomerang = include("boomerang/boomerang.lua")

local DAMAGE = 80

boomerang.codes = {"O","P","Q"}
boomerang.shortname = "Boomrng2"
boomerang.damage = DAMAGE
boomerang.time_freeze = false
boomerang.element = Element.Wood
boomerang.description = "Boomerang that circ batlfield"
boomerang.long_description = "A piercing Boomerang flies along the edge of the battlefield"
boomerang.can_boost = true
boomerang.card_class = CardClass.Standard
boomerang.limit = 2
boomerang.mb = 30

function package_init(package) 
    package:declare_package_id("com.wcity.OFC.card.EXEPoN-067-Boomerang2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(boomerang.codes)

    local props = package:get_card_props()
    props.shortname = boomerang.shortname
    props.damage = boomerang.damage
    props.time_freeze = boomerang.time_freeze
    props.element = boomerang.element
    props.description = boomerang.description
    props.long_description = boomerang.long_description
    props.can_boost = boomerang.can_boost
	props.card_class = boomerang.card_class
	props.limit = boomerang.limit
end

card_create_action = boomerang.card_create_action