nonce = function() end
 
local AUDIO1 = Engine.load_audio(_modpath.."sound.ogg")
local ELEC_STUN_IMMUNITY_PRIORITY = 999999

local function add_elec_stun_immunity(user)
    local defense_rule = Battle.DefenseRule.new(
        ELEC_STUN_IMMUNITY_PRIORITY,
        DefenseOrder.Always
    )

    defense_rule.filter_statuses_func = function(hit_props)
        if user:get_element() == Element.Elec and
            hit_props.element == Element.Elec then
            hit_props.flags = hit_props.flags & ~Hit.Stun
        end

        return hit_props
    end

    user:add_defense_rule(defense_rule)
end
 
function package_init(package)
    package:declare_package_id("com.wcity.Thor.card.SwapElec")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"*"})
 
    local props = package:get_card_props()
    props.shortname = "SwapElec"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.Elec
    props.secondary_element = Element.None
    props.description = "Navi Elec Element"
    props.card_class = CardClass.Standard
    props.limit = 1
    props.can_boost = false
end

function card_create_action(actor, props)
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")

	action.execute_func = function(self, user)
        actor:set_color(Color.new(255,255,0,200))
		actor:set_element(Element.Elec)
        add_elec_stun_immunity(user)
        Engine.play_audio(AUDIO1, AudioPriority.Low)    
    end
    return action
end
