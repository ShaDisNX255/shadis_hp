local shockwave = include("shockwave/shockwave.lua")

local DAMAGE = 80

shockwave.type = "1"

shockwave.codes = {"G","M","W"}
shockwave.shortname = "SoncWave"
shockwave.damage = DAMAGE
shockwave.time_freeze = false
shockwave.element = Element.None
shockwave.description = "Shock through enemies"
shockwave.long_description = "A piercing attack that moves across the ground"
shockwave.can_boost = true
shockwave.card_class = CardClass.Standard
shockwave.limit = 4
shockwave.mb = 32

function package_init(package)
    package:declare_package_id("com.OFC.card.EXEPoN-052-SonicWave")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes(shockwave.codes)

    local props = package:get_card_props()
    props.shortname = shockwave.shortname
    props.damage = shockwave.damage
    props.time_freeze = shockwave.time_freeze
    props.element = shockwave.element
    props.description = shockwave.description
    props.long_description = shockwave.long_description
    props.can_boost = shockwave.can_boost
	props.card_class = shockwave.card_class
	props.limit = shockwave.limit
end

card_create_action = shockwave.card_create_action