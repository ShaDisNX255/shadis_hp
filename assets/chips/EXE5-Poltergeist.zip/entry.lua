function package_init(package) 
    package:declare_package_id("com.darkware.card.EXE5-Poltergeist")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"P"})

    local props = package:get_card_props()
    props.shortname = "Poltergeist"
    props.time_freeze = true
    props.element = Element.None
    props.description = "Objects thrown at enemies"
    props.long_description = "Objects thrown at enemies"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

local enemy = nil
local enemy_not_found = nil

function card_create_action(actor, props)
        action = Battle.CardAction.new(actor, "PLAYER_SWORD")
        local frame1 = { 1, 0.133 }
        local frame2 = { 2, 0.033 }	
        local frame3 = { 3, 0.033 }
        local frame4 = { 4, 0.167 }		
        local frame5 = { 4, 2.0}			
        local frames = make_frame_data({frame1, frame2, frame3, frame4, frame5})
		
        action:override_animation_frames(frames)
        action:set_lockout(make_animation_lockout())	
		
        action.execute_func = function(self, actor)		
	        find_targets(actor)	

		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)

			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
		end)
	
		self:add_anim_action(5, function()		
		if not enemy_not_found then		
        obstacle_finder(enemy, 30, -26, enemy:get_current_tile())
        else
		local random_x = math.random(1, 6)
		local random_y = math.random(1, 3)		
		
        obstacle_finder(actor, 30, -26, actor:get_field():tile_at( random_x, random_y ))		
		   end		
	   end)
	end
    return action
end

function obstacle_finder(self, target_offset_x, target_offset_y, target_tile)
    self:get_field():find_obstacles(function(o)
        o:hide()
        o:delete()
        create_suction_effect(self, o, target_offset_x, target_offset_y, target_tile, o:get_current_tile())
    end)	
    return   
end

function find_targets(self)
    local target = self:get_field():find_characters(function(other_entity)
        return other_entity:get_team() ~= self:get_team()
    end)

    enemy_not_found = true 

    if target and #target > 0 then
        enemy = target[1]
        enemy_not_found = false 
        return {enemy}, enemy_not_found
    else
        return {}, enemy_not_found
    end
end

function create_suction_effect(self, o, target_offset_x, target_offset_y, target_tile, start_tile)
    local dist_x = target_tile:x() - start_tile:x()
    local dist_y = target_tile:y() - start_tile:y()
    dist_x = dist_x * -1
    local offset_x = dist_x * start_tile:width()
    local offset_y = (dist_y * start_tile:height()) * -1

    local obstacle_texture = o:sprite():get_texture()
    local obstacle_anim = o:get_animation()
    local obstacle_state = obstacle_anim:get_state()

    local artifact = Battle.Artifact.new()
    artifact:sprite():set_texture(obstacle_texture, true)  
	artifact:set_facing(o:get_facing())
    artifact:sprite():set_layer(-7)
    artifact:set_offset(offset_x, offset_y)

    local anim = artifact:get_animation()
    anim:copy_from(obstacle_anim)  
    anim:set_state(obstacle_state)  
    anim:refresh(artifact:sprite())

    Engine.play_audio(Engine.load_audio(_folderpath.."levitate.ogg"), AudioPriority.Low)

    offset_x = offset_x * -1
    local dist_to_move_x = target_offset_x + offset_x
    local dist_to_move_y = target_offset_y - offset_y

    local time = 15  
    local cur_time = 0
    local elevation = 5
    local shake = 1
    local shake2 = 1	
    local frameCount = 0 
    local delayFrames = 100
		
    artifact.update_func = function(self)
	frameCount = frameCount + 1
	
	if frameCount < 30 then	
            elevation = elevation + 4
            self:set_elevation(elevation)	
		end
		
        local mod = cur_time / time

	
	if cur_time % 2 == 0 then
		shake = math.random(3, 8) * -1
	    shake2 = math.random(3, 8) * -1
	end
	
    if frameCount < 99 and frameCount > 30 then	
	        local x = math.floor(offset_x - dist_to_move_x * mod) * -1
            local y = math.floor(offset_y + dist_to_move_y * mod)
self:set_offset(x + shake, y + shake2)
	end
	
	if frameCount >= delayFrames then

            elevation = elevation - 8
            self:set_elevation(elevation)
	
        local mod = cur_time / time
        local x = math.floor(offset_x - dist_to_move_x * mod) * -1
        x = x + x % 2
        local y = math.floor(offset_y + dist_to_move_y * mod)
        y = y + y % 2


        self:set_offset(x, y)

        cur_time = cur_time + 1

        if cur_time > time + 1 then
           self:hide()
		   self:get_field():spawn(create_damage(self, props), self:get_tile())
           self:delete()		   
            end
		end
    end

    self:get_field():spawn(artifact, target_tile)
end


function create_damage(self, props)
	local spell = Battle.Spell.new(self:get_team())
	spell:set_facing(self:get_facing())
	spell:set_hit_props(
		HitProps.new(
			150,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.None,
			self:get_context(),
			Drag.None
		)
	)
	local attack_once = true
	local field = self:get_field()
    local frameCount = 0
    local delayFrames = 5

	
    spell.update_func = function(self, dt) 
		local tile = spell:get_current_tile()
		tile:attack_entities(self)
		frameCount = frameCount + 1
					 if frameCount >= delayFrames then
                     self:delete()
				frameCount = 0
			end		
	end

    	spell.collision_func = function(self, other)
	    Engine.play_audio(Engine.load_audio(_folderpath.."hitsound.ogg"), AudioPriority.Low)		
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(Engine.load_texture(_folderpath.."effect.png"), true)
    hitfx:set_offset(math.random(-30,30), math.random(-30,30))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-9)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(_folderpath .. "effect.animation")
	hitfx_anim:set_state("0")
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    self:get_field():spawn(hitfx, spell:get_current_tile())				
        self:delete()		
    	end

	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return false
	end



	return spell
end