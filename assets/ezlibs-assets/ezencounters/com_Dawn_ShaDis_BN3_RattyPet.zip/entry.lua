local package_id = "com.Dawn.ShaDis.BN3.RattyPet"
local character_id = "com.Dawn.ShaDis.BN3.pet.RattyPet"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Ratty")
    package:set_description("Go Go Ratton Rangers!")
    package:set_speed(1)
    package:set_attack(40)
    package:set_health(20)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    print("_modpath is: ".._modpath)
    mob:stream_music(_modpath.."music.mid", 0, 0)

    mob:create_spawner(character_id, Rank.V1)
        :spawn_at(4, 1)
    mob:create_spawner(character_id, Rank.V2)
        :spawn_at(5, 2)
    mob:create_spawner(character_id, Rank.V3)
        :spawn_at(4, 3)
    --[[mob:create_spawner(character_id, Rank.SP)
        :spawn_at(6, 2)]]--
end