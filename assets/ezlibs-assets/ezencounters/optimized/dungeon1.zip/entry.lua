-- Generated minimal ezencounters wrapper.
-- Unsupported obstacle layouts and packaged music are redirected to the legacy
-- package by the server-side resolver before this package is initiated.

local PACKAGE_ID = "com.shadishp.mob.ezencounters.dungeon1"
local PACKAGE_NAME = "ezencounters_dungeon1"

local enemy_packages = {
    HeelNavi = "com.louise.enemy.HeelNavi",
    Swordy = "com.louise.enemy.Swordy",
    Noir = "com.OctoChris.enemy.Noir",
    Metrid = "com.EXE3.Metrid.Enemy",
    MegaBunny = "com.louise.enemy.MegaBunny",
    ElementMan = "com.OFC.char.EXE6-045-ElementMan1",
    JokerEye = "com.louise.enemy.JokerEye",
    Gunner = "com.OFC.char.EXE6-023-Gunner",
    ShadeMan = "com.Dawn.Enemy.Shademan",
    Yort = "com.louise.enemy.Yort",
    DemonEye = "com.louise.enemy.DemonEye",
    TuffBunny = "com.louise.enemy.TuffBunny",
    Volcano = "com.louise.enemy.Volcano",
    MegaCorn = "com.louise.enemy.Corn.MegaCorn",
    Fishy = "com.louise.enemy.Fishy",
    Beetank = "com.OFC.char.EXEPoN-007-Kabutank",
    Spikey = "com.Dawn.char.Spikey",
    Quaker = "com.louise.enemy.Quaker",
    MettaurPet = "com.OFC.char.EXE6-001-MetallPet",
    RattyPet = "com.Dawn.ShaDis.BN3.pet.RattyPet",
    SwordyPet = "com.louise.pet.SwordyPet",
    PowiePet = "com.Konstinople.pet.powiepet",
    SpikeyPet = "com.Dawn.ShaDis.BN3.pet.SpikeyPet",
    PiranhaPet = "com.louise.pet.PiranhaPet",
    BunnyPet = "com.OFC.char.EXE3-010-BunnyPet",
    FishyPet = "com.OFC.char.EXE3-003-FishyPet",
    VolgearPet = "com.louise.pet.VolgearPet",
}

local loaded_obstacles = {}

local obstacle_scripts = {
    RockCube = "obstacles/rock_cube.lua",
    Rock = "obstacles/rock.lua",
    Coffin = "obstacles/coffin.lua",
    BlastCube = "obstacles/blast_cube.lua",
    IceCube = "obstacles/ice_cube.lua",
    MysteryData = "obstacles/mystery.lua",
}

local tile_states = {
    0,  -- normal
    1,  -- cracked
    2,  -- broken
    11, -- up
    12, -- down
    9,  -- left
    10, -- right
    7,  -- empty
    4,  -- grass
    17, -- hidden
    8,  -- holy
    3,  -- ice
    5,  -- lava
    6,  -- poison
    13, -- volcano
    14, -- sea
    15, -- sand
    16, -- metal
}

local enemy_ranks = {
    0, -- v1
    1, -- v2
    2, -- v3
    3, -- sp
    4, -- ex
    5, -- rare1
    6, -- rare2
    7, -- nightmare
}

local default_tiles = {
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
}

local default_teams = {
    {2,2,2,1,1,1},
    {2,2,2,1,1,1},
    {2,2,2,1,1,1},
}

local function enum_value(mapping, index, label)
    local value = mapping[tonumber(index)]
    if value == nil then
        print("[ezencounters optimized] invalid " .. tostring(label) .. " index: " .. tostring(index))
    end
    return value
end

function package_requires_scripts()
    for _, package_id in pairs(enemy_packages) do
        Engine.requires_character(package_id)
    end
end

function package_init(package)
    package:declare_package_id(PACKAGE_ID)
    package:set_name(PACKAGE_NAME)
    package:set_description("Targeted ShaDisHP encounter wrapper")
end

function package_build(mob, data)
    if not data then
        print("[ezencounters optimized] no encounter data supplied")
        return
    end

    for alias, script_path in pairs(obstacle_scripts) do
        if loaded_obstacles[alias] == nil then
            loaded_obstacles[alias] = include(script_path)
        end
    end

    local field = mob:get_field()
    local tiles = data.tiles or default_tiles
    local teams = data.teams or default_teams

    for y, row in ipairs(tiles) do
        for x, tile_state_index in ipairs(row) do
            local tile = field:tile_at(x, y)
            local state = enum_value(tile_states, tile_state_index, "tile state")
            if state ~= nil then tile:set_state(state) end
        end
    end

    for y, row in ipairs(teams) do
        for x, team_index in ipairs(row) do
            field:tile_at(x, y):set_team(team_index, false)
        end
    end

    if type(data.enemies) ~= "table" then
        print("[ezencounters optimized] encounter has no enemies")
        return
    end

    local spawners = {}
    for index, enemy_info in ipairs(data.enemies) do
        local package_id = enemy_packages[enemy_info.name]
        if not package_id then
            print("[ezencounters optimized] missing enemy alias: " .. tostring(enemy_info.name))
            return
        end

        local enemy_rank = enum_value(enemy_ranks, enemy_info.rank, "enemy rank")
        if enemy_rank == nil then return end
        spawners[index] = mob:create_spawner(package_id, enemy_rank)
    end

    if type(data.positions) ~= "table" then
        print("[ezencounters optimized] encounter has no enemy positions")
        return
    end

    for y, row in ipairs(data.positions) do
        for x, spawner_id in ipairs(row) do
            if spawner_id ~= 0 then
                local spawner = spawners[spawner_id]
                local enemy_info = data.enemies[spawner_id]
                if not spawner or not enemy_info then
                    print("[ezencounters optimized] invalid spawner id: " .. tostring(spawner_id))
                    return
                end

                local spawn_x, spawn_y = x, y
                local mutator = spawner:spawn_at(spawn_x, spawn_y)
                mutator:mutate(function(character)
                    if enemy_info.pet_bridge_name ~= nil then
                        character:set_name(enemy_info.pet_bridge_name)
                    elseif enemy_info.pet_chip_id ~= nil then
                        character:set_name("__PETC" .. tostring(enemy_info.pet_chip_id))
                    elseif enemy_info.nickname ~= nil then
                        character:set_name(enemy_info.nickname)
                    end

                    if enemy_info.starting_hp ~= nil then
                        character:set_health(enemy_info.starting_hp)
                    end

                    if enemy_info.team ~= nil then
                        character:set_team(enemy_info.team)
                    end

                    if enemy_info.facing ~= nil then
                        character:set_facing(enemy_info.facing)
                    elseif enemy_info.team ~= nil then
                        local width = field:width()
                        if spawn_x <= math.floor(width / 2) then
                            character:set_facing(Direction.Right)
                        else
                            character:set_facing(Direction.Left)
                        end
                    end
                end)
            end
        end
    end

    if type(data.player_positions) == "table" then
        for y, row in ipairs(data.player_positions) do
            for x, player_id in ipairs(row) do
                if player_id ~= 0 then
                    mob:spawn_player(player_id, x, y)
                end
            end
        end
    end

    if data.freedom_mission then
        local turns = tonumber(data.freedom_mission.turns) or 3
        local can_flip = data.freedom_mission.player_can_flip
        if can_flip == nil then can_flip = true end
        mob:enable_freedom_mission(turns, can_flip)
    end
    if type(data.obstacle_positions) == "table" then
        if type(data.obstacles) ~= "table" then
            print("[ezencounters optimized] obstacle positions supplied without obstacle definitions")
            return
        end

        for y, row in ipairs(data.obstacle_positions) do
            for x, obstacle_id in ipairs(row) do
                obstacle_id = tonumber(obstacle_id) or 0

                if obstacle_id ~= 0 then
                    local obstacle_info = data.obstacles[obstacle_id]

                    if not obstacle_info then
                        print(
                            "[ezencounters optimized] invalid obstacle id: "
                            .. tostring(obstacle_id)
                        )
                        return
                    end

                    local obstacle_name = tostring(obstacle_info.name or "")
                    local create_obstacle = loaded_obstacles[obstacle_name]

                    if type(create_obstacle) ~= "function" then
                        print(
                            "[ezencounters optimized] missing obstacle alias: "
                            .. obstacle_name
                        )
                        return
                    end

                    local obstacle = create_obstacle()
                    field:spawn(obstacle, x, y)
                end
            end
        end
    end
end
