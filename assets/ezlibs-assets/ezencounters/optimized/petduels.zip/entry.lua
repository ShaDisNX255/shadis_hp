-- Pet-duel encounter wrapper.
-- This package intentionally supports pets only and never spawns a player.

local PACKAGE_ID = "com.shadishp.mob.ezencounters.petduels"
local PACKAGE_NAME = "ezencounters_petduels"

local enemy_packages = {
    MettaurPet = "com.OFC.char.EXE6-001-MetallPet",
    RattyPet = "com.Dawn.ShaDis.BN3.pet.RattyPet",
    SwordyPet = "com.louise.pet.SwordyPet",
    PowiePet = "com.Konstinople.pet.powiepet",
    SpikeyPet = "com.Dawn.ShaDis.BN3.pet.SpikeyPet",
    PiranhaPet = "com.louise.pet.PiranhaPet",
    BunnyPet = "com.OFC.char.EXE3-010-BunnyPet",
    FishyPet = "com.OFC.char.EXE3-003-FishyPet",
    VolgearPet = "com.louise.pet.VolgearPet",
}

local tile_states = {
    0,  -- normal
    1,  -- cracked
    2,  -- broken
    11, -- up
    12, -- down
    9,  -- left
    10, -- right
    7,  -- empty
    4,  -- grass
    17, -- hidden
    8,  -- holy
    3,  -- ice
    5,  -- lava
    6,  -- poison
    13, -- volcano
    14, -- sea
    15, -- sand
    16, -- metal
}

local enemy_ranks = {
    0, -- v1
    1, -- v2
    2, -- v3
    3, -- sp
    4, -- ex
    5, -- rare1
    6, -- rare2
    7, -- nightmare
}

local default_tiles = {
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
}

local default_teams = {
    {2,2,2,1,1,1},
    {2,2,2,1,1,1},
    {2,2,2,1,1,1},
}

local function spawn_player_removal_controller(field)
    local finder = Battle.Artifact.new()
    finder:hide()

    local elapsed_frames = 0

    finder.update_func = function(self)
        elapsed_frames = elapsed_frames + 1

        local players = field:find_characters(function(character)
            return Battle.Player.from(character) ~= nil
        end)

        if #players == 0 then
            if elapsed_frames >= 300 then
                print("[petduels] timed out waiting for battle Player")
                self:erase()
            end

            return
        end

        local removed = 0

        for _, character in ipairs(players) do
            local player = Battle.Player.from(character)

            if player ~= nil then
                player:erase()
                removed = removed + 1
            end
        end

        print(
            "[petduels] removed battle Player(s): "
            .. tostring(removed)
        )

        self:erase()
    end

    field:spawn(
        finder,
        field:tile_at(1, 1)
    )
end

local pet_elements = {
    fire = Element.Fire,
    aqua = Element.Aqua,
    elec = Element.Elec,
    wood = Element.Wood,
}

local PET_ELEMENT_AURA_PALETTES = {
    fire = Engine.load_texture(
        _modpath .. "element_aura/fire.palette.png"
    ),

    aqua = Engine.load_texture(
        _modpath .. "element_aura/aqua.palette.png"
    ),

    elec = Engine.load_texture(
        _modpath .. "element_aura/elec.palette.png"
    ),

    wood = Engine.load_texture(
        _modpath .. "element_aura/wood.palette.png"
    ),
}

local LAVAFIELD_FLASH_AUDIO =
    Engine.load_audio(
        _modpath .. "field_effects/EXE4_351.ogg"
    )

local LAVAFIELD_COMPLETE_AUDIO =
    Engine.load_audio(
        _modpath .. "field_effects/EXE4_136.ogg"
    )

local PET_ELEMENT_AURA_OFFSETS = {
    {-2, 0}, {2, 0},
    {0, -2}, {0, 2},
    {-2, -2}, {2, -2},
    {-2, 2}, {2, 2},
}

local FIELD_EFFECTS = {
    lava = {
        shortname = "LavaField",
        tile_state = TileState.Lava,
    },

    grass = {
        shortname = "GrassField",
        tile_state = TileState.Grass,
    },

    ice = {
        shortname = "IceField",
        tile_state = TileState.Ice,
    },

    sea = {
        shortname = "SeaField",
        tile_state = TileState.Sea,
    },

    cancel = {
        shortname = "CancelField",
        cancel = true,
    },
}

local function install_pet_element_aura(
    character,
    element_name
)
    local palette =
        PET_ELEMENT_AURA_PALETTES[element_name]

    if palette == nil then
        return
    end

    local field = character:get_field()
    local source_animation =
        character:get_animation()

    local auras = {}

    for _, offset in ipairs(
        PET_ELEMENT_AURA_OFFSETS
    ) do
        local aura =
            Battle.Artifact.new()

        aura:set_texture(
            character:sprite():get_texture(),
            false
        )

        -- Unlike SpriteNode, Artifact can have its
        -- own palette. Every visible palette index
        -- becomes the chosen element color.
        aura:set_palette(palette)

        aura:set_facing(
            character:get_facing()
        )

        aura:set_float_shoe(true)
        aura:set_air_shoe(true)

        -- Keep the colored copies behind the real pet.
        aura:sprite():set_layer(99)

        aura.can_move_to_func = function()
            return true
        end

        field:spawn(
            aura,
            character:get_current_tile()
        )

        aura.update_func = function(self)
            if character:is_deleted() then
                self:erase()
                return
            end

            local character_tile =
                character:get_current_tile()

            if
                self:get_current_tile()
                ~= character_tile
            then
                self:teleport(
                    character_tile,
                    ActionOrder.Immediate,
                    nil
                )
            end

            self:set_facing(
                character:get_facing()
            )

            -- Follow both normal sprite offset and
            -- movement between tiles.
            local sprite_offset =
                character:get_offset()

            local tile_offset =
                character:get_tile_offset()

            self:set_offset(
                sprite_offset.x
                    + tile_offset.x
                    + offset[1],

                sprite_offset.y
                    + tile_offset.y
                    + offset[2]
            )

            -- Use the exact animation/frame currently
            -- being displayed by the real pet.
            source_animation:refresh(
                self:sprite()
            )

            -- Reassert palette after refresh just to
            -- keep the aura completely independent
            -- from the pet's own palette changes.
            self:set_palette(palette)
        end

        auras[#auras + 1] = aura
    end

    print(
        "[petduels] element aura installed: "
        .. tostring(element_name)
    )
end

local function apply_pet_element(
    character,
    element_name
)
    element_name = tostring(element_name or "")

    local element =
        pet_elements[element_name]

    if element == nil then
        return
    end

    character:set_element(element)

    install_pet_element_aura(
        character,
        element_name
    )

    print(
        "[petduels] pet element applied: "
        .. tostring(element_name)
    )
end

local function find_pet_element_target(
    field,
    target
)
    local wanted_tile =
        field:tile_at(
            target.x,
            target.y
        )

    local matches =
        field:find_characters(function(character)
            -- Ignore the automatically injected battle Player.
            if Battle.Player.from(character) ~= nil then
                return false
            end

            if
                target.team ~= nil
                and character:get_team() ~= target.team
            then
                return false
            end

            return
                character:get_current_tile()
                == wanted_tile
        end)

    return matches[1]
end

local function spawn_pet_element_controller(
    field,
    targets
)
    if
        type(targets) ~= "table"
        or #targets == 0
    then
        return
    end

    local controller =
        Battle.Artifact.new()

    controller:hide()

    local elapsed_frames = 0
    local stable_frames = 0

    controller.update_func = function(self)
        elapsed_frames =
            elapsed_frames + 1

        local ready_count = 0

        for _, target in ipairs(targets) do
            local character =
                target.character

            if
                character == nil
                or character:is_deleted()
            then
                character =
                    find_pet_element_target(
                        field,
                        target
                    )

                target.character =
                    character
            end

            if character ~= nil then
                local element =
                    pet_elements[target.element]

                if element ~= nil then
                    -- Reapply during setup so the pet package's own
                    -- initialization cannot restore its original element.
                    character:set_element(element)

                    if not target.aura_installed then
                        install_pet_element_aura(
                            character,
                            target.element
                        )

                        target.aura_installed = true

                        print(
                            "[petduels] pet element active: "
                            .. tostring(target.element)
                            .. " team="
                            .. tostring(target.team)
                        )
                    end

                    ready_count =
                        ready_count + 1
                end
            end
        end

        if ready_count == #targets then
            stable_frames =
                stable_frames + 1
        else
            stable_frames = 0
        end

        if stable_frames >= 5 then
            print(
                "[petduels] pet elements stabilized"
            )

            self:erase()
            return
        end

        if elapsed_frames >= 300 then
            print(
                "[petduels] timed out waiting for pet element targets"
            )

            self:erase()
        end
    end

    field:spawn(
        controller,
        field:tile_at(1, 1)
    )
end

local function spawn_pet_health_cap_controller(
    field,
    targets
)
    if
        type(targets) ~= "table"
        or #targets == 0
    then
        return
    end

    local controller =
        Battle.Artifact.new()

    controller:hide()

    local component =
        Battle.Component.new(
            controller,
            Lifetimes.Battlestep
        )

    component.update_func = function(self)
        for _, target in ipairs(targets) do
            local character =
                target.character

            if
                character == nil
                or character:is_deleted()
            then
                character =
                    find_pet_element_target(
                        field,
                        target
                    )

                target.character =
                    character
            end

            if character ~= nil then
                local hp_cap =
                    math.max(
                        1,
                        math.floor(
                            tonumber(
                                target.hp_cap
                            ) or 1
                        )
                    )

                local health =
                    math.floor(
                        tonumber(
                            character:get_health()
                        ) or 0
                    )

                if health > hp_cap then
                    character:set_health(
                        hp_cap
                    )

                    -- Don't spam logs every time a
                    -- Grass panel attempts another heal.
                    if not target.clamp_logged then
                        target.clamp_logged = true

                        print(
                            "[petduels] HP clamped"
                            .. " team="
                            .. tostring(
                                target.team
                            )
                            .. " cap="
                            .. tostring(
                                hp_cap
                            )
                        )
                    end
                end
            end
        end
    end

    controller:register_component(
        component
    )

    field:spawn(
        controller,
        field:tile_at(1, 1)
    )
end

local function create_pet_setup_hold_action(
    actor,
    setup_state,
    team,
    wait_until_done
)
    local animation_state =
        actor:get_animation():get_state()

    local action =
        Battle.CardAction.new(
            actor,
            animation_state
        )

    action:set_lockout(
        make_sequence_lockout()
    )

    action.execute_func = function(self, user)
        local step =
            Battle.Step.new()

        step.update_func = function(
            self,
            dt
        )
            local released =
                setup_state.done == true

            if not wait_until_done then
                released =
                    released
                    or setup_state.released_teams[
                        team
                    ] == true
            end

            if released then
                self:complete_step()
            end
        end

        self:add_step(step)
    end

    return action
end

local function create_field_action(
    actor,
    presentation,
    on_complete
)
    local effect_name =
        tostring(
            presentation
            and presentation.effect
            or ""
        )

    local definition =
        FIELD_EFFECTS[effect_name]

    if definition == nil then
        print(
            "[petduels] unknown field effect: "
            .. tostring(effect_name)
        )

        return nil
    end

    local props =
        Battle.CardProperties.new()

    props.shortname =
        tostring(
            presentation.shortname
            or definition.shortname
        )

    props.damage = 0
    props.time_freeze = true
    props.skip_time_freeze_intro = false
    props.element = Element.None
    props.secondary_element = Element.None
    props.card_class = CardClass.Standard
    props.can_boost = false

    local animation_state =
        actor:get_animation():get_state()

    local action =
        Battle.CardAction.new(
            actor,
            animation_state
        )

    action:set_lockout(
        make_sequence_lockout()
    )

    action:set_metadata(props)

    action.execute_func = function(self, user)
        local field =
            user:get_field()

    -- Same-field cancellation is presentation only.
    -- Give the time-freeze banner a brief moment,
    -- but don't alter any panels.
    if definition.cancel == true then
        local remaining = 0.12

        local step =
            Battle.Step.new()

        step.update_func = function(
            self,
            dt
        )
            remaining =
                remaining - dt

            if remaining > 0 then
                return
            end

            if on_complete then
                on_complete(user)
            end

            self:complete_step()

            print(
                "[petduels] CancelField complete"
            )
        end

        self:add_step(step)
        return
    end

        local target_team =
            tonumber(
                presentation.target_team
            )

        local tiles =
            field:find_tiles(function(tile)
                if
                    presentation.target == "all"
                    or target_team == nil
                then
                    return true
                end

                return
                    tile:get_team()
                    == target_team
            end)

        local original_states = {}

        for i, tile in ipairs(tiles) do
            original_states[i] =
                tile:get_state()
        end

        local k = 0
        local cooldown = 0
        local showing_field = false

        local step =
            Battle.Step.new()

        step.update_func = function(
            self,
            dt
        )
            if cooldown > 0 then
                cooldown =
                    cooldown - dt

                return
            end

            cooldown = 0.04
            k = k + 1

            Engine.play_audio(
                LAVAFIELD_FLASH_AUDIO,
                AudioPriority.Highest
            )

            showing_field =
                not showing_field

            for i, tile in ipairs(tiles) do
                if showing_field then
                    tile:set_state(
                        definition.tile_state
                    )
                else
                    tile:set_state(
                        original_states[i]
                    )
                end
            end

            if k >= 17 then
                Engine.play_audio(
                    LAVAFIELD_COMPLETE_AUDIO,
                    AudioPriority.High
                )

                for _, tile in ipairs(tiles) do
                    tile:set_state(
                        definition.tile_state
                    )
                end

                if on_complete then
                    on_complete(user)
                end

                self:complete_step()

                print(
                    "[petduels] "
                    .. tostring(
                        definition.shortname
                    )
                    .. " complete"
                )
            end
        end

        self:add_step(step)
    end

    return action
end

local function find_pet_by_team(
    field,
    team
)
    local matches =
        field:find_characters(function(character)
            if
                Battle.Player.from(character)
                ~= nil
            then
                return false
            end

            return
                character:get_team()
                == team
        end)

    return matches[1]
end

local function spawn_field_presentation_controller(
    field,
    presentations
)
    if
        type(presentations) ~= "table"
        or #presentations == 0
    then
        return
    end

    local controller =
        Battle.Artifact.new()

    controller:hide()

    local setup_state = {
        armed = false,
        done = false,

        released_teams = {},

        combat_frames = 0,
        pets_by_team = {},
    }

    local function find_pets()
        return field:find_characters(
            function(character)
                return
                    Battle.Player.from(character)
                    == nil
            end
        )
    end

    local queue_presentation

    queue_presentation =
        function(index, previous_actor)
            local presentation =
                presentations[index]

            if presentation == nil then
                setup_state.done = true

                print(
                    "[petduels] PREP STEP 4 Combat released"
                )

                return
            end

            local owner_team =
                tonumber(
                    presentation.owner_team
                )

            local actor =
                setup_state.pets_by_team[
                    owner_team
                ]

            if
                actor == nil
                or actor:is_deleted()
            then
                print(
                    "[petduels] missing field actor"
                )

                setup_state.done = true
                return
            end

            -- If control is moving to the other pet,
            -- immediately put the previous actor back
            -- into an invisible hold until Step 3 ends.
            if
                previous_actor ~= nil
                and previous_actor:get_id()
                    ~= actor:get_id()
            then
                previous_actor:card_action_event(
                    create_pet_setup_hold_action(
                        previous_actor,
                        setup_state,
                        previous_actor:get_team(),
                        true
                    ),
                    ActionOrder.Immediate
                )
            end

            local action =
                create_field_action(
                    actor,
                    presentation,
                    function(user)
                        queue_presentation(
                            index + 1,
                            user
                        )
                    end
                )

            if action == nil then
                setup_state.done = true
                return
            end

            -- If this actor was waiting inside the
            -- setup hold, queue its Field action first,
            -- THEN release the hold.
            actor:card_action_event(
                action,
                ActionOrder.Immediate
            )

            setup_state.released_teams[
                owner_team
            ] = true

            print(
                "[petduels] queued "
                .. tostring(
                    presentation.shortname
                    or presentation.effect
                )
                .. " team="
                .. tostring(owner_team)
            )
        end

    local function arm_setup()
        if setup_state.armed then
            return true
        end

        local pets = find_pets()

        if #pets < 2 then
            return false
        end

        for _, pet in ipairs(pets) do
            setup_state.pets_by_team[
                pet:get_team()
            ] = pet
        end

        local first =
            presentations[1]

        local first_team =
            tonumber(first.owner_team)

        local first_actor =
            setup_state.pets_by_team[
                first_team
            ]

        if first_actor == nil then
            return false
        end

        -- Lock every pet except the first Field owner.
        for _, pet in ipairs(pets) do
            if
                pet:get_id()
                ~= first_actor:get_id()
            then
                pet:card_action_event(
                    create_pet_setup_hold_action(
                        pet,
                        setup_state,
                        pet:get_team(),
                        false
                    ),
                    ActionOrder.Immediate
                )
            end
        end

        setup_state.armed = true

        queue_presentation(
            1,
            nil
        )

        print(
            "[petduels] pre-combat field barrier armed"
        )

        return true
    end

    controller.battle_start_func =
        function(self)
            arm_setup()
        end

    local component =
        Battle.Component.new(
            controller,
            Lifetimes.Battlestep
        )

    component.update_func = function(self)
        setup_state.combat_frames =
            setup_state.combat_frames + 1

        if not setup_state.armed then
            arm_setup()
            return
        end

        if setup_state.done then
            controller:erase()
            return
        end

        if
            setup_state.combat_frames
            >= 600
        then
            print(
                "[petduels] field barrier timeout; forcing result"
            )

            -- Apply the server-resolved result directly
            -- so a presentation failure cannot leave
            -- the two simulations with different fields.
            for _, presentation in ipairs(
                presentations
            ) do
                local definition =
                    FIELD_EFFECTS[
                        tostring(
                            presentation.effect
                        )
                    ]

                if
                    definition
                    and definition.tile_state ~= nil
                then
                    local target_team =
                        tonumber(
                            presentation.target_team
                        )

                    local tiles =
                        field:find_tiles(
                            function(tile)
                                if
                                    presentation.target
                                        == "all"
                                    or target_team
                                        == nil
                                then
                                    return true
                                end

                                return
                                    tile:get_team()
                                    == target_team
                            end
                        )

                    for _, tile in ipairs(tiles) do
                        tile:set_state(
                            definition.tile_state
                        )
                    end
                end
            end

            setup_state.done = true
        end
    end

    controller:register_component(
        component
    )

    field:spawn(
        controller,
        field:tile_at(1, 1)
    )
end

local function add_under_shirt(
    character
)
    local under_shirt =
        Battle.DefenseRule.new(
            61044,
            DefenseOrder.CollisionOnly
        )

    under_shirt.filter_statuses_func =
        function(hit_props)
            local damage =
                math.max(
                    0,
                    hit_props.damage or 0
                )

            local current_health =
                character:get_health()

            if
                current_health > 1
                and damage >= current_health
            then
                hit_props.damage = 0

                character:set_health(1)
            end

            return hit_props
        end

    character:add_defense_rule(
        under_shirt
    )
end

local function enum_value(mapping, index, label)
    local value = mapping[tonumber(index)]
    if value == nil then
        print("[petduels] invalid " .. tostring(label) .. " index: " .. tostring(index))
    end
    return value
end

function package_requires_scripts()
    for _, package_id in pairs(enemy_packages) do
        Engine.requires_character(package_id)
    end
end

function package_init(package)
    package:declare_package_id(PACKAGE_ID)
    package:set_name(PACKAGE_NAME)
    package:set_description("Pet duel encounter wrapper")
end

function package_build(mob, data)
    if not data then
        print("[petduels] no encounter data supplied")
        return
    end

    if data.no_results == true then
        mob:no_results()
    end

    local field = mob:get_field()

    spawn_field_presentation_controller(
        field,
        data.field_presentations
    )

    spawn_player_removal_controller(field)

    local tiles = data.tiles or default_tiles
    local teams = data.teams or default_teams

    for y, row in ipairs(tiles) do
        for x, tile_state_index in ipairs(row) do
            local tile = field:tile_at(x, y)
            local state = enum_value(tile_states, tile_state_index, "tile state")
            if state ~= nil then
                tile:set_state(state)
            end
        end
    end

    for y, row in ipairs(teams) do
        for x, team_index in ipairs(row) do
            field:tile_at(x, y):set_team(team_index, false)
        end
    end

    if type(data.enemies) ~= "table" then
        print("[petduels] encounter has no pets")
        return
    end

    local spawners = {}

    for index, enemy_info in ipairs(data.enemies) do
        local package_id = enemy_packages[enemy_info.name]
        if not package_id then
            print("[petduels] missing pet alias: " .. tostring(enemy_info.name))
            return
        end

        local enemy_rank = enum_value(enemy_ranks, enemy_info.rank, "enemy rank")
        if enemy_rank == nil then
            return
        end

        spawners[index] = mob:create_spawner(package_id, enemy_rank)
    end

    if type(data.positions) ~= "table" then
        print("[petduels] encounter has no pet positions")
        return
    end

    local pet_element_targets = {}
    local pet_health_cap_targets = {}

    for y, row in ipairs(data.positions) do
        for x, spawner_id in ipairs(row) do
            if spawner_id ~= 0 then
                local spawner = spawners[spawner_id]
                local enemy_info = data.enemies[spawner_id]

                if not spawner or not enemy_info then
                    print("[petduels] invalid spawner id: " .. tostring(spawner_id))
                    return
                end

                local spawn_x, spawn_y = x, y
                local mutator = spawner:spawn_at(spawn_x, spawn_y)

                local health_cap_target = {
                    x = spawn_x,
                    y = spawn_y,

                    team = enemy_info.team,

                    hp_cap =
                        enemy_info.hp_cap
                        or enemy_info.starting_hp,
                }

                pet_health_cap_targets[
                    #pet_health_cap_targets + 1
                ] = health_cap_target

                if enemy_info.element ~= nil then
                    pet_element_targets[
                        #pet_element_targets + 1
                    ] = {
                        x = spawn_x,
                        y = spawn_y,

                        team = enemy_info.team,

                        element =
                            tostring(
                                enemy_info.element
                            ),
                    }
                end

                mutator:mutate(function(character)
                    health_cap_target.character =
                        character
                    if enemy_info.pet_bridge_name ~= nil then
                        character:set_name(enemy_info.pet_bridge_name)
                    elseif enemy_info.pet_chip_id ~= nil then
                        character:set_name("__PETC" .. tostring(enemy_info.pet_chip_id))
                    elseif enemy_info.nickname ~= nil then
                        character:set_name(enemy_info.nickname)
                    end

                    if enemy_info.starting_hp ~= nil then
                        character:set_health(enemy_info.starting_hp)
                    end

                    if enemy_info.element ~= nil then
                        local early_element =
                            pet_elements[
                                tostring(
                                    enemy_info.element
                                )
                            ]

                        if early_element ~= nil then
                            character:set_element(
                                early_element
                            )
                        end
                    end

                    if enemy_info.team ~= nil then
                        character:set_team(enemy_info.team)
                    end

                    if enemy_info.facing ~= nil then
                        character:set_facing(enemy_info.facing)
                    elseif enemy_info.team ~= nil then
                        local width = field:width()

                        if spawn_x <= math.floor(width / 2) then
                            character:set_facing(Direction.Right)
                        else
                            character:set_facing(Direction.Left)
                        end
                    end
                    if enemy_info.under_shirt == true then
                        add_under_shirt(character)

                        print(
                            "[petduels] UnderShirt installed"
                            .. " team="
                            .. tostring(
                                enemy_info.team
                            )
                        )
                    end
                end)
            end
        end
    end

    spawn_pet_element_controller(
        field,
        pet_element_targets
    )

    spawn_pet_health_cap_controller(
        field,
        pet_health_cap_targets
    )

--    spawn_field_presentation_controller(
--        field,
--        data.field_presentation
--    )
end
