-- Generated minimal ezencounters wrapper.
-- Unsupported obstacle layouts and packaged music are redirected to the legacy
-- package by the server-side resolver before this package is initiated.

local PACKAGE_ID = "com.shadishp.mob.ezencounters.elmquest"
local PACKAGE_NAME = "ezencounters_elmquest"

local enemy_packages = {
    Mettaur = "com.OFC.char.EXE6-001-Metall",
    Spikey = "com.Dawn.char.Spikey",
    Shrimpy = "com.louise.enemy.Shrimpy",
    Weathers = "com.OFC.char.EXE4-013-Weathers",
    AppleSam = "com.OFC.char.EXE5-027-AppleSam",
    MegaCorn = "com.louise.enemy.Corn.MegaCorn", -- V1
    Lark="com.louise.enemy.Lark",--V1,R1,R2,SP,NM
    Piranha="com.louise.enemy.Piranha",
    Metrid="com.EXE3.Metrid.Enemy",--V1,V2,V3,SP
    Bunny="com.louise.enemy.Bunny", --First Version, Spawn @ V1
    KillerEye="com.louise.enemy.KillerEye",--V1,SP,R1,R2
    DemonEye="com.louise.enemy.DemonEye",--V1
    TuffBunny="com.louise.enemy.TuffBunny", --Second Version, Spawn @ V1
    DreamMoss = "com.OFC.char.EXEPoN-018-DreamMoss",
    DreamMeraru = "com.OFC.char.EXEPoN-018-DreamMeraru",
    DreamLapia = "com.OFC.char.EXEPoN-018-DreamLapia",
    DreamBolt = "com.OFC.char.EXEPoN-018-DreamBolt",
    MettaurPet = "com.OFC.char.EXE6-001-MetallPet",
    RattyPet = "com.Dawn.ShaDis.BN3.pet.RattyPet",
    SwordyPet = "com.louise.pet.SwordyPet",
    PowiePet = "com.Konstinople.pet.powiepet",
    SpikeyPet = "com.Dawn.ShaDis.BN3.pet.SpikeyPet",
    PiranhaPet = "com.louise.pet.PiranhaPet",
    BunnyPet = "com.OFC.char.EXE3-010-BunnyPet",
    FishyPet = "com.OFC.char.EXE3-003-FishyPet",
    VolgearPet = "com.louise.pet.VolgearPet",
}

local tile_states = {
    0,  -- normal
    1,  -- cracked
    2,  -- broken
    11, -- up
    12, -- down
    9,  -- left
    10, -- right
    7,  -- empty
    4,  -- grass
    17, -- hidden
    8,  -- holy
    3,  -- ice
    5,  -- lava
    6,  -- poison
    13, -- volcano
    14, -- sea
    15, -- sand
    16, -- metal
}

local enemy_ranks = {
    0, -- v1
    1, -- v2
    2, -- v3
    3, -- sp
    4, -- ex
    5, -- rare1
    6, -- rare2
    7, -- nightmare
}

local default_tiles = {
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
}

local default_teams = {
    {2,2,2,1,1,1},
    {2,2,2,1,1,1},
    {2,2,2,1,1,1},
}

-- Encounter tables can request a temporary Player element and an optional
-- synthetic time-freeze chip presentation:
--
-- player_modifier={
--     element="grass",
--
--     chip_visual={
--         shortname="SwapWood",
--         time_freeze=true,
--         color={r=153, g=255, b=51, a=200},
--     },
-- }
--
-- SwapSound.ogg is shared by every elemental Swap presentation and must be
-- packaged beside entry.lua.
local player_elements = {
    none = Element.None,
    fire = Element.Fire,
    aqua = Element.Aqua,
    elec = Element.Elec,
    wood = Element.Wood,
}

local function resolve_player_element(value)
    if type(value) ~= "string" then
        return nil, nil
    end

    return player_elements[value], value
end

local function create_visual_color(chip_visual)
    if type(chip_visual) ~= "table" then
        return nil
    end

    local color = chip_visual.color
    if type(color) ~= "table" then
        return nil
    end

    -- Supports either:
    -- color={r=153,g=255,b=51,a=200}
    --
    -- or:
    -- color={153,255,51,200}
    local r = tonumber(color.r or color[1])
    local g = tonumber(color.g or color[2])
    local b = tonumber(color.b or color[3])
    local a = tonumber(color.a or color[4]) or 255

    if r == nil or g == nil or b == nil then
        print("[elmquest modifier] invalid chip visual color")
        return nil
    end

    return Color.new(r, g, b, a)
end

local function queue_chip_visual(player, chip_visual, element)
    if type(chip_visual) ~= "table" then
        return false
    end

    local shortname = chip_visual.shortname
    if type(shortname) ~= "string" or shortname == "" then
        shortname = "Element"
    end

    local ok, err = pcall(function()
        local props = Battle.CardProperties.new()
        props.shortname = shortname
        props.damage = 0
        props.time_freeze = chip_visual.time_freeze ~= false
        props.skip_time_freeze_intro = false
        props.element = element
        props.secondary_element = Element.None
        props.card_class = CardClass.Standard
        props.can_boost = false

        local visual_color = create_visual_color(chip_visual)

        local action = Battle.CardAction.new(
            player,
            chip_visual.animation or "PLAYER_IDLE"
        )

        action:set_metadata(props)

        action.execute_func = function(self, user)
            user:set_element(element)

            if visual_color ~= nil then
                user:set_color(visual_color)
            end

            local swap_audio =
                Engine.load_audio(_modpath .. "SwapSound.ogg")

            Engine.play_audio(
                swap_audio,
                AudioPriority.Immediate
            )

            print(
                "[elmquest modifier] synthetic action executing: "
                .. tostring(shortname)
            )
        end

        player:card_action_event(
            action,
            ActionOrder.Voluntary
        )
    end)

    if not ok then
        print(
            "[elmquest modifier] synthetic chip visual skipped: "
            .. tostring(err)
        )

        return false
    end

    print(
        "[elmquest modifier] queued synthetic chip visual: "
        .. tostring(shortname)
    )

    return true
end

local function count_expected_players(player_positions)
    local count = 0

    if type(player_positions) ~= "table" then
        return count
    end

    for _, row in ipairs(player_positions) do
        for _, player_id in ipairs(row) do
            if player_id ~= 0 then
                count = count + 1
            end
        end
    end

    return count
end

local function find_battle_players(field)
    return field:find_characters(function(character)
        return Battle.Player.from(character) ~= nil
    end)
end

local function apply_element_to_players(players, element)
    for _, character in ipairs(players) do
        local player = Battle.Player.from(character)

        if player ~= nil then
            player:set_element(element)
        end
    end
end

local function spawn_player_modifier_controller(field, data)
    local modifier = data.player_modifier
    if type(modifier) ~= "table" then
        return
    end

    local element, element_name =
        resolve_player_element(modifier.element)

    if element == nil then
        print(
            "[elmquest modifier] invalid element: "
            .. tostring(modifier.element)
        )

        return
    end

    local expected_players =
        count_expected_players(data.player_positions)

    if expected_players < 1 then
        expected_players = 1
    end

    local chip_visual = modifier.chip_visual
    local visual_requested = type(chip_visual) == "table"

    local controller = Battle.Artifact.new()
    controller:hide()

    local elapsed_frames = 0
    local stable_frames = 0

    if visual_requested then
        local combat_frames = 0
        local visual_attempted = false

        -- Battlestep only updates during actual combat. It does not count enemy
        -- spawning or time spent inside the opening Chip Select screen.
        local combat_component =
            Battle.Component.new(
                controller,
                Lifetimes.Battlestep
            )

        combat_component.update_func = function(self)
            if visual_attempted then
                return
            end

            combat_frames = combat_frames + 1

            -- Small buffer after pressing OK and entering combat.
            if combat_frames < 2 then
                return
            end

            local players = find_battle_players(field)

            if #players < expected_players then
                return
            end

            local queued_count = 0

            for _, character in ipairs(players) do
                local player = Battle.Player.from(character)

                if player ~= nil then
                    player:set_element(element)

                    if queue_chip_visual(
                        player,
                        chip_visual,
                        element
                    ) then
                        queued_count = queued_count + 1
                    end
                end
            end

            visual_attempted = true

            print(
                "[elmquest modifier] combat visual attempted: "
                .. tostring(chip_visual.shortname)
                .. "; queued="
                .. tostring(queued_count)
            )

            controller:erase()
        end

        controller:register_component(combat_component)
    end

    controller.update_func = function(self)
        elapsed_frames = elapsed_frames + 1

        local players = find_battle_players(field)

        if #players < expected_players then
            if elapsed_frames >= 300 then
                print(
                    "[elmquest modifier] timed out waiting for Players"
                )

                self:erase()
            end

            return
        end

        -- Apply for several setup updates so Player initialization cannot
        -- immediately restore the original body element.
        apply_element_to_players(players, element)

        stable_frames = stable_frames + 1

        if stable_frames == 5 then
            print(
                "[elmquest modifier] applied Player element: "
                .. tostring(element_name)
            )
        end

        -- When no presentation is requested, the controller has no reason to
        -- survive until combat. Otherwise the Battlestep component erases it.
        if stable_frames >= 5 and not visual_requested then
            self:erase()
        end
    end

    field:spawn(
        controller,
        field:tile_at(1, 1)
    )
end

local function enum_value(mapping, index, label)
    local value = mapping[tonumber(index)]
    if value == nil then
        print("[ezencounters optimized] invalid " .. tostring(label) .. " index: " .. tostring(index))
    end
    return value
end

function package_requires_scripts()
    for _, package_id in pairs(enemy_packages) do
        Engine.requires_character(package_id)
    end
end

function package_init(package)
    package:declare_package_id(PACKAGE_ID)
    package:set_name(PACKAGE_NAME)
    package:set_description("Targeted ShaDisHP encounter wrapper")
end

function package_build(mob, data)
    if not data then
        print("[ezencounters optimized] no encounter data supplied")
        return
    end

    if data.no_results == true then
        mob:no_results()
    end

    local field = mob:get_field()
    local tiles = data.tiles or default_tiles
    local teams = data.teams or default_teams

    for y, row in ipairs(tiles) do
        for x, tile_state_index in ipairs(row) do
            local tile = field:tile_at(x, y)
            local state = enum_value(tile_states, tile_state_index, "tile state")
            if state ~= nil then
                tile:set_state(state)
            end
        end
    end

    for y, row in ipairs(teams) do
        for x, team_index in ipairs(row) do
            field:tile_at(x, y):set_team(team_index, false)
        end
    end

    if type(data.enemies) ~= "table" then
        print("[ezencounters optimized] encounter has no enemies")
        return
    end

    local spawners = {}
    for index, enemy_info in ipairs(data.enemies) do
        local package_id = enemy_packages[enemy_info.name]
        if not package_id then
            print("[ezencounters optimized] missing enemy alias: " .. tostring(enemy_info.name))
            return
        end

        local enemy_rank = enum_value(enemy_ranks, enemy_info.rank, "enemy rank")
        if enemy_rank == nil then
            return
        end

        spawners[index] = mob:create_spawner(package_id, enemy_rank)
    end

    if type(data.positions) ~= "table" then
        print("[ezencounters optimized] encounter has no enemy positions")
        return
    end

    for y, row in ipairs(data.positions) do
        for x, spawner_id in ipairs(row) do
            if spawner_id ~= 0 then
                local spawner = spawners[spawner_id]
                local enemy_info = data.enemies[spawner_id]
                if not spawner or not enemy_info then
                    print("[ezencounters optimized] invalid spawner id: " .. tostring(spawner_id))
                    return
                end

                local spawn_x, spawn_y = x, y
                local mutator = spawner:spawn_at(spawn_x, spawn_y)
                mutator:mutate(function(character)
                    if enemy_info.pet_bridge_name ~= nil then
                        character:set_name(enemy_info.pet_bridge_name)
                    elseif enemy_info.pet_chip_id ~= nil then
                        character:set_name("__PETC" .. tostring(enemy_info.pet_chip_id))
                    elseif enemy_info.nickname ~= nil then
                        character:set_name(enemy_info.nickname)
                    end

                    if enemy_info.starting_hp ~= nil then
                        character:set_health(enemy_info.starting_hp)
                    end

                    if enemy_info.team ~= nil then
                        character:set_team(enemy_info.team)
                    end

                    if enemy_info.facing ~= nil then
                        character:set_facing(enemy_info.facing)
                    elseif enemy_info.team ~= nil then
                        local width = field:width()
                        if spawn_x <= math.floor(width / 2) then
                            character:set_facing(Direction.Right)
                        else
                            character:set_facing(Direction.Left)
                        end
                    end
                end)
            end
        end
    end

    if type(data.player_positions) == "table" then
        for y, row in ipairs(data.player_positions) do
            for x, player_id in ipairs(row) do
                if player_id ~= 0 then
                    mob:spawn_player(player_id, x, y)
                end
            end
        end
    end

    -- mob:spawn_player() does not expose a usable Player immediately, so this
    -- hidden Artifact waits until the Player exists before modifying it.
    spawn_player_modifier_controller(field, data)

    if data.freedom_mission then
        local turns = tonumber(data.freedom_mission.turns) or 3
        local can_flip = data.freedom_mission.player_can_flip
        if can_flip == nil then
            can_flip = true
        end

        mob:enable_freedom_mission(turns, can_flip)
    end
end